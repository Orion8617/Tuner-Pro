"""
Información detallada sobre códigos de área de Guatemala y sus coordenadas geográficas.
Esta información se usa para proporcionar ubicaciones más precisas para números de Guatemala.
"""

# Códigos de área de Guatemala con coordenadas precisas
# Formato: 'código_de_área': {'city': 'nombre_ciudad', 'latitude': valor, 'longitude': valor}
GUATEMALA_AREA_CODES = {
    '22': {
        'city': 'Ciudad de Guatemala', 
        'latitude': 14.6349, 
        'longitude': -90.5069,
        'region': 'Guatemala'
    },
    '23': {
        'city': 'Ciudad de Guatemala', 
        'latitude': 14.6349, 
        'longitude': -90.5069,
        'region': 'Guatemala'
    },
    '77': {
        'city': 'Quetzaltenango', 
        'latitude': 14.8456, 
        'longitude': -91.5222,
        'region': 'Quetzaltenango'
    },
    '78': {
        'city': 'Escuintla', 
        'latitude': 14.3000, 
        'longitude': -90.7833,
        'region': 'Escuintla'
    },
    '66': {
        'city': 'Villa Nueva', 
        'latitude': 14.5278, 
        'longitude': -90.5969,
        'region': 'Guatemala'
    },
    '79': {
        'city': 'Cobán', 
        'latitude': 15.4833, 
        'longitude': -90.3667,
        'region': 'Alta Verapaz'
    }
}

def get_guatemala_location(area_code):
    """
    Obtiene información de ubicación para un código de área de Guatemala específico.
    
    Args:
        area_code (str): El código de área de dos dígitos (ej. '22', '77')
        
    Returns:
        dict: Información de ubicación incluyendo ciudad, coordenadas y región,
              o None si el código de área no está en la base de datos
    """
    return GUATEMALA_AREA_CODES.get(area_code)