import math
import random
import hashlib
import time

DEG2RAD = math.pi / 180
M_PER_DEG = 111320

WIFI_AP_TYPES = [
    {'prefix': 'Claro-WiFi', 'vendor': '00:1A:2B', 'channel_range': (1, 11), 'freq': '2.4GHz', 'power': -30},
    {'prefix': 'Tigo-Home', 'vendor': '00:3C:4D', 'channel_range': (1, 11), 'freq': '2.4GHz', 'power': -28},
    {'prefix': 'HUAWEI', 'vendor': '48:8F:5A', 'channel_range': (36, 165), 'freq': '5GHz', 'power': -32},
    {'prefix': 'TP-LINK', 'vendor': 'C0:25:E9', 'channel_range': (1, 11), 'freq': '2.4GHz', 'power': -30},
    {'prefix': 'ARRIS', 'vendor': 'E8:ED:05', 'channel_range': (36, 165), 'freq': '5GHz', 'power': -35},
    {'prefix': 'Tigo-Business', 'vendor': '00:3C:4D', 'channel_range': (1, 11), 'freq': '2.4GHz', 'power': -25},
    {'prefix': 'ClaroNet', 'vendor': '00:1A:2B', 'channel_range': (36, 165), 'freq': '5GHz', 'power': -30},
    {'prefix': 'NETGEAR', 'vendor': 'A0:63:91', 'channel_range': (1, 11), 'freq': '2.4GHz', 'power': -28},
    {'prefix': 'D-Link', 'vendor': '1C:7E:E5', 'channel_range': (1, 11), 'freq': '2.4GHz', 'power': -30},
    {'prefix': 'Mikrotik', 'vendor': 'D4:CA:6D', 'channel_range': (36, 165), 'freq': '5GHz', 'power': -33},
    {'prefix': 'ZTE', 'vendor': '34:4B:50', 'channel_range': (1, 11), 'freq': '2.4GHz', 'power': -29},
    {'prefix': 'Linksys', 'vendor': 'C0:56:27', 'channel_range': (36, 165), 'freq': '5GHz', 'power': -31},
    {'prefix': 'TigoFibra', 'vendor': '00:3C:4D', 'channel_range': (36, 165), 'freq': '5GHz', 'power': -27},
    {'prefix': 'Ubiquiti', 'vendor': '80:2A:A8', 'channel_range': (36, 165), 'freq': '5GHz', 'power': -26},
    {'prefix': 'ASUS', 'vendor': '04:D9:F5', 'channel_range': (1, 11), 'freq': '2.4GHz', 'power': -29},
]

HN_VENUE_TYPES = [
    'Residencial', 'Pulpería', 'Farmacia', 'Banco', 'Hotel',
    'Restaurante', 'Gasolinera', 'Centro Comercial', 'Oficina', 'Escuela',
    'Iglesia', 'Hospital', 'Taller', 'Panadería', 'Tienda',
    'Cyber Café', 'Bar', 'Gimnasio', 'Clínica', 'Supermercado',
    'Ferretería', 'Barbería', 'Lavandería', 'Librería', 'Cafetería',
]

ENCRYPTION_TYPES = ['WPA2-PSK', 'WPA3-SAE', 'WPA2-Enterprise', 'WPA2-PSK', 'WPA2-PSK', 'WPA3-Personal']

HN_SSID_NAMES = [
    'WiFi-Casa', 'Internet-Hogar', 'MiRed', 'FamiliaNet', 'CasaWiFi',
    'RedLocal', 'WiFi-Oficina', 'Conexion', 'MiInternet', 'WiFiRapido',
    'LaRedDe', 'NetHogar', 'WiFi-Vecino', 'PulperiaWiFi', 'TiendaNet',
]

GRID_SIZE_DEG = 0.002


def _grid_key(lat, lng):
    return (round(lat / GRID_SIZE_DEG), round(lng / GRID_SIZE_DEG))


def generate_bssid(seed_val):
    h = hashlib.md5(str(seed_val).encode()).hexdigest()
    octets = [h[i:i+2].upper() for i in range(0, 12, 2)]
    octets[0] = format(int(octets[0], 16) & 0xFE, '02X')
    return ':'.join(octets)


def _time_epoch():
    return int(time.time() // 30)


def _generate_tile_aps(grid_lat_idx, grid_lng_idx, time_epoch):
    tile_base_seed = (grid_lat_idx * 100003 + grid_lng_idx * 99991) & 0xFFFFFFFF

    base_rng = random.Random(tile_base_seed)
    total_aps_in_area = base_rng.randint(15, 35)

    center_lat = grid_lat_idx * GRID_SIZE_DEG
    center_lng = grid_lng_idx * GRID_SIZE_DEG

    permanent_aps = []
    for i in range(total_aps_in_area):
        ap_seed = (tile_base_seed * 1000 + i * 97 + 42) & 0xFFFFFFFF
        ap_rng = random.Random(ap_seed)

        ap_type = ap_rng.choice(WIFI_AP_TYPES)

        angle = ap_rng.uniform(0, 2 * math.pi)
        dist_m = ap_rng.uniform(5, 200)
        dlat = (dist_m * math.cos(angle)) / M_PER_DEG
        cos_lat_val = max(math.cos(center_lat * DEG2RAD), 0.01)
        dlng = (dist_m * math.sin(angle)) / (M_PER_DEG * cos_lat_val)
        ap_lat = center_lat + dlat
        ap_lng = center_lng + dlng

        bssid = generate_bssid(ap_seed * 7 + 13)

        use_generic = ap_rng.random() < 0.4
        if use_generic:
            name = ap_rng.choice(HN_SSID_NAMES)
            suffix = hashlib.md5(str(ap_seed).encode()).hexdigest()[:3].upper()
            ssid = f"{name}_{suffix}"
        else:
            suffix = hashlib.md5(str(ap_seed * 500 + i * 53).encode()).hexdigest()[:4].upper()
            ssid = f"{ap_type['prefix']}_{suffix}"

        ch_lo, ch_hi = ap_type['channel_range']
        channel = ap_rng.randint(ch_lo, ch_hi)
        venue = ap_rng.choice(HN_VENUE_TYPES)
        encryption = ap_rng.choice(ENCRYPTION_TYPES)

        uptime_pct = ap_rng.uniform(0.6, 0.99)

        permanent_aps.append({
            'ssid': ssid,
            'bssid': bssid,
            'lat': ap_lat,
            'lng': ap_lng,
            'channel': channel,
            'freq': ap_type['freq'],
            'tx_power': ap_type['power'],
            'venue': venue,
            'encryption': encryption,
            'uptime_pct': uptime_pct,
            'ap_seed': ap_seed,
        })

    time_rng = random.Random(tile_base_seed ^ (time_epoch * 7919))
    visible = []
    for ap in permanent_aps:
        roll = time_rng.random()
        if roll < ap['uptime_pct']:
            visible.append(ap)

    return visible


def get_area_aps(lat, lng, radius_tiles=1):
    gk = _grid_key(lat, lng)
    epoch = _time_epoch()
    all_aps = []
    for di in range(-radius_tiles, radius_tiles + 1):
        for dj in range(-radius_tiles, radius_tiles + 1):
            tile_aps = _generate_tile_aps(gk[0] + di, gk[1] + dj, epoch)
            all_aps.extend(tile_aps)
    return all_aps


def get_visible_bssids(lat, lng, max_range_m=300):
    area_aps = get_area_aps(lat, lng, radius_tiles=2)
    visible = set()
    for ap in area_aps:
        d = _haversine_m(lat, lng, ap['lat'], ap['lng'])
        if d <= max_range_m:
            visible.add(ap['bssid'])
    return visible


def _haversine_m(lat1, lng1, lat2, lng2):
    R = 6371000
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))


def generate_wifi_aps(phone_lat, phone_lng, phone_seed, count=12):
    area_aps = get_area_aps(phone_lat, phone_lng, radius_tiles=1)

    scan_rng = random.Random(phone_seed ^ int(time.time() * 1000) & 0xFFFFFFFF)

    aps_with_dist = []
    for ap in area_aps:
        d = _haversine_m(phone_lat, phone_lng, ap['lat'], ap['lng'])
        if d <= 300:
            detect_prob = max(0.3, 1.0 - (d / 350))
            if scan_rng.random() < detect_prob:
                aps_with_dist.append((d, ap))

    aps_with_dist.sort(key=lambda x: x[0])

    actual_count = scan_rng.randint(max(3, count - 4), count + 2)

    if len(aps_with_dist) > actual_count:
        keep = aps_with_dist[:actual_count - 2]
        extras = aps_with_dist[actual_count - 2:]
        keep.extend(scan_rng.sample(extras, min(2, len(extras))))
        aps_with_dist = keep
        aps_with_dist.sort(key=lambda x: x[0])

    result = []
    for dist_m, ap in aps_with_dist[:actual_count]:
        result.append({
            'ssid': ap['ssid'],
            'bssid': ap['bssid'],
            'lat': ap['lat'],
            'lng': ap['lng'],
            'dist_m': round(dist_m, 1),
            'channel': ap['channel'],
            'freq': ap['freq'],
            'tx_power': ap['tx_power'],
            'venue': ap['venue'],
            'encryption': ap['encryption'],
        })

    if len(result) < 3:
        for i in range(3 - len(result)):
            ap_type = scan_rng.choice(WIFI_AP_TYPES)
            angle = scan_rng.uniform(0, 2 * math.pi)
            dist_m = scan_rng.uniform(5, 100)
            dlat = (dist_m * math.cos(angle)) / M_PER_DEG
            dlng = (dist_m * math.sin(angle)) / (M_PER_DEG * max(math.cos(phone_lat * DEG2RAD), 0.01))
            bssid = generate_bssid(int(time.time() * 1000) + i * 97)
            suffix = hashlib.md5(str(int(time.time()) + i * 53).encode()).hexdigest()[:4].upper()
            ch_lo, ch_hi = ap_type['channel_range']
            result.append({
                'ssid': f"{ap_type['prefix']}_{suffix}",
                'bssid': bssid,
                'lat': phone_lat + dlat,
                'lng': phone_lng + dlng,
                'dist_m': round(dist_m, 1),
                'channel': scan_rng.randint(ch_lo, ch_hi),
                'freq': ap_type['freq'],
                'tx_power': ap_type['power'],
                'venue': scan_rng.choice(HN_VENUE_TYPES),
                'encryption': scan_rng.choice(ENCRYPTION_TYPES),
            })

    result.sort(key=lambda a: a['dist_m'])
    return result


def calculate_rssi_from_distance(dist_m, tx_power=-30, freq_ghz=2.4, rng=None):
    if dist_m < 1:
        dist_m = 1
    path_loss_exp = 3.0 if freq_ghz > 3.0 else 2.7
    indoor_loss = path_loss_exp * 10 * math.log10(max(dist_m, 1))

    if rng is None:
        rng = random.Random()
    fading = rng.gauss(0, 5.0)
    multipath = rng.gauss(0, 2.5)

    rssi = tx_power - indoor_loss + fading + multipath
    return round(max(-100, min(-20, rssi)), 1)


def rssi_to_distance(rssi, tx_power=-30, freq_ghz=2.4):
    path_loss = tx_power - rssi
    path_loss_exp = 3.0 if freq_ghz > 3.0 else 2.7
    dist_m = 10 ** (path_loss / (10 * path_loss_exp))
    return max(1.0, dist_m)


def wifi_trilateration(aps_with_rssi):
    if len(aps_with_rssi) < 3:
        return None

    usable = sorted(aps_with_rssi, key=lambda a: a['rssi'], reverse=True)[:min(len(aps_with_rssi), 10)]

    cos_lat = math.cos(usable[0]['lat'] * DEG2RAD)
    m_per_lng = M_PER_DEG * cos_lat

    ref_lat = usable[0]['lat']
    ref_lng = usable[0]['lng']

    circles = []
    for ap in usable:
        freq = float(ap['freq'].replace('GHz', ''))
        est_dist = rssi_to_distance(ap['rssi'], ap.get('tx_power', -30), freq)
        x = (ap['lng'] - ref_lng) * m_per_lng
        y = (ap['lat'] - ref_lat) * M_PER_DEG
        rssi_linear = 10 ** (ap['rssi'] / 10.0)
        circles.append({'x': x, 'y': y, 'r': est_dist, 'ap': ap, 'w': rssi_linear})

    w_total = sum(c['w'] for c in circles)
    if w_total < 1e-30:
        w_total = 1.0
    est_x = sum(c['w'] * c['x'] for c in circles) / w_total
    est_y = sum(c['w'] * c['y'] for c in circles) / w_total

    for outlier_pass in range(3):
        lam = 2.0
        nu = 2.0
        for iteration in range(30):
            JtWJ = [[0.0, 0.0], [0.0, 0.0]]
            JtWr = [0.0, 0.0]
            for c in circles:
                dx = est_x - c['x']
                dy = est_y - c['y']
                d = math.sqrt(dx * dx + dy * dy)
                if d < 0.5:
                    d = 0.5
                residual = d - c['r']
                jx = dx / d
                jy = dy / d
                w = c['w']
                JtWJ[0][0] += w * jx * jx
                JtWJ[0][1] += w * jx * jy
                JtWJ[1][0] += w * jy * jx
                JtWJ[1][1] += w * jy * jy
                JtWr[0] += w * jx * residual
                JtWr[1] += w * jy * residual

            JtWJ[0][0] += lam
            JtWJ[1][1] += lam

            det = JtWJ[0][0] * JtWJ[1][1] - JtWJ[0][1] * JtWJ[1][0]
            if abs(det) < 1e-12:
                break
            step_x = (JtWr[0] * JtWJ[1][1] - JtWr[1] * JtWJ[0][1]) / det
            step_y = (JtWJ[0][0] * JtWr[1] - JtWJ[1][0] * JtWr[0]) / det

            est_x -= step_x
            est_y -= step_y
            lam = max(lam * 0.5, 1e-6)

            if abs(step_x) < 0.01 and abs(step_y) < 0.01:
                break

        if outlier_pass < 2 and len(circles) > 3:
            residuals = []
            for c in circles:
                dx = est_x - c['x']
                dy = est_y - c['y']
                d = math.sqrt(dx * dx + dy * dy)
                residuals.append(abs(d - c['r']))
            med_r = sorted(residuals)[len(residuals) // 2]
            threshold = max(med_r * 3.0, 20.0)
            kept = []
            for i, c in enumerate(circles):
                if residuals[i] <= threshold or len(kept) < 3:
                    kept.append(c)
            if len(kept) >= 3:
                circles = kept

    est_lat = ref_lat + est_y / M_PER_DEG
    est_lng = ref_lng + est_x / m_per_lng

    residual_sum = 0
    for c in circles:
        dx = est_x - c['x']
        dy = est_y - c['y']
        d = math.sqrt(dx * dx + dy * dy)
        residual_sum += abs(d - c['r'])
    avg_residual = residual_sum / len(circles) if circles else 50.0

    return {
        'lat': est_lat,
        'lng': est_lng,
        'accuracy_m': round(avg_residual, 1),
        'method': 'NLS-RSSI N-AP Trilateration',
        'aps_used': len(circles),
        'circles': [
            {
                'ssid': c['ap']['ssid'],
                'bssid': c['ap']['bssid'],
                'rssi': c['ap']['rssi'],
                'est_dist_m': round(c['r'], 1),
                'lat': c['ap']['lat'],
                'lng': c['ap']['lng'],
            } for c in circles
        ]
    }


def wifi_scan_and_position(phone_lat, phone_lng, phone_seed):
    scan_rng = random.Random(phone_seed ^ int(time.time() * 1000) & 0xFFFFFFFF)

    aps = generate_wifi_aps(phone_lat, phone_lng, phone_seed)

    aps_with_rssi = []
    for ap in aps:
        freq = float(ap['freq'].replace('GHz', ''))
        rssi = calculate_rssi_from_distance(ap['dist_m'], ap['tx_power'], freq, scan_rng)
        ap_data = dict(ap)
        ap_data['rssi'] = rssi
        aps_with_rssi.append(ap_data)

    aps_with_rssi.sort(key=lambda a: a['rssi'], reverse=True)

    wps_result = wifi_trilateration(aps_with_rssi)

    if wps_result:
        real_dist = math.sqrt(
            ((wps_result['lat'] - phone_lat) * M_PER_DEG)**2 +
            ((wps_result['lng'] - phone_lng) * M_PER_DEG * math.cos(phone_lat * DEG2RAD))**2
        )
        wps_result['error_m'] = round(real_dist, 1)

    return {
        'aps': aps_with_rssi[:8],
        'total_aps': len(aps_with_rssi),
        'wps': wps_result,
    }


def hybrid_position(cell_lat, cell_lng, cell_accuracy_m, wifi_lat, wifi_lng, wifi_accuracy_m):
    if wifi_accuracy_m <= 0:
        wifi_accuracy_m = 1
    if cell_accuracy_m <= 0:
        cell_accuracy_m = 1

    w_cell = 1.0 / (cell_accuracy_m ** 2)
    w_wifi = 1.0 / (wifi_accuracy_m ** 2)
    w_total = w_cell + w_wifi

    hybrid_lat = (w_cell * cell_lat + w_wifi * wifi_lat) / w_total
    hybrid_lng = (w_cell * cell_lng + w_wifi * wifi_lng) / w_total
    hybrid_acc = math.sqrt(1.0 / w_total)

    return {
        'lat': hybrid_lat,
        'lng': hybrid_lng,
        'accuracy_m': round(hybrid_acc, 1),
        'method': 'Hybrid (Cell + Wi-Fi WPS)',
        'cell_weight': round(w_cell / w_total * 100, 1),
        'wifi_weight': round(w_wifi / w_total * 100, 1),
    }
