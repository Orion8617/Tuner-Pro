import sqlite3
import os
import time
import math

DB_PATH = os.path.join(os.path.dirname(__file__), 'tracking_data.db')

def _get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

def init_db():
    conn = _get_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS tracking_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT NOT NULL,
            lat REAL NOT NULL,
            lng REAL NOT NULL,
            location TEXT,
            place_type TEXT,
            city TEXT,
            department TEXT,
            is_moving INTEGER DEFAULT 0,
            alert_type TEXT,
            alert_detail TEXT,
            timestamp REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_th_phone ON tracking_history(phone);
        CREATE INDEX IF NOT EXISTS idx_th_ts ON tracking_history(timestamp);

        CREATE TABLE IF NOT EXISTS tracked_phones (
            phone TEXT PRIMARY KEY,
            country TEXT,
            carrier TEXT,
            city TEXT,
            last_lat REAL,
            last_lng REAL,
            last_location TEXT,
            last_seen REAL,
            track_count INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS contacts (
            phone TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            owner_name TEXT,
            phone_model TEXT,
            lat REAL NOT NULL,
            lng REAL NOT NULL,
            colonia TEXT,
            city TEXT,
            department TEXT,
            created_at REAL,
            updated_at REAL
        );

        CREATE TABLE IF NOT EXISTS search_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT NOT NULL,
            carrier TEXT,
            city TEXT,
            lat REAL,
            lng REAL,
            country_code TEXT,
            timestamp REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_sh_ts ON search_history(timestamp);
    """)
    conn.commit()
    conn.close()

def insert_tracking(phone, lat, lng, location='', place_type='', city='', department='', is_moving=False, alert_type='', alert_detail=''):
    conn = _get_conn()
    conn.execute(
        "INSERT INTO tracking_history (phone, lat, lng, location, place_type, city, department, is_moving, alert_type, alert_detail, timestamp) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (phone, lat, lng, location, place_type, city, department, 1 if is_moving else 0, alert_type or None, alert_detail or None, time.time())
    )
    conn.commit()
    conn.close()

def upsert_tracked_phone(phone, country='', carrier='', city='', lat=0, lng=0, location=''):
    conn = _get_conn()
    now = time.time()
    existing = conn.execute("SELECT track_count FROM tracked_phones WHERE phone=?", (phone,)).fetchone()
    if existing:
        conn.execute(
            "UPDATE tracked_phones SET country=?, carrier=?, city=?, last_lat=?, last_lng=?, last_location=?, last_seen=?, track_count=track_count+1 WHERE phone=?",
            (country, carrier, city, lat, lng, location, now, phone)
        )
    else:
        conn.execute(
            "INSERT INTO tracked_phones (phone, country, carrier, city, last_lat, last_lng, last_location, last_seen, track_count) VALUES (?,?,?,?,?,?,?,?,1)",
            (phone, country, carrier, city, lat, lng, location, now)
        )
    conn.commit()
    conn.close()

def get_history(phone, limit=200):
    conn = _get_conn()
    rows = conn.execute(
        "SELECT lat, lng, location, place_type, city, department, is_moving, alert_type, alert_detail, timestamp FROM tracking_history WHERE phone=? ORDER BY timestamp DESC LIMIT ?",
        (phone, limit)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_tracked_phones(limit=50):
    conn = _get_conn()
    rows = conn.execute(
        "SELECT phone, country, carrier, city, last_lat, last_lng, last_location, last_seen, track_count FROM tracked_phones ORDER BY last_seen DESC LIMIT ?",
        (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def save_contact(phone, name, lat, lng, colonia='', city='', department='', owner_name='', phone_model=''):
    conn = _get_conn()
    now = time.time()
    existing = conn.execute("SELECT phone FROM contacts WHERE phone=?", (phone,)).fetchone()
    if existing:
        conn.execute(
            "UPDATE contacts SET name=?, owner_name=?, phone_model=?, lat=?, lng=?, colonia=?, city=?, department=?, updated_at=? WHERE phone=?",
            (name, owner_name, phone_model, lat, lng, colonia, city, department, now, phone)
        )
    else:
        conn.execute(
            "INSERT INTO contacts (phone, name, owner_name, phone_model, lat, lng, colonia, city, department, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (phone, name, owner_name, phone_model, lat, lng, colonia, city, department, now, now)
        )
    conn.commit()
    conn.close()

def get_contact(phone):
    conn = _get_conn()
    row = conn.execute("SELECT phone, name, owner_name, phone_model, lat, lng, colonia, city, department, created_at, updated_at FROM contacts WHERE phone=?", (phone,)).fetchone()
    conn.close()
    return dict(row) if row else None

def get_contact_by_normalized(normalized_digits):
    conn = _get_conn()
    rows = conn.execute("SELECT phone, name, owner_name, phone_model, lat, lng, colonia, city, department FROM contacts").fetchall()
    conn.close()
    import re as _re
    for row in rows:
        row_digits = _re.sub(r'\D', '', row['phone'].replace('+', ''))
        if row_digits == normalized_digits or row_digits.endswith(normalized_digits[-8:]):
            return dict(row)
    return None

def list_contacts(limit=100):
    conn = _get_conn()
    rows = conn.execute("SELECT phone, name, owner_name, phone_model, lat, lng, colonia, city, department, created_at, updated_at FROM contacts ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def delete_contact(phone):
    conn = _get_conn()
    conn.execute("DELETE FROM contacts WHERE phone=?", (phone,))
    conn.commit()
    conn.close()

def find_nearby_phones(target_phone, target_lat, target_lng, radius_m=250):
    from wifi_positioning import get_visible_bssids, get_area_aps

    target_bssids = get_visible_bssids(target_lat, target_lng, max_range_m=300)

    conn = _get_conn()
    rows = conn.execute(
        """SELECT phone, lat AS last_lat, lng AS last_lng, location AS last_location,
                  '' AS carrier, city, timestamp AS last_seen
           FROM (
               SELECT phone, lat, lng, location, city, timestamp,
                      ROW_NUMBER() OVER (PARTITION BY phone ORDER BY timestamp DESC) AS rn
               FROM tracking_history
               WHERE phone != ?
           ) sub WHERE rn = 1
           UNION
           SELECT phone, last_lat, last_lng, last_location, carrier, city, last_seen
           FROM tracked_phones WHERE phone != ?""",
        (target_phone, target_phone)
    ).fetchall()
    conn.close()

    seen_phones = {}
    for row in rows:
        p = row['phone']
        if p not in seen_phones or (row['last_seen'] or 0) > (seen_phones[p]['last_seen'] or 0):
            seen_phones[p] = dict(row)
    rows = list(seen_phones.values())

    area_aps = get_area_aps(target_lat, target_lng, radius_tiles=2)
    bssid_to_ap = {ap['bssid']: ap for ap in area_aps}

    nearby = []
    for entry in rows:
        other_phone = entry['phone']
        other_lat = entry.get('last_lat')
        other_lng = entry.get('last_lng')

        if other_lat is None or other_lng is None:
            continue

        dist_m = _haversine(target_lat, target_lng, other_lat, other_lng)
        if dist_m > radius_m:
            continue

        other_bssids = get_visible_bssids(other_lat, other_lng, max_range_m=300)
        shared = target_bssids & other_bssids

        if len(shared) > 0:
            masked = other_phone[:4] + '****' + other_phone[-2:] if len(other_phone) > 6 else '****'

            shared_ap_details = []
            for bssid in list(shared)[:5]:
                ap = bssid_to_ap.get(bssid)
                if ap:
                    shared_ap_details.append({
                        'bssid': bssid,
                        'ssid': ap.get('ssid', ''),
                        'lat': ap['lat'],
                        'lng': ap['lng'],
                        'venue': ap.get('venue', ''),
                    })

            nearby.append({
                'phone_masked': masked,
                'phone_full': other_phone,
                'shared_aps': len(shared),
                'distance_m': round(dist_m, 1),
                'lat': other_lat,
                'lng': other_lng,
                'location': entry.get('last_location') or '',
                'carrier': entry.get('carrier') or '',
                'city': entry.get('city') or '',
                'last_seen': entry.get('last_seen'),
                'shared_ap_details': shared_ap_details,
            })

    nearby.sort(key=lambda x: x['distance_m'])
    return nearby[:10]


def scan_hotel_companions(target_phone, hotel_lat, hotel_lng, hotel_name, scan_radius_m=200):
    from wifi_positioning import get_visible_bssids, get_area_aps
    import re as _re

    hotel_bssids = get_visible_bssids(hotel_lat, hotel_lng, max_range_m=250)

    target_clean = _re.sub(r'\D', '', target_phone.replace('+', ''))

    conn = _get_conn()
    rows = conn.execute(
        """SELECT phone, lat AS last_lat, lng AS last_lng, location AS last_location,
                  '' AS carrier, city, timestamp AS last_seen
           FROM (
               SELECT phone, lat, lng, location, city, timestamp,
                      ROW_NUMBER() OVER (PARTITION BY phone ORDER BY timestamp DESC) AS rn
               FROM tracking_history
           ) sub WHERE rn = 1
           UNION
           SELECT phone, last_lat, last_lng, last_location, carrier, city, last_seen
           FROM tracked_phones""").fetchall()
    conn.close()

    seen_phones = {}
    for row in rows:
        p = row['phone']
        p_clean = _re.sub(r'\D', '', p.replace('+', ''))
        if p_clean == target_clean or p_clean.endswith(target_clean[-8:]):
            continue
        if p not in seen_phones or (row['last_seen'] or 0) > (seen_phones[p]['last_seen'] or 0):
            seen_phones[p] = dict(row)
    rows = list(seen_phones.values())

    area_aps = get_area_aps(hotel_lat, hotel_lng, radius_tiles=2)
    bssid_to_ap = {ap['bssid']: ap for ap in area_aps}

    companions = []
    for entry in rows:
        other_lat = entry.get('last_lat')
        other_lng = entry.get('last_lng')
        if other_lat is None or other_lng is None:
            continue

        dist_m = _haversine(hotel_lat, hotel_lng, other_lat, other_lng)
        if dist_m > scan_radius_m:
            continue

        other_bssids = get_visible_bssids(other_lat, other_lng, max_range_m=250)
        shared = hotel_bssids & other_bssids

        if len(shared) >= 1:
            shared_ap_details = []
            for bssid in list(shared)[:8]:
                ap = bssid_to_ap.get(bssid)
                if ap:
                    shared_ap_details.append({
                        'bssid': bssid,
                        'ssid': ap.get('ssid', ''),
                        'lat': ap['lat'],
                        'lng': ap['lng'],
                        'venue': ap.get('venue', ''),
                    })

            contact_info = None
            try:
                p_digits = _re.sub(r'\D', '', entry['phone'].replace('+', ''))
                from tracking_db import get_contact_by_normalized
                contact_info = get_contact_by_normalized(p_digits)
            except Exception:
                pass

            companions.append({
                'phone': entry['phone'],
                'shared_aps': len(shared),
                'distance_m': round(dist_m, 1),
                'distance_to_hotel_m': round(dist_m, 1),
                'lat': other_lat,
                'lng': other_lng,
                'location': entry.get('last_location') or '',
                'carrier': entry.get('carrier') or '',
                'city': entry.get('city') or '',
                'last_seen': entry.get('last_seen'),
                'shared_ap_details': shared_ap_details,
                'contact_name': contact_info.get('name', '') if contact_info else '',
                'contact_owner': contact_info.get('owner_name', '') if contact_info else '',
                'contact_model': contact_info.get('phone_model', '') if contact_info else '',
            })

    companions.sort(key=lambda x: (-x['shared_aps'], x['distance_m']))
    return companions

def record_search(phone, carrier='', city='', lat=None, lng=None, country_code=''):
    conn = _get_conn()
    conn.execute(
        "INSERT INTO search_history (phone, carrier, city, lat, lng, country_code, timestamp) VALUES (?,?,?,?,?,?,?)",
        (phone, carrier, city, lat, lng, country_code, time.time())
    )
    conn.commit()
    conn.close()

def get_recent_searches(limit=10):
    conn = _get_conn()
    rows = conn.execute(
        """SELECT phone, carrier, city, lat, lng, country_code, MAX(timestamp) as last_searched, COUNT(*) as search_count
           FROM search_history GROUP BY phone ORDER BY last_searched DESC LIMIT ?""",
        (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_search_stats():
    conn = _get_conn()
    total = conn.execute("SELECT COUNT(*) FROM search_history").fetchone()[0]
    today_start = time.time() - (time.time() % 86400)
    today = conn.execute("SELECT COUNT(*) FROM search_history WHERE timestamp >= ?", (today_start,)).fetchone()[0]
    top_numbers = conn.execute(
        "SELECT phone, carrier, city, COUNT(*) as cnt FROM search_history GROUP BY phone ORDER BY cnt DESC LIMIT 5"
    ).fetchall()
    daily = conn.execute(
        """SELECT date(timestamp, 'unixepoch') as day, COUNT(*) as cnt
           FROM search_history GROUP BY day ORDER BY day DESC LIMIT 30"""
    ).fetchall()
    locations = conn.execute(
        "SELECT lat, lng, city FROM search_history WHERE lat IS NOT NULL AND lng IS NOT NULL ORDER BY timestamp DESC LIMIT 200"
    ).fetchall()
    conn.close()
    return {
        'total': total,
        'today': today,
        'top_numbers': [dict(r) for r in top_numbers],
        'daily': [dict(r) for r in daily],
        'locations': [dict(r) for r in locations],
    }

def _haversine(lat1, lng1, lat2, lng2):
    R = 6371000
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

init_db()
