"""
Información detallada sobre códigos de área de Honduras y sus coordenadas geográficas.
Coordenadas verificadas contra centros urbanos reales y OpenStreetMap.
"""

HONDURAS_AREA_CODES = {
    '22': {
        'city': 'Tegucigalpa', 
        'latitude': 14.0723, 
        'longitude': -87.1921,
        'region': 'Francisco Morazán'
    },
    '25': {
        'city': 'San Pedro Sula', 
        'latitude': 15.5000, 
        'longitude': -88.0333,
        'region': 'Cortés'
    },
    '24': {
        'city': 'La Ceiba', 
        'latitude': 15.7631, 
        'longitude': -86.7822,
        'region': 'Atlántida'
    },
    '27': {
        'city': 'Comayagua', 
        'latitude': 14.4539, 
        'longitude': -87.6366,
        'region': 'Comayagua'
    },
    '28': {
        'city': 'Choluteca', 
        'latitude': 13.3005, 
        'longitude': -87.1908,
        'region': 'Choluteca'
    },
    '26': {
        'city': 'Santa Rosa de Copán', 
        'latitude': 14.7667, 
        'longitude': -88.7833,
        'region': 'Copán'
    },
    '29': {
        'city': 'Juticalpa', 
        'latitude': 14.6500, 
        'longitude': -86.2167,
        'region': 'Olancho'
    },
    '31': {
        'city': 'Puerto Cortés', 
        'latitude': 15.8383, 
        'longitude': -87.9497,
        'region': 'Cortés'
    },
    '32': {
        'city': 'El Progreso', 
        'latitude': 15.4000, 
        'longitude': -87.8000,
        'region': 'Yoro'
    },
    '33': {
        'city': 'Tela', 
        'latitude': 15.7833, 
        'longitude': -87.4500,
        'region': 'Atlántida'
    },
    '37': {
        'city': 'Siguatepeque', 
        'latitude': 14.6000, 
        'longitude': -87.8333,
        'region': 'Comayagua'
    },
    '36': {
        'city': 'Danlí', 
        'latitude': 14.0333, 
        'longitude': -86.5833,
        'region': 'El Paraíso'
    }
}

HONDURAS_MOBILE_CITIES = {
    'La Lima': {
        'latitude': 15.4333,
        'longitude': -87.9250,
        'region': 'Cortés',
        'department': 'Cortés'
    },
    'Choloma': {
        'latitude': 15.5600,
        'longitude': -87.9544,
        'region': 'Cortés',
        'department': 'Cortés'
    },
    'Villanueva': {
        'latitude': 15.3167,
        'longitude': -87.9833,
        'region': 'Cortés',
        'department': 'Cortés'
    },
    'Roatán': {
        'latitude': 16.3333,
        'longitude': -86.5333,
        'region': 'Islas de la Bahía',
        'department': 'Islas de la Bahía'
    },
    'Tocoa': {
        'latitude': 15.6500,
        'longitude': -85.9833,
        'region': 'Colón',
        'department': 'Colón'
    },
    'Catacamas': {
        'latitude': 14.8000,
        'longitude': -85.9000,
        'region': 'Olancho',
        'department': 'Olancho'
    },
    'Olanchito': {
        'latitude': 15.4833,
        'longitude': -86.5833,
        'region': 'Yoro',
        'department': 'Yoro'
    },
    'La Esperanza': {
        'latitude': 14.3000,
        'longitude': -88.1833,
        'region': 'Intibucá',
        'department': 'Intibucá'
    },
    'Nacaome': {
        'latitude': 13.5333,
        'longitude': -87.4833,
        'region': 'Valle',
        'department': 'Valle'
    },
    'Gracias': {
        'latitude': 14.5833,
        'longitude': -88.5833,
        'region': 'Lempira',
        'department': 'Lempira'
    },
    'Tegucigalpa': {
        'latitude': 14.0723,
        'longitude': -87.1921,
        'region': 'Francisco Morazán',
        'department': 'Francisco Morazán'
    },
    'San Pedro Sula': {
        'latitude': 15.5000,
        'longitude': -88.0333,
        'region': 'Cortés',
        'department': 'Cortés'
    },
    'La Ceiba': {
        'latitude': 15.7631,
        'longitude': -86.7822,
        'region': 'Atlántida',
        'department': 'Atlántida'
    },
    'Comayagua': {
        'latitude': 14.4539,
        'longitude': -87.6366,
        'region': 'Comayagua',
        'department': 'Comayagua'
    },
    'Choluteca': {
        'latitude': 13.3005,
        'longitude': -87.1908,
        'region': 'Choluteca',
        'department': 'Choluteca'
    },
    'Santa Rosa de Copán': {
        'latitude': 14.7667,
        'longitude': -88.7833,
        'region': 'Copán',
        'department': 'Copán'
    },
    'Juticalpa': {
        'latitude': 14.6500,
        'longitude': -86.2167,
        'region': 'Olancho',
        'department': 'Olancho'
    },
    'Puerto Cortés': {
        'latitude': 15.8383,
        'longitude': -87.9497,
        'region': 'Cortés',
        'department': 'Cortés'
    },
    'El Progreso': {
        'latitude': 15.4000,
        'longitude': -87.8000,
        'region': 'Yoro',
        'department': 'Yoro'
    },
    'Tela': {
        'latitude': 15.7833,
        'longitude': -87.4500,
        'region': 'Atlántida',
        'department': 'Atlántida'
    },
    'Siguatepeque': {
        'latitude': 14.6000,
        'longitude': -87.8333,
        'region': 'Comayagua',
        'department': 'Comayagua'
    },
    'Danlí': {
        'latitude': 14.0333,
        'longitude': -86.5833,
        'region': 'El Paraíso',
        'department': 'El Paraíso'
    },
}


def get_honduras_city_location(city_name):
    return HONDURAS_MOBILE_CITIES.get(city_name)

def get_honduras_location(area_code):
    return HONDURAS_AREA_CODES.get(area_code)
