# INGENIERÍA LocalizaHN — Documento Técnico Completo

**Versión:** 2.0  
**Fecha:** Abril 2026  
**Clasificación:** Confidencial — Uso Interno  

---

## 1. RESUMEN EJECUTIVO

LocalizaHN es una aplicación web SaaS de localización de teléfonos móviles en Honduras, construida sobre Flask (Python) con un motor de triangulación Rust/WASM. Utiliza un solver propietario denominado **TriNet-Pythag v2** basado en Gauss-Newton con IRLS (Iteratively Reweighted Least Squares) y kernel Tukey Bisquare para estimar la posición geográfica de un dispositivo móvil a partir de señales de torres celulares BTS.

**Stack tecnológico principal:**
- Backend: Python 3.11 / Flask / Gunicorn
- Motor numérico: Rust → WebAssembly (wasm-bindgen)
- Base de datos: SQLite (WAL mode) — `users.db` + `tracking_data.db`
- Datos de torres: OpenCelliD CSV (CC BY-SA 4.0) — MCC 708 (Honduras), 704 (Guatemala), 310 (US-Louisiana)
- APIs externas: Google Maps Roads API, Google Geocoding API, Google Maps JavaScript API, Mylnikov Cell API, ipgeolocation.io
- Frontend: HTML5 / CSS3 / Canvas API / Bootstrap / Feather Icons

---

## 2. ARQUITECTURA DEL SISTEMA

### 2.1 Diagrama de Componentes

```
┌─────────────────────────────────────────────────────────────────────┐
│                        FRONTEND (Browser)                          │
│  ┌──────────┐  ┌──────────────┐  ┌───────────┐  ┌──────────────┐  │
│  │ index.html│  │ track.html   │  │result.html│  │ account.html │  │
│  │ (búsqueda)│  │(AI loading)  │  │(mapa+HUD) │  │ (perfil)     │  │
│  └─────┬─────┘  └──────┬───────┘  └─────┬─────┘  └──────────────┘  │
│        │               │                │                           │
│  ┌─────┴───────────────┴────────────────┴─────────────────────┐    │
│  │              clonengine.js (969 líneas)                     │    │
│  │  Canvas API: AI processing animation, HUD overlays         │    │
│  └────────────────────────────────────────────────────────────┘    │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │              hud.css (507 líneas)                           │    │
│  │  Visual identity: --hn-blue:#0077C8 --gold:#FFB800         │    │
│  │  --jade:#00D68F  --bg:#060a12                              │    │
│  └────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────┘
                              │ HTTP POST/GET
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      BACKEND (Flask / Gunicorn)                     │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    app.py (1,884 líneas)                     │   │
│  │  Rutas: /, /track, /result, /login, /register, /account,   │   │
│  │         /planes, /upgrade, /donar, /estadisticas,           │   │
│  │         /api/shield/*, /api/track                            │   │
│  │  Lógica: _get_phone_profile(), road-snap perfiles,          │   │
│  │          free search counting, session management            │   │
│  └──────────┬──────────┬──────────────┬────────────┬───────────┘   │
│             │          │              │            │                │
│  ┌──────────▼──┐ ┌─────▼──────┐ ┌────▼─────┐ ┌───▼──────────┐    │
│  │triangulation│ │phone_      │ │cell_     │ │tracking_db   │    │
│  │_engine.py   │ │validator.py│ │towers.py │ │.py (388 lns) │    │
│  │(1,261 lns)  │ │(321 lns)   │ │(670 lns) │ │tracking_data │    │
│  │TriNet-Pythag│ │phonenumbers│ │OpenCelliD│ │.db (SQLite)  │    │
│  │v2 GN-IRLS  │ │lib parsing │ │CSV loader│ │              │    │
│  └──────┬──────┘ └─────┬──────┘ └────┬─────┘ └──────────────┘    │
│         │              │             │                             │
│  ┌──────▼──────┐ ┌─────▼──────┐ ┌────▼──────────────┐            │
│  │wifi_        │ │cellid_     │ │opencellid_etl.py  │            │
│  │positioning  │ │lookup.py   │ │(569 lns) CSV ETL  │            │
│  │.py (410 lns)│ │(211 lns)   │ │import/export/stats│            │
│  │WiFi AP sim  │ │Mylnikov API│ │MCC 708/704/310    │            │
│  └─────────────┘ └────────────┘ └────┬──────────────┘            │
│                                      │                            │
│  ┌───────────────────────────────────▼────────────────────────┐   │
│  │                    data/ (CSV files)                        │   │
│  │  towers_708.csv (557 rows, 82KB) — Honduras                │   │
│  │  towers_704.csv (34 rows, 4KB)  — Guatemala                │   │
│  │  towers_310.csv (67 rows, 9KB)  — US Louisiana             │   │
│  └────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    models.py (344 líneas)                    │   │
│  │  SQLite users.db: users, payments, protected_numbers        │   │
│  │  Planes: none → localizador($5.99) → premium($9.99)        │   │
│  └─────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   RUST / WASM ENGINE                                │
│  rust_triangulation/src/lib.rs (415 líneas)                        │
│  Structs: Tower, BakeIn, TowerDistance, TriangulationResult,       │
│           PingResult, SNNState                                      │
│  Funciones: triangulate(), ping_tower(), snn_update()              │
│  Pascal's Triangle cached weighting, Q6 quantization               │
│  Compilación: wasm-pack build --target web                          │
└─────────────────────────────────────────────────────────────────────┘
```

### 2.2 Flujo de Solicitud de Localización

```
Usuario → POST /track (número de teléfono)
  │
  ├─ 1. phone_validator.validate_phone_number("+504XXXXXXXX")
  │     → phonenumbers parse → carrier detection → area code lookup
  │     → honduras_area_codes / guatemala_area_codes
  │
  ├─ 2. cell_towers.resolve_carrier(carrier_name)
  │     → CARRIER_MAPPING lookup → carrier_key (tigo/claro/digicel)
  │
  ├─ 3. cell_towers.get_all_towers_for_city(country_code, city)
  │     → CARRIER_TOWER_MAP → towers from CSV data
  │
  ├─ 4. cellid_lookup.lookup_cell_location(phone, carrier, "HN", city)
  │     → phone_to_cell_id → parse_cell_id (eNodeB/sector)
  │     → determine_lac_from_city → TIGO_LACS/CITY_TO_LAC
  │     → lookup_mylnikov (Mylnikov API, cached)
  │
  ├─ 5. wifi_positioning.estimate_wifi_position(lat, lng, phone)
  │     → simulated WiFi AP scan → weighted centroid
  │
  ├─ 6. triangulation_engine.triangulate(towers, lat, lng, phone, ...)
  │     │
  │     ├─ 6a. simulate_cell_connection() — RSSI/RSRP/RSRQ/TA
  │     ├─ 6b. Vigesimal quantization (20 niveles)
  │     ├─ 6c. Quality gate filtering
  │     ├─ 6d. Triangle motif classification (ISO/SCALE/CROSS)
  │     ├─ 6e. Phase 1: All-triples trilateration
  │     ├─ 6f. Phase 2: Radial refinement (8 directions × 3 radii)
  │     ├─ 6g. GN-IRLS solver (5 IRLS rounds × 40 GN iterations)
  │     │       → Tukey Bisquare M-estimator with asymmetric c-threshold
  │     ├─ 6h. Bilateral resonance adjustment
  │     ├─ 6i. WiFi fusion (inverse-variance weighting)
  │     ├─ 6j. GDOP computation
  │     └─ 6k. _snap_to_land() → water check → road snap
  │
  ├─ 7. _get_phone_profile(phone) — simulated movement profile
  │     → home + places (mall, work, park, etc.) road-snapped
  │
  └─ 8. Render result.html → Google Maps + Canvas HUD animation
        → 3 BTS towers, street grid, user dot on road waypoints
```

---

## 3. MOTOR DE TRIANGULACIÓN — TriNet-Pythag v2

### 3.1 Modelo de Señal

Cada torre BTS genera un vector de observación:

| Campo | Descripción | Rango típico |
|-------|-------------|--------------|
| RSSI | Intensidad de señal recibida | -120 a -40 dBm |
| RSRP | Reference Signal Received Power | -140 a -44 dBm |
| RSRQ | Reference Signal Received Quality | -20 a -3 dB |
| TA | Timing Advance | 0 a 1282 µs |
| est_distance | Distancia estimada torre→dispositivo | 50 a 35,000 m |

**Modelo de propagación (path loss):**
```
distance = 10^((tx_power - rssi) / (10 × n)) × λ/(4π)
```
Donde `n` es el exponente de propagación (2.0 urbano denso → 4.5 rural) y `λ` depende de la banda (850/1900/2100 MHz).

### 3.2 Cuantización Vigesimal

El motor utiliza cuantización vigesimal (base-20) para normalizar observaciones:

```python
def quant_vigesimal(value, min_v, max_v):
    norm = clamp((value - min_v) / (max_v - min_v), 0, 1)
    level = min(19, int(norm * 20))
    return level
```

Símbolos vigesimales: `◎ • •• ••• •••• ━ ━• ━•• ━••• ━•••• ━━ ━━• ━━•• ━━••• ━━•••• ━━━ ━━━• ━━━•• ━━━••• ━━━••••`

Pesos de señal: `w = 0.05 + (level/19) × 0.95`

### 3.3 Solver GN-IRLS con Tukey Bisquare

El corazón del motor es un solver no-lineal de mínimos cuadrados robusto:

**Gauss-Newton con Levenberg-Marquardt damping:**
```
(JᵀWJ + λI) · δ = JᵀWr

donde:
  J = Jacobiano [∂residual/∂x, ∂residual/∂y] por torre
  W = diagonal de pesos IRLS
  r = vector de residuales (dist_observada - radio_torre)
  λ = factor de regularización (adaptivo: ×0.33 si mejora, ×ν si no)
```

**IRLS (5 rondas):**
Después de cada ronda GN, se recalculan los pesos usando el M-estimador Tukey Bisquare:

```python
sigma = max(median_abs_residual × 1.4826, 10.0)
c_threshold = (6.0 - irls_round × 0.263) × sigma  # decreasing

# Asimétrico: penaliza más los residuales positivos (torre muy lejos)
if residual > 0:
    asym_c = c_threshold × 0.7
else:
    asym_c = c_threshold

norm_r = |residual| / asym_c
tukey_weight = (1 - norm_r²)² if norm_r ≤ 1 else 0
final_weight = base_weight × max(tukey_weight, 0.001)
```

**Multi-start:** El solver se ejecuta desde los mejores 10 candidatos de la fase de refinamiento radial, seleccionando la solución con menor costo total.

### 3.4 Pipeline de Selección de Candidatos

```
Fase 0: Quality Gate
  → Cada torre recibe score QG = f(vig_dist, vig_rsrp, range_km, timing_advance)
  → Torres con QG < 0.1 son penalizadas

Fase 1: Trilateración por tripletes
  → Top 8 torres por peso → C(8,3) = 56 tripletes
  → Cada triplete: clasificación de motif (isósceles/escaleno/cruzado)
  → Boost factor: isósceles 1.25, escaleno 1.0, cruzado 1.5
  → Score: Huber loss (δ=50m) ponderado por peso de torre

Fase 2: Refinamiento radial
  → Top 12 candidatos × 24 puntos de sondeo (8 ángulos × 3 radios: 10%, 20%, 35%)
  → Re-score todos los puntos → top 10

Fase 3: GN-IRLS (descrito arriba)
  → 10 inicios × 5 IRLS × 40 GN = 2,000 iteraciones máximo

Fase 4: Resonancia bilateral
  → Ajuste fino basado en coherencia inter-torre
  → coupling = 0.25
```

### 3.5 Clasificación de Motifs Triangulares

```python
MOTIF_ISO = 'isosceles'    # boost 1.25 — distribución equilibrada
MOTIF_SCALE = 'scalene'    # boost 1.00 — distribución desigual
MOTIF_CROSS = 'cross'      # boost 1.50 — cobertura cruzada
```

Se clasifican según la relación entre las distancias de los lados del triángulo formado por 3 torres, favoreciendo geometrías que maximizan la diversidad angular (mejor GDOP).

### 3.6 Fusión WiFi

Cuando se dispone de datos WiFi (APs detectados ≥ 3):

```
σ_cell = max(avg_residual × GDOP / √n_towers, 10)
σ_wifi = max(wifi_accuracy × max(0.5, 3/n_aps), 5)

w_cell = 1/σ_cell²
w_wifi = 1/σ_wifi²

lat_final = (w_cell × lat_cell + w_wifi × lat_wifi) / (w_cell + w_wifi)
lng_final = (w_cell × lng_cell + w_wifi × lng_wifi) / (w_cell + w_wifi)
```

### 3.7 GDOP (Geometric Dilution of Precision)

```python
def compute_gdop(tower_positions, est_x, est_y):
    H = [[dx/d, dy/d] for each tower]
    G = (HᵀH)⁻¹
    gdop = sqrt(trace(G))
```

GDOP < 2.0: excelente | 2-5: bueno | 5-10: moderado | >10: pobre

### 3.8 Validación Geoespacial

**Pipeline _snap_to_land():**

```
1. Verificación de agua (HONDURAS_WATER_BODIES: 5 cuerpos)
   → Lago de Yojoa, Laguna de Caratasca, Golfo de Fonseca,
     Mar Caribe Honduras Norte, Laguna de Guaimoreto

2. Anchor a ciudad más cercana (HONDURAS_CITIES: 32 ciudades)
   → Snap a <80km con offset aleatorio determinista

3. Road snap primario: Google Roads API
   → snapToRoads?path={lat},{lng}&interpolate=true
   → Cache: _ROAD_SNAP_CACHE (por lat,lng redondeado a 4 decimales)
   → Máximo desplazamiento: 3km

4. Road snap fallback: Google Geocoding API (reverse)
   → result_type=route|street_address
   → Máximo desplazamiento: 2km

5. Si ningún snap funciona → coordenadas del anchor
```

---

## 4. DATOS DE TORRES CELULARES

### 4.1 Fuente y Licencia

| Campo | Valor |
|-------|-------|
| Fuente | OpenCelliD community database |
| URL | https://opencellid.org |
| Licencia | CC BY-SA 4.0 |
| Formato | CSV (OpenCelliD cell_towers.csv schema) |

### 4.2 Inventario de Torres

| MCC | País | Archivo | Torres | Tamaño |
|-----|------|---------|--------|--------|
| 708 | Honduras | towers_708.csv | ~550 | 82 KB |
| 704 | Guatemala | towers_704.csv | ~30 | 4 KB |
| 310 | US (Louisiana) | towers_310.csv | ~63 | 9 KB |

### 4.3 Operadores Soportados

**Honduras (MCC 708):**
| MNC | Operador | Carrier Key | Bandas LTE | Market Share |
|-----|----------|-------------|------------|-------------|
| 2 | Tigo (Millicom) | tigo | B4 (AWS 2100), B5 (CLR 850) | 60% |
| 1 | Claro (América Móvil) | claro | B4 (AWS 2100) | 39% |
| 40 | Digicel (inactivo desde 2011) | digicel | — | 0% |

**Guatemala (MCC 704):**
| MNC | Operador | Carrier Key |
|-----|----------|-------------|
| 1 | Tigo | tigo |
| 3 | Claro | claro |

**US Louisiana (MCC 310):**
| MNC | Operador | Carrier Key |
|-----|----------|-------------|
| 410 | AT&T | att |
| 260 | T-Mobile | tmobile |
| 12 | Verizon | verizon |

### 4.4 Schema CSV Extendido

```
radio,mcc,mnc,lac,cid,unit,lon,lat,range,samples,changeable,created,updated,averageSignal,cell_id,enodeb,band,tech,power_dbm,source,carrier,city,country
```

### 4.5 Enriquecimiento de Torres

Cada torre se enriquece con metadata de banda/frecuencia:

| Band | EARFCN | Freq (MHz) | Radio |
|------|--------|-----------|-------|
| B2 | 900 | 1900 | LTE |
| B4 | 2050 | 2100 | LTE |
| B5 | 2543 | 883 | LTE |
| B12 | 5095 | 700 | LTE |
| GSM850 | 190 | 850 | GSM |
| GSM1900 | 661 | 1900 | GSM |
| UMTS850 | 4357 | 850 | UMTS |
| UMTS1900 | 9662 | 1900 | UMTS |

---

## 5. MOTOR RUST / WASM

### 5.1 Arquitectura

```
rust_triangulation/
├── Cargo.toml          # wasm-bindgen, serde, serde_json
├── src/
│   └── lib.rs          # 415 líneas
└── pkg/                # wasm-pack output (no committed)
```

### 5.2 Estructuras de Datos

```rust
struct Tower { id, lat, lng, range_km, power_dbm }
struct BakeIn { cos_lat, sin_lat, m_per_lng, center_lat, center_lng }
struct TowerDistance { tower_id, distance_m, radius_m, vig_level, vig_category, q6_signal, tower_lat, tower_lng }
struct TriangulationResult { lat, lng, confidence, pascal_confidence, accuracy_meters, tower_distances, bake_in, pascal_weights, computation_ms }
struct PingResult { latency_ms, estimated_distance_km, q6_latency, vig_distance, confidence_adjustment, timing }
struct SNNState { reactivo_q6, analitico_q6, pascal_q6, neat_gen, reactivo_pct, analitico_pct, pascal_pct }
```

### 5.3 Pascal's Triangle Weighting

El motor WASM implementa ponderación usando filas de Pascal's Triangle como distribuciones de peso simétricas para las torres participantes. Se cachea globalmente para evitar recálculo.

### 5.4 Cuantización Q6

Señales se cuantizan a 6 bits (0-63) para transmisión eficiente:
```rust
const Q6_MAX: u32 = 63;
```

---

## 6. BASE DE DATOS

### 6.1 users.db (SQLite, WAL mode)

**Tabla `users`:**
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    active_plan TEXT DEFAULT 'none',    -- none/localizador/premium
    stripe_customer_id TEXT,
    stripe_subscription_id TEXT,
    subscription_start REAL,
    subscription_end REAL,
    free_searches_used INTEGER DEFAULT 0,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
```

**Tabla `payments`:**
```sql
CREATE TABLE payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    stripe_payment_id TEXT,
    amount REAL NOT NULL,
    currency TEXT DEFAULT 'usd',
    plan TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at REAL NOT NULL
);
```

**Tabla `protected_numbers` (Escudo Anti-Localización):**
```sql
CREATE TABLE protected_numbers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    phone_number TEXT NOT NULL,
    label TEXT DEFAULT '',
    created_at REAL NOT NULL
);
```

### 6.2 tracking_data.db (SQLite)

**Tablas:**
- `tracking_history` — historial de localizaciones
- `tracked_phones` — teléfonos rastreados con metadata
- `contacts` — directorio de contactos (Premium)
- `search_history` — bitácora de búsquedas

---

## 7. MODELO DE NEGOCIO SaaS

### 7.1 Planes de Suscripción

| Plan | Precio | Límites | Características |
|------|--------|---------|-----------------|
| Gratis | $0 | 2 búsquedas totales | Localización básica |
| Localizador | $5.99/mes | Ilimitadas | Localización + carrier + zona en mapa + historial 7 días |
| Premium | $9.99/mes | Ilimitadas | Todo Localizador + Estudio de Zona + Escudo Anti-Localización + rastreo en vivo + alertas + mapa de calor + historial 30 días + directorio |

### 7.2 Escudo Anti-Localización (Premium)

Números registrados como protegidos devuelven `shield_blocked.html` cuando alguien intenta localizarlos. La página muestra una animación SVG de circuito con estilo Honduras.

### 7.3 Estudio de Zona (Premium)

Análisis del área circundante al dispositivo localizado: moteles, bares, restaurantes y puntos de interés cercanos.

---

## 8. FRONTEND

### 8.1 Identidad Visual

```css
:root {
    --bg: #060a12;           /* fondo oscuro profundo */
    --hn-blue: #0077C8;      /* cerúleo Honduras */
    --gold: #FFB800;         /* dorado */
    --jade: #00D68F;         /* jade verde */
    --text: #e0e6ed;         /* texto claro */
}
```

### 8.2 Pantalla de Procesamiento AI (track.html → clonengine.js)

Animación Canvas de ~7 segundos con fases progresivas:
1. Conexión a red celular
2. Identificación de portador
3. Triangulación de señal
4. Análisis geoespacial
5. Precisión de coordenadas

`window._mapReady` flag + `dismissLoading()` con failsafe de 10 segundos.

### 8.3 Visualización de Resultado (result.html)

**Canvas HUD superpuesto al mapa Google:**
- Mini ciudad con 8 segmentos de calles
- 3 torres BTS fijas con líneas de rastreo punteadas
- Dot de usuario moviéndose por 18 waypoints de ruta
- Trail history con opacidad decreciente
- Transición de fase: azul → verde en lock (fase 5)

**Google Maps:**
- Marcador de posición con InfoWindow
- Círculo de precisión (radio = accuracy_meters)
- Mapa estilo dark mode

### 8.4 Templates

| Archivo | Líneas | Función |
|---------|--------|---------|
| base.html | 29 | Layout base con Bootstrap/Feather Icons |
| index.html | — | Página principal, formulario de búsqueda |
| track.html | 1,314 | Pantalla AI processing con Canvas |
| result.html | 736 | Mapa + HUD + datos técnicos |
| login.html | — | Inicio de sesión |
| register.html | — | Registro de usuario |
| account.html | 293 | Perfil con gold aura effect |
| planes.html | — | Comparación de planes |
| upgrade.html | — | Upgrade de suscripción |
| shield_blocked.html | 214 | Escudo Anti-Localización SVG animation |
| limit_reached.html | — | Límite de búsquedas gratuitas |
| estadisticas.html | — | Dashboard de estadísticas |
| donar.html | — | Página de donaciones |

---

## 9. APIs EXTERNAS

### 9.1 Google Maps Platform

| API | Uso | Endpoint |
|-----|-----|----------|
| Roads API | Road-snap de coordenadas | `roads.googleapis.com/v1/snapToRoads` |
| Geocoding API | Reverse geocode fallback | `maps.googleapis.com/maps/api/geocode/json` |
| Maps JavaScript API | Renderizado de mapa en result.html | Client-side |

**Variables de entorno:** `GOOGLE_MAPS_API_KEY`

### 9.2 Mylnikov Cell API

| Campo | Valor |
|-------|-------|
| URL | `api.mylnikov.org/geolocation/cell` |
| Método | GET con parámetros mcc, mnc, lac, cellid |
| Uso | Lookup de ubicación de celda por LAC/CellID |
| Cache | `MYLNIKOV_CACHE` en memoria |

### 9.3 ipgeolocation.io

| Campo | Valor |
|-------|-------|
| Uso | Información de geolocalización por IP (legacy) |
| Variable | `IPGEOLOCATION_API_KEY` |
| Estado | Fallback; endpoint puede estar no disponible |

---

## 10. CELL ID RESOLUTION

### 10.1 Estructura de Cell ID (LTE)

```
Cell ID (32-bit) = eNodeB ID (20-bit) × 256 + Sector ID (8-bit)

Ejemplo: CID = 39176192
  eNodeB = 39176192 / 256 = 153032
  Sector  = 39176192 % 256 = 0
```

### 10.2 LAC (Location Area Code) Mapping

Honduras tiene 35+ LACs mapeados a departamentos y ciudades. Ejemplo:

| LAC | Nombre | Ciudades |
|-----|--------|----------|
| 17 | Cortés Norte | SPS, La Lima, Choloma, Villanueva |
| 25 | Francisco Morazán | Tegucigalpa, Comayagüela |
| 40 | Islas de la Bahía | Roatán, Guanaja, Utila |
| 11 | Atlántida Norte | La Ceiba |

### 10.3 Detección de Carrier por Prefijo Móvil

```python
HN_MOBILE_PREFIXES = {"9": "tigo", "8": "tigo", "3": "claro"}
GT_MOBILE_PREFIXES = {"5": "tigo", "4": "claro", "3": "claro"}
```

---

## 11. DEPARTAMENTOS DE HONDURAS

El sistema mapea los 18 departamentos con sus ciudades principales (HN_DEPARTMENTS en cell_towers.py, 333 líneas):

Atlántida, Colón, Comayagua, Copán, Cortés, Choluteca, El Paraíso, Francisco Morazán, Gracias a Dios, Intibucá, Islas de la Bahía, La Paz, Lempira, Ocotepeque, Olancho, Santa Bárbara, Valle, Yoro.

Total de ciudades mapeadas: 150+

---

## 12. WIFI POSITIONING MODULE

### 12.1 Simulación de APs WiFi

`wifi_positioning.py` (410 líneas) simula la detección de Access Points WiFi cercanos a la posición estimada:

- Generación determinista basada en seed del teléfono
- 3-8 APs simulados con BSSID, SSID, canal, señal
- Ponderación por intensidad de señal
- Centroide ponderado → posición WiFi

### 12.2 Parámetros

| Parámetro | Valor |
|-----------|-------|
| APs mínimos | 3 |
| Radio de detección | ~200m |
| Accuracy típica | 15-50m |

---

## 13. SEGURIDAD

### 13.1 Autenticación

- Contraseñas hasheadas con `werkzeug.security.generate_password_hash` (default: scrypt)
- Sesiones Flask con `SESSION_SECRET` desde variable de entorno
- `free_searches_used` tracking por usuario

### 13.2 Protección de Números (Escudo)

- Tabla `protected_numbers` con FK a `users`
- Verificación en cada búsqueda: si el número está protegido → redirect a `shield_blocked.html`
- Solo disponible para usuarios Premium

### 13.3 Variables de Entorno

| Variable | Uso |
|----------|-----|
| SESSION_SECRET | Flask session encryption |
| GOOGLE_MAPS_API_KEY | Google Maps/Roads/Geocoding APIs |
| IPGEOLOCATION_API_KEY | IP geolocation (fallback) |

---

## 14. DEPLOYMENT

### 14.1 Configuración

```bash
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
```

### 14.2 Dependencias Python

- Flask, gunicorn
- phonenumbers
- requests
- werkzeug

### 14.3 Dependencias Rust (Cargo.toml)

- wasm-bindgen
- serde, serde_json
- Compilación: `wasm-pack build --target web`

---

## 15. INVENTARIO DE ARCHIVOS FUENTE

| Archivo | Líneas | Descripción |
|---------|--------|-------------|
| app.py | 1,884 | Aplicación Flask principal, rutas, lógica de negocio |
| triangulation_engine.py | 1,261 | Motor TriNet-Pythag v2 GN-IRLS |
| cell_towers.py | 670 | Carga y gestión de torres celulares |
| opencellid_etl.py | 569 | ETL pipeline para datos OpenCelliD |
| wifi_positioning.py | 410 | Módulo de posicionamiento WiFi |
| tracking_db.py | 388 | Base de datos de tracking |
| models.py | 344 | Modelos de usuario y pagos |
| phone_validator.py | 321 | Validación de números telefónicos |
| cellid_lookup.py | 211 | Resolución de Cell ID vía Mylnikov |
| honduras_area_codes.py | 221 | Códigos de área Honduras con coordenadas |
| guatemala_area_codes.py | 57 | Códigos de área Guatemala |
| main.py | ~10 | Entry point |
| static/js/clonengine.js | 969 | Motor Canvas de animación AI |
| static/js/script.js | 230 | Scripts generales |
| static/css/hud.css | 507 | Estilos HUD y visual identity |
| static/css/styles.css | 32 | Estilos generales |
| rust_triangulation/src/lib.rs | 415 | Motor WASM Rust |
| templates/ (13 archivos) | ~3,500 | Templates HTML |
| data/ (3 CSVs) | 658 | Datos de torres celulares |
| **TOTAL** | **~12,000+** | |

---

## 16. GLOSARIO TÉCNICO

| Término | Definición |
|---------|-----------|
| BTS | Base Transceiver Station — torre celular |
| eNodeB | Evolved Node B — estación base LTE |
| LAC | Location Area Code — código de área de localización |
| CID | Cell ID — identificador único de celda |
| MCC | Mobile Country Code (708=Honduras, 704=Guatemala) |
| MNC | Mobile Network Code (2=Tigo HN, 1=Claro HN) |
| EARFCN | E-UTRA Absolute Radio Frequency Channel Number |
| RSSI | Received Signal Strength Indicator |
| RSRP | Reference Signal Received Power |
| RSRQ | Reference Signal Received Quality |
| TA | Timing Advance — delay de propagación |
| GDOP | Geometric Dilution of Precision |
| GN-IRLS | Gauss-Newton con Iteratively Reweighted Least Squares |
| WASM | WebAssembly |
| Q6 | Cuantización a 6 bits (0-63) |
| SNN | Simulated Neural Network state |

---

*Documento generado automáticamente. Propiedad intelectual de LocalizaHN.*
