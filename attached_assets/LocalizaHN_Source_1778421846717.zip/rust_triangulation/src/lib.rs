use wasm_bindgen::prelude::*;
use serde::{Serialize, Deserialize};
use std::f64::consts::PI;

const DEG2RAD: f64 = PI / 180.0;
const M_PER_DEG: f64 = 111320.0;
const VIG_LEVELS: u32 = 20;
const Q6_MAX: u32 = 63;
const HIST_SIZE: usize = 5;
const ARC_LEN: f64 = 50.3;

#[wasm_bindgen]
extern "C" {
    #[wasm_bindgen(js_namespace = performance, js_name = now)]
    fn performance_now() -> f64;
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Tower {
    pub id: String,
    pub lat: f64,
    pub lng: f64,
    pub range_km: f64,
    pub power_dbm: f64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct BakeIn {
    pub cos_lat: f64,
    pub sin_lat: f64,
    pub m_per_lng: f64,
    pub center_lat: f64,
    pub center_lng: f64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct TowerDistance {
    pub tower_id: String,
    pub distance_m: f64,
    pub radius_m: f64,
    pub vig_level: u32,
    pub vig_category: String,
    pub q6_signal: u32,
    pub tower_lat: f64,
    pub tower_lng: f64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct TriangulationResult {
    pub lat: f64,
    pub lng: f64,
    pub confidence: f64,
    pub pascal_confidence: f64,
    pub accuracy_meters: f64,
    pub tower_distances: Vec<TowerDistance>,
    pub bake_in: BakeIn,
    pub pascal_weights: Vec<f64>,
    pub computation_ms: f64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct PingResult {
    pub latency_ms: f64,
    pub estimated_distance_km: f64,
    pub q6_latency: u32,
    pub vig_distance: u32,
    pub confidence_adjustment: f64,
    pub timing: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct SNNState {
    pub reactivo_q6: u32,
    pub analitico_q6: u32,
    pub pascal_q6: u32,
    pub neat_gen: u32,
    pub reactivo_pct: f64,
    pub analitico_pct: f64,
    pub pascal_pct: f64,
}

static mut PASCAL_CACHE: Option<Vec<(usize, Vec<f64>)>> = None;
static mut INTENSITY_HISTORY: Option<Vec<Vec<f64>>> = None;
static mut NEAT_GEN: u32 = 0;

fn get_pascal(n: usize) -> Vec<f64> {
    unsafe {
        if PASCAL_CACHE.is_none() {
            PASCAL_CACHE = Some(Vec::new());
        }
        let cache = PASCAL_CACHE.as_ref().unwrap();
        for (k, row) in cache.iter() {
            if *k == n { return row.clone(); }
        }
    }
    let mut row: Vec<f64> = vec![1.0];
    for _ in 1..=n {
        let mut nx = vec![1.0];
        for j in 1..row.len() {
            nx.push(row[j-1] + row[j]);
        }
        nx.push(1.0);
        row = nx;
    }
    let s: f64 = row.iter().sum();
    let normalized: Vec<f64> = row.iter().map(|v| v / s).collect();
    unsafe {
        if let Some(cache) = PASCAL_CACHE.as_mut() {
            cache.push((n, normalized.clone()));
        }
    }
    normalized
}

fn quant_vig(value: f64, min: f64, max: f64) -> u32 {
    if (max - min).abs() < 1e-10 { return 0; }
    let norm = ((value - min) / (max - min)).clamp(0.0, 1.0);
    (norm * (VIG_LEVELS - 1) as f64).round() as u32
}

fn dequant_vig(level: u32, min: f64, max: f64) -> f64 {
    min + (level as f64 / (VIG_LEVELS - 1) as f64) * (max - min)
}

fn quant6(pct: f64) -> u32 {
    ((pct / 100.0) * Q6_MAX as f64).round().clamp(0.0, Q6_MAX as f64) as u32
}

fn dequant6(q: u32) -> f64 {
    (q as f64 * (100.0 / Q6_MAX as f64)).round()
}

fn pythagoras_dist(lat1: f64, lng1: f64, lat2: f64, lng2: f64, cos_lat: f64) -> f64 {
    let dlat = (lat2 - lat1) * M_PER_DEG;
    let dlng = (lng2 - lng1) * M_PER_DEG * cos_lat;
    (dlat * dlat + dlng * dlng).sqrt()
}

fn smooth_intensity(tower_idx: usize, new_val: f64) -> f64 {
    unsafe {
        if INTENSITY_HISTORY.is_none() {
            INTENSITY_HISTORY = Some(Vec::new());
        }
        let hist = INTENSITY_HISTORY.as_mut().unwrap();
        while hist.len() <= tower_idx {
            hist.push(Vec::new());
        }
        let h = &mut hist[tower_idx];
        h.push(new_val);
        if h.len() > HIST_SIZE { h.remove(0); }
        h.iter().sum::<f64>() / h.len() as f64
    }
}

fn vig_category(level: u32) -> String {
    match level {
        0..=3 => "EXCELENTE".to_string(),
        4..=7 => "BUENA".to_string(),
        8..=11 => "MODERADA".to_string(),
        12..=15 => "BAJA".to_string(),
        _ => "MUY BAJA".to_string(),
    }
}

#[wasm_bindgen]
pub fn init_engine() {
    unsafe {
        PASCAL_CACHE = Some(Vec::new());
        INTENSITY_HISTORY = Some(Vec::new());
        NEAT_GEN = 0;
    }
    for d in [3, 4, 5, 6, 7] {
        get_pascal(d);
    }
}

#[wasm_bindgen]
pub fn triangulate(towers_json: &str, center_lat: f64, center_lng: f64) -> String {
    let start = performance_now();

    let towers: Vec<Tower> = match serde_json::from_str(towers_json) {
        Ok(t) => t,
        Err(e) => return serde_json::to_string(&serde_json::json!({"error": e.to_string()})).unwrap(),
    };

    if towers.len() < 3 {
        return serde_json::to_string(&serde_json::json!({"error": "Need at least 3 towers"})).unwrap();
    }

    let cos_lat = (center_lat * DEG2RAD).cos();
    let sin_lat = (center_lat * DEG2RAD).sin();
    let m_per_lng = M_PER_DEG * cos_lat;

    let bake_in = BakeIn {
        cos_lat, sin_lat, m_per_lng, center_lat, center_lng,
    };

    let mut tower_dists: Vec<(usize, f64)> = towers.iter().enumerate()
        .map(|(i, t)| (i, pythagoras_dist(center_lat, center_lng, t.lat, t.lng, cos_lat)))
        .collect();
    tower_dists.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

    let best_3: Vec<usize> = tower_dists.iter().take(3).map(|(i, _)| *i).collect();

    struct Circle { x: f64, y: f64, r: f64, dist: f64, idx: usize }
    let circles: Vec<Circle> = best_3.iter().map(|&i| {
        let t = &towers[i];
        let dist = pythagoras_dist(center_lat, center_lng, t.lat, t.lng, cos_lat);
        let signal_factor = (1.0 - (t.power_dbm.abs() - 50.0) / 80.0).clamp(0.3, 1.0);
        let smoothed = smooth_intensity(i, signal_factor);
        let radius = t.range_km * 1000.0 * 0.7 * smoothed;
        Circle {
            x: (t.lng - center_lng) * m_per_lng,
            y: (t.lat - center_lat) * M_PER_DEG,
            r: radius,
            dist,
            idx: i,
        }
    }).collect();

    let (tri_lat, tri_lng) = if circles.len() >= 3 {
        let (c1, c2, c3) = (&circles[0], &circles[1], &circles[2]);
        let a1 = 2.0 * (c2.x - c1.x);
        let b1 = 2.0 * (c2.y - c1.y);
        let d1 = c1.r.powi(2) - c2.r.powi(2) - c1.x.powi(2) + c2.x.powi(2) - c1.y.powi(2) + c2.y.powi(2);
        let a2 = 2.0 * (c3.x - c2.x);
        let b2 = 2.0 * (c3.y - c2.y);
        let d2 = c2.r.powi(2) - c3.r.powi(2) - c2.x.powi(2) + c3.x.powi(2) - c2.y.powi(2) + c3.y.powi(2);
        let denom = a1 * b2 - a2 * b1;
        if denom.abs() > 1e-10 {
            let px = (d1 * b2 - d2 * b1) / denom;
            let py = (a1 * d2 - a2 * d1) / denom;
            (center_lat + py / M_PER_DEG, center_lng + px / m_per_lng)
        } else {
            let avg_lat = best_3.iter().map(|&i| towers[i].lat).sum::<f64>() / 3.0;
            let avg_lng = best_3.iter().map(|&i| towers[i].lng).sum::<f64>() / 3.0;
            (avg_lat, avg_lng)
        }
    } else {
        (center_lat, center_lng)
    };

    let max_dist = circles.iter().map(|c| c.dist).fold(0.0f64, |a, b| a.max(b)) * 1.2;
    let tower_distances: Vec<TowerDistance> = circles.iter().map(|c| {
        let t = &towers[c.idx];
        let vig = quant_vig(c.dist, 0.0, max_dist);
        let signal_pct = (1.0 - c.dist / (t.range_km * 1000.0)).clamp(0.0, 1.0) * 100.0;
        TowerDistance {
            tower_id: t.id.clone(),
            distance_m: (c.dist * 100.0).round() / 100.0,
            radius_m: (c.r * 100.0).round() / 100.0,
            vig_level: vig,
            vig_category: vig_category(vig),
            q6_signal: quant6(signal_pct),
            tower_lat: t.lat,
            tower_lng: t.lng,
        }
    }).collect();

    let max_radius = circles.iter().map(|c| c.r).fold(0.0f64, |a, b| a.max(b));
    let avg_dist = circles.iter().map(|c| c.dist).sum::<f64>() / circles.len() as f64;
    let confidence = (100.0 - (avg_dist / max_radius) * 30.0).clamp(0.0, 100.0);
    let confidence_q6 = quant6(confidence);
    let confidence_final = dequant6(confidence_q6);

    let pascal_w = get_pascal(5);
    let mut pascal_sum = 0.0;
    let mut weight_sum = 0.0;
    for (i, td) in tower_distances.iter().enumerate() {
        if i < pascal_w.len() {
            pascal_sum += pascal_w[i] * (100.0 - td.distance_m / 100.0);
            weight_sum += pascal_w[i];
        }
    }
    let pascal_confidence = if weight_sum > 0.0 {
        (pascal_sum / weight_sum).clamp(0.0, 100.0)
    } else { 0.0 };

    let elapsed_ms = performance_now() - start;

    let result = TriangulationResult {
        lat: (tri_lat * 1e6).round() / 1e6,
        lng: (tri_lng * 1e6).round() / 1e6,
        confidence: confidence_final,
        pascal_confidence: (pascal_confidence * 10.0).round() / 10.0,
        accuracy_meters: (avg_dist * 0.4 * 100.0).round() / 100.0,
        tower_distances,
        bake_in,
        pascal_weights: pascal_w,
        computation_ms: (elapsed_ms * 1000.0).round() / 1000.0,
    };

    serde_json::to_string(&result).unwrap()
}

#[wasm_bindgen]
pub fn process_ping_signal(latency_ms: f64) -> String {
    let speed_of_light_km_ms = 299.792458;
    let fiber_factor = 0.66;
    let estimated_distance_km = latency_ms * speed_of_light_km_ms * fiber_factor / 2.0;

    let q6_lat = quant6((latency_ms * 2.0).clamp(0.0, 100.0));
    let vig_dist = quant_vig(estimated_distance_km, 0.0, 5000.0);

    let confidence_adjustment = if latency_ms < 5.0 {
        5.0
    } else if latency_ms < 20.0 {
        2.0
    } else if latency_ms < 50.0 {
        0.0
    } else if latency_ms < 100.0 {
        -3.0
    } else {
        -8.0
    };

    let result = PingResult {
        latency_ms: (latency_ms * 1000.0).round() / 1000.0,
        estimated_distance_km: (estimated_distance_km * 100.0).round() / 100.0,
        q6_latency: q6_lat,
        vig_distance: vig_dist,
        confidence_adjustment,
        timing: "performance.now() (sub-millisecond)".to_string(),
    };

    serde_json::to_string(&result).unwrap()
}

#[wasm_bindgen]
pub fn tick_snn() -> String {
    unsafe {
        NEAT_GEN += 1;

        let now = performance_now();
        let seed1 = ((now * 13.7) % 12.0) as f64;
        let seed2 = ((now * 7.3) % 28.0) as f64;
        let seed3 = ((now * 11.1) % 28.0) as f64;

        let q1 = quant6(88.0 + seed1);
        let q2 = quant6(68.0 + seed2);
        let q3 = quant6(72.0 + seed3);
        let gen = NEAT_GEN.min(7133) * 12;

        let state = SNNState {
            reactivo_q6: q1,
            analitico_q6: q2,
            pascal_q6: q3,
            neat_gen: gen,
            reactivo_pct: dequant6(q1),
            analitico_pct: dequant6(q2),
            pascal_pct: dequant6(q3),
        };

        serde_json::to_string(&state).unwrap()
    }
}

#[wasm_bindgen]
pub fn quant_vigesimal(value: f64, min: f64, max: f64) -> u32 {
    quant_vig(value, min, max)
}

#[wasm_bindgen]
pub fn dequant_vigesimal(level: u32, min: f64, max: f64) -> f64 {
    dequant_vig(level, min, max)
}

#[wasm_bindgen]
pub fn quantize_6bit(pct: f64) -> u32 {
    quant6(pct)
}

#[wasm_bindgen]
pub fn dequantize_6bit(q: u32) -> f64 {
    dequant6(q)
}

#[wasm_bindgen]
pub fn get_pascal_weights(depth: usize) -> String {
    let w = get_pascal(depth);
    serde_json::to_string(&w).unwrap()
}

#[wasm_bindgen]
pub fn pythagorean_distance(lat1: f64, lng1: f64, lat2: f64, lng2: f64) -> f64 {
    let cos_lat = (lat1 * DEG2RAD).cos();
    pythagoras_dist(lat1, lng1, lat2, lng2, cos_lat)
}

#[wasm_bindgen]
pub fn engine_info() -> String {
    serde_json::to_string(&serde_json::json!({
        "name": "ClonEngine Triangulation",
        "version": "1.0.0",
        "runtime": "Rust/WASM",
        "timing": "performance.now() (sub-millisecond resolution)",
        "features": [
            "Pythagorean Triangulation with bake-in trig",
            "Vigesimal Quantization (20-level Maya)",
            "6-bit Quantization (64-step SNN)",
            "Pascal Cascade (depth 3-7)",
            "Intensity Memory (5-tick window)",
            "Computation Latency Measurement"
        ],
        "bake_in": {
            "DEG2RAD": DEG2RAD,
            "M_PER_DEG": M_PER_DEG,
            "VIG_LEVELS": VIG_LEVELS,
            "Q6_MAX": Q6_MAX,
            "HIST_SIZE": HIST_SIZE,
            "ARC_LEN": ARC_LEN
        }
    })).unwrap()
}
