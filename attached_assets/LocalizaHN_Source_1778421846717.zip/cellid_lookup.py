import math
import requests
import logging
import re

MYLNIKOV_URL = "https://api.mylnikov.org/geolocation/cell"

TIGO_LACS = {
    17: {'name': 'Cortés Norte', 'cities': ['San Pedro Sula', 'La Lima', 'Choloma', 'Villanueva']},
    18: {'name': 'Cortés Oeste', 'cities': ['Puerto Cortés', 'Omoa']},
    14: {'name': 'Yoro', 'cities': ['El Progreso', 'Yoro', 'Olanchito']},
    25: {'name': 'Francisco Morazán', 'cities': ['Tegucigalpa', 'Comayagüela']},
    30: {'name': 'Francisco Morazán Sur', 'cities': ['Tegucigalpa']},
    40: {'name': 'Islas de la Bahía', 'cities': ['Roatán', 'Guanaja', 'Utila']},
    22: {'name': 'Atlántida', 'cities': ['La Ceiba', 'Tela']},
    11: {'name': 'Atlántida Norte', 'cities': ['La Ceiba']},
    19: {'name': 'Atlántida Oeste', 'cities': ['Tela']},
    28: {'name': 'Comayagua', 'cities': ['Comayagua', 'Siguatepeque']},
    1: {'name': 'Comayagua Centro', 'cities': ['Comayagua']},
    9: {'name': 'Comayagua Sur', 'cities': ['Comayagua']},
    32: {'name': 'Copán', 'cities': ['Santa Rosa de Copán', 'Copán Ruinas']},
    35: {'name': 'Olancho', 'cities': ['Juticalpa', 'Catacamas']},
    38: {'name': 'Choluteca', 'cities': ['Choluteca', 'San Lorenzo']},
    10: {'name': 'Choluteca Sur', 'cities': ['Choluteca']},
    23: {'name': 'El Paraíso', 'cities': ['Danlí', 'El Paraíso']},
    2: {'name': 'Olancho Norte', 'cities': ['Juticalpa']},
    3: {'name': 'Santa Bárbara', 'cities': ['Santa Bárbara']},
    4: {'name': 'Ocotepeque', 'cities': ['Ocotepeque', 'Nueva Ocotepeque']},
    5: {'name': 'Colón', 'cities': ['Tocoa', 'Trujillo']},
    12: {'name': 'Cortés Sur', 'cities': ['San Pedro Sula', 'La Lima']},
    13: {'name': 'Intibucá', 'cities': ['La Esperanza']},
    16: {'name': 'Lempira', 'cities': ['Gracias']},
    20: {'name': 'Copán Oeste', 'cities': ['Santa Rosa de Copán']},
    21: {'name': 'Santa Bárbara Oeste', 'cities': ['Santa Bárbara']},
    24: {'name': 'Olancho Sur', 'cities': ['Juticalpa']},
    26: {'name': 'Tegucigalpa Este', 'cities': ['Tegucigalpa']},
    27: {'name': 'Tegucigalpa Oeste', 'cities': ['Tegucigalpa']},
    29: {'name': 'Valle', 'cities': ['Nacaome', 'San Lorenzo']},
}

CITY_TO_LAC = {
    'San Pedro Sula': 17,
    'La Lima': 17,
    'Choloma': 17,
    'Villanueva': 17,
    'Puerto Cortés': 18,
    'Omoa': 18,
    'El Progreso': 14,
    'Yoro': 14,
    'Olanchito': 14,
    'Tegucigalpa': 25,
    'Comayagüela': 25,
    'Roatán': 40,
    'Guanaja': 40,
    'Utila': 40,
    'La Ceiba': 11,
    'Tela': 19,
    'Comayagua': 1,
    'Siguatepeque': 28,
    'Santa Rosa de Copán': 20,
    'Copán Ruinas': 32,
    'Juticalpa': 2,
    'Catacamas': 35,
    'Choluteca': 10,
    'San Lorenzo': 29,
    'Danlí': 23,
    'El Paraíso': 23,
    'Tocoa': 5,
    'Trujillo': 5,
    'La Esperanza': 13,
    'Gracias': 16,
    'Santa Bárbara': 3,
    'Nacaome': 29,
    'Nueva Ocotepeque': 4,
}

MYLNIKOV_LAC_COORDS = {}
MYLNIKOV_CACHE = {}


def parse_cell_id(cell_id_int):
    enodeb = cell_id_int // 256
    sector = cell_id_int % 256
    enodeb_hex = hex(enodeb)
    sector_hex = hex(sector)
    cell_id_hex = hex(cell_id_int)

    return {
        'cell_id': cell_id_int,
        'cell_id_hex': cell_id_hex,
        'enodeb_id': enodeb,
        'enodeb_hex': enodeb_hex,
        'sector_id': sector,
        'sector_hex': sector_hex,
        'network_type': 'LTE',
    }


def phone_to_cell_id(phone_number_str):
    digits = re.sub(r'\D', '', str(phone_number_str))
    if digits.startswith('504'):
        digits = digits[3:]

    if len(digits) >= 8:
        cell_id = int(digits[:8])
    elif len(digits) >= 6:
        cell_id = int(digits) * (10 ** (8 - len(digits)))
    else:
        cell_id = int(digits) * 1000

    return cell_id


def determine_lac_from_city(city, carrier='tigo'):
    if not city or city == 'Unknown':
        return 17

    lac = CITY_TO_LAC.get(city)
    if lac:
        return lac

    city_lower = city.lower()
    for city_name, lac_id in CITY_TO_LAC.items():
        if city_name.lower() in city_lower or city_lower in city_name.lower():
            return lac_id

    for lac_id, lac_data in TIGO_LACS.items():
        for c in lac_data.get('cities', []):
            if c.lower() in city_lower or city_lower in c.lower():
                return lac_id

    return 17


def lookup_mylnikov(mcc, mnc, lac, cell_id):
    cache_key = f"{mcc}:{mnc}:{lac}"
    if cache_key in MYLNIKOV_CACHE:
        return MYLNIKOV_CACHE[cache_key]

    try:
        params = {
            'v': '1.1',
            'data': 'open',
            'mcc': mcc,
            'mnc': mnc,
            'lac': lac,
            'cellid': cell_id,
        }
        resp = requests.get(MYLNIKOV_URL, params=params, timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            if data.get('result') == 200:
                cell_data = data.get('data', {})
                result = {
                    'lat': cell_data.get('lat'),
                    'lng': cell_data.get('lon'),
                    'range': cell_data.get('range', 0),
                    'source': 'mylnikov_lac',
                    'precision': 'lac_centroid',
                    'found': True,
                }
                MYLNIKOV_CACHE[cache_key] = result
                return result
    except Exception as e:
        logging.error(f"Mylnikov lookup error: {e}")

    result = {'found': False, 'source': 'mylnikov_lac'}
    return result


def lookup_cell_location(phone_number, carrier='tigo', country_code='HN', detected_city=None):
    if country_code != 'HN':
        return None

    mcc = 708
    mnc = 2 if carrier == 'tigo' else 1

    cell_id = phone_to_cell_id(phone_number)
    cell_info = parse_cell_id(cell_id)

    lac = determine_lac_from_city(detected_city, carrier)

    cell_info['lac'] = lac
    cell_info['mcc'] = mcc
    cell_info['mnc'] = mnc

    result = lookup_mylnikov(mcc, 2, lac, cell_id)

    if not result.get('found'):
        for alt_lac in [17, 18, 25, 14, 40, 11, 1, 10, 23, 2, 5]:
            if alt_lac != lac:
                result = lookup_mylnikov(mcc, 2, alt_lac, cell_id)
                if result.get('found'):
                    cell_info['lac'] = alt_lac
                    result['fallback_lac'] = True
                    break

    cell_info['location'] = result

    final_lac = cell_info['lac']
    lac_info = TIGO_LACS.get(final_lac, {})
    cell_info['lac_name'] = lac_info.get('name', 'Unknown')
    cell_info['lac_cities'] = lac_info.get('cities', [])

    logging.info(
        f"Cell ID resolved: CID={cell_id} (eNB={cell_info['enodeb_id']}, "
        f"sector={cell_info['sector_id']}) → LAC {final_lac} "
        f"({cell_info['lac_name']}) for city={detected_city}"
    )

    return cell_info
