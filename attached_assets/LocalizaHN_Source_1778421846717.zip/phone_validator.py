import logging
import os
import requests
import phonenumbers
from phonenumbers import geocoder, carrier, timezone
import re

# Importar información específica de Honduras y Guatemala
try:
    from honduras_area_codes import get_honduras_location
except ImportError:
    # Función ficticia en caso de que el módulo no esté disponible
    def get_honduras_location(area_code):
        return None

try:
    from guatemala_area_codes import get_guatemala_location
except ImportError:
    # Función ficticia en caso de que el módulo no esté disponible
    def get_guatemala_location(area_code):
        return None

# Default country coordinates for common countries (approximate center points)
COUNTRY_COORDINATES = {
    'US': {'latitude': 29.9511, 'longitude': -90.0715},  # United States (Louisiana focus)
    'CA': {'latitude': 56.1304, 'longitude': -106.3468},  # Canada
    'MX': {'latitude': 23.6345, 'longitude': -102.5528},  # Mexico
    'GB': {'latitude': 55.3781, 'longitude': -3.4360},  # United Kingdom
    'FR': {'latitude': 46.2276, 'longitude': 2.2137},  # France
    'DE': {'latitude': 51.1657, 'longitude': 10.4515},  # Germany
    'IT': {'latitude': 41.8719, 'longitude': 12.5674},  # Italy
    'ES': {'latitude': 40.4637, 'longitude': -3.7492},  # Spain
    'JP': {'latitude': 36.2048, 'longitude': 138.2529},  # Japan
    'CN': {'latitude': 35.8617, 'longitude': 104.1954},  # China
    'IN': {'latitude': 20.5937, 'longitude': 78.9629},  # India
    'BR': {'latitude': -14.2350, 'longitude': -51.9253},  # Brazil
    'AU': {'latitude': -25.2744, 'longitude': 133.7751},  # Australia
    'RU': {'latitude': 61.5240, 'longitude': 105.3188},  # Russia
    'ZA': {'latitude': -30.5595, 'longitude': 22.9375},  # South Africa
    'AR': {'latitude': -38.4161, 'longitude': -63.6167},  # Argentina
    'CO': {'latitude': 4.5709, 'longitude': -74.2973},  # Colombia
    'CL': {'latitude': -35.6751, 'longitude': -71.5430},  # Chile
    'PE': {'latitude': -9.1900, 'longitude': -75.0152},  # Peru
    'VE': {'latitude': 6.4238, 'longitude': -66.5897},  # Venezuela
    'AT': {'latitude': 47.5162, 'longitude': 14.5501},  # Austria
    'BE': {'latitude': 50.5039, 'longitude': 4.4699},  # Belgium
    'NL': {'latitude': 52.1326, 'longitude': 5.2913},  # Netherlands
    'DK': {'latitude': 56.2639, 'longitude': 9.5018},  # Denmark
    'SE': {'latitude': 60.1282, 'longitude': 18.6435},  # Sweden
    'NO': {'latitude': 60.4720, 'longitude': 8.4689},  # Norway
    'FI': {'latitude': 61.9241, 'longitude': 25.7482},  # Finland
    'PT': {'latitude': 39.3999, 'longitude': -8.2245},  # Portugal
    'GR': {'latitude': 39.0742, 'longitude': 21.8243},  # Greece
    'CH': {'latitude': 46.8182, 'longitude': 8.2275},  # Switzerland
    'PL': {'latitude': 51.9194, 'longitude': 19.1451},  # Poland
    'HK': {'latitude': 22.3193, 'longitude': 114.1694},  # Hong Kong
    'SG': {'latitude': 1.3521, 'longitude': 103.8198},  # Singapore
    'TW': {'latitude': 23.6978, 'longitude': 120.9605},  # Taiwan
    'AE': {'latitude': 23.4241, 'longitude': 53.8478},  # United Arab Emirates
    'IL': {'latitude': 31.0461, 'longitude': 34.8516},  # Israel
    'QA': {'latitude': 25.3548, 'longitude': 51.1839},  # Qatar
    'TH': {'latitude': 15.8700, 'longitude': 100.9925},  # Thailand
    'MY': {'latitude': 4.2105, 'longitude': 101.9758},  # Malaysia
    'ID': {'latitude': -0.7893, 'longitude': 113.9213},  # Indonesia
    'PH': {'latitude': 12.8797, 'longitude': 121.7740},  # Philippines
    'VN': {'latitude': 14.0583, 'longitude': 108.2772},  # Vietnam
    'TR': {'latitude': 38.9637, 'longitude': 35.2433},  # Turkey
    'NZ': {'latitude': -40.9006, 'longitude': 174.8860},  # New Zealand
    'KR': {'latitude': 35.9078, 'longitude': 127.7669},  # South Korea
    'HN': {'latitude': 14.0723, 'longitude': -87.1921},  # Honduras (Tegucigalpa)
    'GT': {'latitude': 14.6349, 'longitude': -90.5069},  # Guatemala (Ciudad de Guatemala)
}

def get_detailed_location(phone_number, country_code):
    """
    Get detailed location information for a phone number.
    Uses area code-level precision for supported countries (Honduras, Guatemala),
    and country-level approximation for others.
    
    Args:
        phone_number (str): Phone number in international format
        country_code (str): Two-letter country code
        
    Returns:
        dict: Location information with coordinates
    """
    try:
        # Inform about the status of the API (for debugging)
        ipgeolocation_api_key = os.environ.get('IPGEOLOCATION_API_KEY')
        if ipgeolocation_api_key:
            logging.info("IPGeolocation API key found, but API endpoint might have changed or be unavailable")
        else:
            logging.info("IPGeolocation API key not found in environment variables")
            
        # Get basic phone information
        logging.info(f"Using basic location data for {phone_number}")
        parsed_number = phonenumbers.parse(phone_number)
        
        # Fallback information based on country
        location = {
            'city': 'Unknown',
            'region': 'Unknown',
            'country': phonenumbers.geocoder.description_for_number(parsed_number, 'en'),
            'continent': 'Unknown',
            'zipcode': 'Unknown',
            'provider': phonenumbers.carrier.name_for_number(parsed_number, 'en') or 'Unknown',
            'connection_type': 'Unknown'
        }
        
        # Extract area code from the national format (for countries with area code support)
        national_format = phonenumbers.format_number(
            parsed_number, 
            phonenumbers.PhoneNumberFormat.NATIONAL
        )
        # Extract area code (typically the first 2 digits after country code)
        match = re.search(r'^\(?(\d{2})\)?', national_format)
        area_code = match.group(1) if match else None
        
        national_digits = re.sub(r'\D', '', national_format)
        is_hn_mobile = country_code == 'HN' and national_digits and national_digits[0] in ('3', '8', '9')
        is_gt_mobile = country_code == 'GT' and national_digits and national_digits[0] in ('3', '4', '5')

        if country_code == 'US' and national_digits and len(national_digits) >= 3:
            us_area_code = national_digits[:3]
            us_locations = {
                '504': {'city': 'New Orleans', 'region': 'Louisiana', 'latitude': 29.9511, 'longitude': -90.0715},
                '225': {'city': 'Baton Rouge', 'region': 'Louisiana', 'latitude': 30.4583, 'longitude': -91.1403},
                '318': {'city': 'Shreveport', 'region': 'Louisiana', 'latitude': 32.5252, 'longitude': -93.7502},
                '337': {'city': 'Lafayette', 'region': 'Louisiana', 'latitude': 30.2241, 'longitude': -92.0198},
                '985': {'city': 'Mandeville', 'region': 'Louisiana', 'latitude': 30.3571, 'longitude': -90.0758},
            }
            us_loc = us_locations.get(us_area_code)
            if us_loc:
                logging.info(f"Found US Louisiana area code {us_area_code}")
                location['city'] = us_loc['city']
                location['region'] = us_loc['region']
                location['latitude'] = us_loc['latitude']
                location['longitude'] = us_loc['longitude']
                return location

        if country_code == 'HN' and area_code and not is_hn_mobile:
            honduras_location = get_honduras_location(area_code)
            
            if honduras_location:
                logging.info(f"Found specific location for Honduras area code {area_code}")
                location['city'] = honduras_location['city']
                location['region'] = honduras_location['region']
                location['latitude'] = honduras_location['latitude']
                location['longitude'] = honduras_location['longitude']
                return location
            else:
                logging.info(f"Honduras area code {area_code} not found in database")
        elif is_hn_mobile:
            logging.info(f"Honduras mobile number (prefix {national_digits[0]}), no area code lookup")
                
        elif country_code == 'GT' and area_code and not is_gt_mobile:
            guatemala_location = get_guatemala_location(area_code)
            
            if guatemala_location:
                logging.info(f"Found specific location for Guatemala area code {area_code}")
                location['city'] = guatemala_location['city']
                location['region'] = guatemala_location['region']
                location['latitude'] = guatemala_location['latitude']
                location['longitude'] = guatemala_location['longitude']
                return location
            else:
                logging.info(f"Guatemala area code {area_code} not found in database")
        
        # Add coordinates based on country if no specific location was found
        if country_code in COUNTRY_COORDINATES:
            location['latitude'] = COUNTRY_COORDINATES[country_code]['latitude']
            location['longitude'] = COUNTRY_COORDINATES[country_code]['longitude']
        
        return location
    except Exception as e:
        logging.error(f"Error getting location information: {str(e)}")
        return None

def validate_phone_number(phone_number):
    """
    Validate a phone number using the phonenumbers library and enhance with ipgeolocation.io API.
    
    Args:
        phone_number (str): Phone number to validate (e.g., +521234567890)
        
    Returns:
        dict: Result containing validation status and phone information
    """
    # Check if number is in a reasonable format
    if not phone_number.startswith('+'):
        return {
            'valid': False,
            'message': 'Phone number should start with + and country code (e.g., +521234567890)'
        }
    
    try:
        # Parse the phone number
        parsed_number = phonenumbers.parse(phone_number)
        
        # Check if the number is valid
        if not phonenumbers.is_valid_number(parsed_number):
            return {
                'valid': False,
                'message': 'The phone number is not valid'
            }
        
        # Format the number in international format
        formatted_number = phonenumbers.format_number(
            parsed_number, 
            phonenumbers.PhoneNumberFormat.INTERNATIONAL
        )
        
        # Get country code (two-letter country code)
        country_code = phonenumbers.region_code_for_number(parsed_number)
        
        # Get country name based on the number
        country_name = geocoder.description_for_number(parsed_number, "en")
        if not country_name:
            country_name = "Unknown"
        
        # Get carrier information
        carrier_name = carrier.name_for_number(parsed_number, "en")
        if not carrier_name:
            carrier_name = "Unknown"
        
        # Get number type
        number_type = phonenumbers.number_type(parsed_number)
        line_type = "Unknown"
        
        # Convert number type to string description
        if number_type == phonenumbers.PhoneNumberType.MOBILE:
            line_type = "Mobile"
        elif number_type == phonenumbers.PhoneNumberType.FIXED_LINE:
            line_type = "Fixed Line"
        elif number_type == phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE:
            line_type = "Fixed Line or Mobile"
        elif number_type == phonenumbers.PhoneNumberType.TOLL_FREE:
            line_type = "Toll Free"
        elif number_type == phonenumbers.PhoneNumberType.PREMIUM_RATE:
            line_type = "Premium Rate"
        elif number_type == phonenumbers.PhoneNumberType.SHARED_COST:
            line_type = "Shared Cost"
        elif number_type == phonenumbers.PhoneNumberType.VOIP:
            line_type = "VoIP"
        elif number_type == phonenumbers.PhoneNumberType.PERSONAL_NUMBER:
            line_type = "Personal Number"
        elif number_type == phonenumbers.PhoneNumberType.PAGER:
            line_type = "Pager"
        elif number_type == phonenumbers.PhoneNumberType.UAN:
            line_type = "UAN"
        
        # Get time zones for the phone number
        time_zones = timezone.time_zones_for_number(parsed_number)
        time_zone_str = ", ".join(time_zones) if time_zones else "Unknown"
        
        # Get detailed location information
        geo_details = get_detailed_location(phone_number, country_code)
        
        # Build the location string based on available details
        location = country_name
        
        if geo_details:
            # Create a more detailed location string
            location_parts = []
            
            if geo_details.get('city') and geo_details.get('city') != 'Unknown':
                location_parts.append(geo_details['city'])
                
            if geo_details.get('region') and geo_details.get('region') != 'Unknown':
                location_parts.append(geo_details['region'])
                
            # Only include country if it's different from what phonenumbers provided
            if (geo_details.get('country') and geo_details.get('country') != 'Unknown' and 
                geo_details.get('country') != country_name):
                location_parts.append(geo_details['country'])
                
            if location_parts:
                location = ", ".join(location_parts)
                
            # Return the successful result with enhanced location data and coordinates
            return {
                'valid': True,
                'number': formatted_number,
                'country_code': country_code,
                'country_name': country_name,
                'location': location,
                'city': geo_details.get('city', 'Unknown'),
                'region': geo_details.get('region', 'Unknown'),
                'provider': geo_details.get('provider', carrier_name),
                'zipcode': geo_details.get('zipcode', 'Unknown'),
                'carrier': carrier_name,
                'line_type': line_type,
                'time_zones': time_zone_str,
                'latitude': geo_details.get('latitude'),
                'longitude': geo_details.get('longitude')
            }
        
        # Return basic result without enhanced location data
        return {
            'valid': True,
            'number': formatted_number,
            'country_code': country_code,
            'country_name': country_name,
            'location': location,
            'carrier': carrier_name,
            'line_type': line_type,
            'time_zones': time_zone_str
        }
        
    except phonenumbers.NumberParseException as e:
        logging.error(f"Number parse error: {str(e)}")
        return {
            'valid': False,
            'message': f'Error parsing the phone number: {str(e)}'
        }
    except Exception as e:
        logging.error(f"Unexpected error: {str(e)}")
        return {
            'valid': False,
            'message': f'An unexpected error occurred: {str(e)}'
        }
