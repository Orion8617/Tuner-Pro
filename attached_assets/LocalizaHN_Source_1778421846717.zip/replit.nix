{pkgs}: {
  deps = [
    pkgs.wasm-bindgen-cli
    pkgs.wasm-pack
    pkgs.postgresql
    pkgs.openssl
  ];
}
