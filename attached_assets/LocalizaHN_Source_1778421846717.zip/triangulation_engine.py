import math
import time
import requests
import logging

DEG2RAD = math.pi / 180
M_PER_DEG = 111320
VIG_LEVELS = 20
Q6_MAX = 63
TERNARY_LEVELS = 3
TERNARY_SYMBOLS = ['◎', '•', '━']
VIGESIMAL_SYMBOLS = [
    '◎', '•', '••', '•••', '••••',
    '━', '━•', '━••', '━•••', '━••••',
    '━━', '━━•', '━━••', '━━•••', '━━••••',
    '━━━', '━━━•', '━━━••', '━━━•••', '━━━••••',
]

PASCAL_CACHE = {}

MOTIF_ISO = 'isosceles'
MOTIF_SCALE = 'scalene'
MOTIF_CROSS = 'cross'


def quant_vigesimal(value, min_v, max_v):
    if max_v <= min_v:
        return 10
    norm = max(0.0, min(1.0, (value - min_v) / (max_v - min_v)))
    level = min(VIG_LEVELS - 1, int(norm * VIG_LEVELS))
    return level


def dequant_vigesimal(level, min_v, max_v):
    center = (level + 0.5) / VIG_LEVELS
    return min_v + center * (max_v - min_v)


def vigesimal_symbol(level):
    return VIGESIMAL_SYMBOLS[min(level, len(VIGESIMAL_SYMBOLS) - 1)]


def vigesimal_weight(level):
    return 0.05 + (level / (VIG_LEVELS - 1)) * 0.95


def quant_ternary(value, min_v, max_v):
    if max_v <= min_v:
        return 1
    norm = max(0.0, min(1.0, (value - min_v) / (max_v - min_v)))
    level = min(TERNARY_LEVELS - 1, int(norm * TERNARY_LEVELS))
    return level


def dequant_ternary(level, min_v, max_v):
    center = (level + 0.5) / TERNARY_LEVELS
    return min_v + center * (max_v - min_v)


def ternary_symbol(level):
    return TERNARY_SYMBOLS[min(level, len(TERNARY_SYMBOLS) - 1)]


def ternary_weight(level):
    return [0.3, 0.6, 1.0][min(level, 2)]


def tower_archetype_6bit(circle):
    bits = 0
    if circle['distance'] < 2000:
        bits |= 0b100000
    if circle['rsrp'] > -90:
        bits |= 0b010000
    if circle.get('rsrq', -20) > -8:
        bits |= 0b001000
    if circle['weight'] > 0.6:
        bits |= 0b000100
    if circle.get('timing_advance', 0) < 5:
        bits |= 0b000010
    if circle.get('frequency_mhz', 1900) >= 1800:
        bits |= 0b000001
    return bits


def classify_triangle_motif(c0, c1, c2):
    d01 = math.sqrt((c0['x'] - c1['x'])**2 + (c0['y'] - c1['y'])**2)
    d02 = math.sqrt((c0['x'] - c2['x'])**2 + (c0['y'] - c2['y'])**2)
    d12 = math.sqrt((c1['x'] - c2['x'])**2 + (c1['y'] - c2['y'])**2)
    sides = sorted([d01, d02, d12])
    if sides[0] < 1:
        return MOTIF_SCALE, 0.3
    ratio = sides[2] / sides[0]
    if ratio < 2.0:
        return MOTIF_ISO, 1.0
    elif ratio < 4.0:
        return MOTIF_SCALE, 0.6
    else:
        return MOTIF_CROSS, 0.3


def bilateral_resonance(circles, estimated_x, estimated_y, coupling=0.3):
    n = len(circles)
    adjustments = [0.0] * n
    for i in range(n):
        dx_i = circles[i]['x'] - estimated_x
        dy_i = circles[i]['y'] - estimated_y
        angle_i = math.atan2(dy_i, dx_i)
        dist_i = math.sqrt(dx_i * dx_i + dy_i * dy_i)
        for j in range(i + 1, n):
            dx_j = circles[j]['x'] - estimated_x
            dy_j = circles[j]['y'] - estimated_y
            angle_j = math.atan2(dy_j, dx_j)
            dist_j = math.sqrt(dx_j * dx_j + dy_j * dy_j)
            angle_diff = abs(angle_i - angle_j)
            if angle_diff > math.pi:
                angle_diff = 2 * math.pi - angle_diff
            if angle_diff > 2.5:
                dist_ratio = min(dist_i, dist_j) / max(dist_i, dist_j) if max(dist_i, dist_j) > 0 else 0
                if dist_ratio > 0.3:
                    err_i = abs(dist_i - circles[i]['radius'])
                    err_j = abs(dist_j - circles[j]['radius'])
                    avg_err = (err_i + err_j) / 2
                    adjustments[i] += coupling * (avg_err - err_i)
                    adjustments[j] += coupling * (avg_err - err_j)
    return adjustments


def compute_gdop(tower_positions, target_x, target_y):
    n = len(tower_positions)
    if n < 3:
        return 99.0
    H = []
    for tx, ty in tower_positions:
        dx = tx - target_x
        dy = ty - target_y
        r = math.sqrt(dx * dx + dy * dy)
        if r < 1:
            r = 1
        H.append([dx / r, dy / r])
    Ht_H = [[0.0, 0.0], [0.0, 0.0]]
    for row in H:
        Ht_H[0][0] += row[0] * row[0]
        Ht_H[0][1] += row[0] * row[1]
        Ht_H[1][0] += row[1] * row[0]
        Ht_H[1][1] += row[1] * row[1]
    det = Ht_H[0][0] * Ht_H[1][1] - Ht_H[0][1] * Ht_H[1][0]
    if abs(det) < 1e-12:
        return 99.0
    trace_inv = (Ht_H[1][1] + Ht_H[0][0]) / det
    if trace_inv < 0:
        return 99.0
    return min(math.sqrt(trace_inv), 99.0)


def build_pascal(n):
    if n in PASCAL_CACHE:
        return PASCAL_CACHE[n]
    row = [1]
    for i in range(1, n + 1):
        nx = [1]
        for j in range(1, len(row)):
            nx.append(row[j - 1] + row[j])
        nx.append(1)
        row = nx
    s = sum(row)
    PASCAL_CACHE[n] = [v / s for v in row]
    return PASCAL_CACHE[n]


for d in [3, 4, 5, 6, 7]:
    build_pascal(d)


def quant_vig(value, min_v, max_v):
    norm = max(0, min(1, (value - min_v) / (max_v - min_v))) if max_v != min_v else 0
    return round(norm * (VIG_LEVELS - 1))


def dequant_vig(level, min_v, max_v):
    return min_v + (level / (VIG_LEVELS - 1)) * (max_v - min_v)


def quant6(pct):
    return round((pct / 100) * Q6_MAX)


def dequant6(q):
    return round(q * (100 / Q6_MAX))


def haversine_distance(lat1, lng1, lat2, lng2):
    r = 6371000
    phi1 = lat1 * DEG2RAD
    phi2 = lat2 * DEG2RAD
    dphi = (lat2 - lat1) * DEG2RAD
    dlam = (lng2 - lng1) * DEG2RAD
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return r * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def pythagoras_distance(lat1, lng1, lat2, lng2, cos_lat=None):
    if cos_lat is None:
        cos_lat = math.cos(lat1 * DEG2RAD)
    dlat = (lat2 - lat1) * M_PER_DEG
    dlng = (lng2 - lng1) * M_PER_DEG * cos_lat
    return math.sqrt(dlat * dlat + dlng * dlng)


def phone_number_seed(phone_number_str):
    h = 0
    for ch in str(phone_number_str):
        if ch.isdigit():
            h = (h * 31 + int(ch)) & 0xFFFFFFFF
    return h


def simulate_phone_position(phone_seed, center_lat, center_lng, radius_km=2.0):
    import random
    rng = random.Random(phone_seed)

    angle = rng.uniform(0, 2 * math.pi)
    r = radius_km * 1000 * math.sqrt(rng.uniform(0.02, 0.85))

    dlat = (r * math.cos(angle)) / M_PER_DEG
    dlng = (r * math.sin(angle)) / (M_PER_DEG * math.cos(center_lat * DEG2RAD))

    return center_lat + dlat, center_lng + dlng


BAND_PROPAGATION = {
    850: {'exponent': 3.2, 'ref_loss_1km': 110.0, 'label': '850MHz'},
    1900: {'exponent': 3.5, 'ref_loss_1km': 120.0, 'label': '1900MHz'},
    2100: {'exponent': 3.8, 'ref_loss_1km': 123.0, 'label': '2100MHz'},
    2600: {'exponent': 4.0, 'ref_loss_1km': 126.0, 'label': '2600MHz'},
}

def get_propagation_params(frequency_mhz):
    if frequency_mhz <= 900:
        return BAND_PROPAGATION[850]
    elif frequency_mhz <= 2000:
        return BAND_PROPAGATION[1900]
    elif frequency_mhz <= 2300:
        return BAND_PROPAGATION[2100]
    return BAND_PROPAGATION[2600]


def cost231_path_loss(distance_m, frequency_mhz, h_bs=30, h_ms=1.5):
    if distance_m <= 0:
        return 0
    freq = max(frequency_mhz, 150)
    d_km = max(distance_m / 1000.0, 0.02)
    a_hm = (1.1 * math.log10(freq) - 0.7) * h_ms - (1.56 * math.log10(freq) - 0.8)
    prop = get_propagation_params(freq)
    path_loss = (46.3 + 33.9 * math.log10(freq) - 13.82 * math.log10(h_bs) - a_hm +
                 (44.9 - 6.55 * math.log10(h_bs)) * math.log10(d_km))
    exponent_adjustment = (prop['exponent'] - 3.5) * 10 * math.log10(d_km)
    return max(path_loss + exponent_adjustment, 0)


def compute_rsrp(tx_power_dbm, path_loss_db, fading_db=0):
    return tx_power_dbm - path_loss_db + fading_db


def compute_rsrq(rsrp, neighbor_rsrps=None, noise_floor_dbm=-105, n_rb=50):
    if rsrp <= -140:
        return -19.5

    signal_linear = 10 ** (rsrp / 10.0)
    noise_linear = 10 ** (noise_floor_dbm / 10.0)

    interference_linear = 0.0
    if neighbor_rsrps:
        for nr in neighbor_rsrps:
            if nr > -140:
                interference_linear += 10 ** (nr / 10.0)

    rssi_per_rb = signal_linear + interference_linear + noise_linear
    rssi_total = rssi_per_rb * n_rb

    if rssi_total <= 0:
        return -19.5

    rsrq = 10 * math.log10(n_rb * signal_linear / rssi_total)
    return max(-19.5, min(-3.0, round(rsrq, 1)))


def simulate_cell_connection(towers, phone_seed, center_lat, center_lng):
    phone_lat, phone_lng = simulate_phone_position(phone_seed, center_lat, center_lng)
    connected, serving = simulate_cell_connection_real(towers, phone_seed, phone_lat, phone_lng)
    return connected, serving


def simulate_cell_connection_real(towers, phone_seed, real_lat, real_lng):
    import random
    rng = random.Random(phone_seed)

    cos_lat = math.cos(real_lat * DEG2RAD)

    tower_data = []
    for t in towers:
        dist = pythagoras_distance(real_lat, real_lng, t['lat'], t['lng'], cos_lat)
        tower_data.append({'tower': t, 'base_dist': dist})

    tower_data.sort(key=lambda x: x['base_dist'])
    nearby = tower_data[:min(12, len(tower_data))]

    for td in nearby:
        tower = td['tower']
        freq_mhz = tower.get('frequency_mhz', 2100)

        pl = cost231_path_loss(td['base_dist'], freq_mhz)
        fading = rng.gauss(0, 1.8)

        tx_power = 46 if tower.get('radio_type', 'LTE') == 'LTE' else 43
        td['rsrp'] = compute_rsrp(tx_power, pl, fading)

        td['frequency_mhz'] = freq_mhz
        td['propagation_exponent'] = get_propagation_params(freq_mhz)['exponent']

        speed_of_light = 299792458
        propagation_delay = td['base_dist'] / speed_of_light
        ta_raw = propagation_delay / 3.69e-6
        ta_jitter = rng.gauss(0, 0.02)
        td['timing_advance'] = max(0, ta_raw + ta_jitter)
        td['estimated_distance'] = td['timing_advance'] * 3.69e-6 * speed_of_light

    for i, td in enumerate(nearby):
        neighbor_rsrps = [nearby[j]['rsrp'] for j in range(len(nearby)) if j != i]
        td['rsrq'] = compute_rsrq(td['rsrp'], neighbor_rsrps=neighbor_rsrps)
        n_rb = 50
        signal_lin = 10 ** (td['rsrp'] / 10.0)
        noise_lin = 10 ** (-105 / 10.0)
        interf_lin = sum(10 ** (nr / 10.0) for nr in neighbor_rsrps if nr > -140)
        rssi_total = (signal_lin + interf_lin + noise_lin) * n_rb
        td['rssi'] = round(10 * math.log10(rssi_total), 1) if rssi_total > 0 else -120

    nearby.sort(key=lambda x: x.get('rsrp', -140), reverse=True)
    serving = nearby[0]

    connected = nearby[:min(8, len(nearby))]
    connected[0]['phone_lat'] = real_lat
    connected[0]['phone_lng'] = real_lng
    return connected, serving


def quality_gate_tower(td, dist_min, dist_max, rsrp_min, rsrp_max):
    est_dist = td.get('estimated_distance', 0)
    base_dist = td.get('base_dist', 0)
    rsrp = td.get('rsrp', -120)
    rsrq = td.get('rsrq', -20)
    ta = td.get('timing_advance', 0)

    quality_score = 1.0

    if est_dist > 0 and base_dist > 0:
        ratio = est_dist / max(base_dist, 1)
        if ratio > 3.0 or ratio < 0.2:
            quality_score *= 0.3

    if rsrp < -120:
        quality_score *= 0.4

    if rsrq < -15:
        quality_score *= 0.6

    if est_dist > 15000:
        quality_score *= 0.5

    if rsrp > -80 and est_dist > 5000:
        quality_score *= 0.4

    if rsrp < -110 and est_dist < 500:
        quality_score *= 0.5

    return quality_score


def _dedupe_towers(towers, min_dist=50):
    seen = []
    result = []
    for t in towers:
        dup = False
        for s in seen:
            dlat = abs(t['lat'] - s['lat'])
            dlng = abs(t['lng'] - s['lng'])
            if dlat < 0.0005 and dlng < 0.0005:
                dup = True
                break
        if not dup:
            seen.append(t)
            result.append(t)
    return result


HN_POPULATED_ANCHORS = [
    (14.0723, -87.1921, 'Tegucigalpa'),
    (15.5000, -88.0333, 'San Pedro Sula'),
    (15.7631, -86.7833, 'La Ceiba'),
    (14.4539, -87.6233, 'Comayagua'),
    (13.3005, -87.1649, 'Choluteca'),
    (14.7667, -86.8000, 'Juticalpa'),
    (15.4333, -87.9167, 'El Progreso'),
    (15.5600, -87.9800, 'Choloma'),
    (15.4589, -87.9465, 'La Lima'),
    (14.0333, -88.5833, 'Santa Rosa de Copán'),
    (15.8383, -87.4500, 'Tela'),
    (15.3167, -87.4667, 'Yoro'),
    (15.7833, -87.9333, 'Puerto Cortés'),
    (14.3000, -87.5833, 'Siguatepeque'),
    (14.8000, -88.1000, 'Santa Bárbara'),
    (14.6500, -87.2500, 'Catacamas'),
    (15.4833, -88.1833, 'Villanueva'),
    (14.6000, -87.0500, 'Danlí'),
    (14.7300, -87.6400, 'La Paz'),
    (15.6500, -87.7833, 'Pimienta'),
    (13.8000, -87.1600, 'San Lorenzo'),
    (16.3333, -86.5333, 'Guanaja'),
    (16.3200, -86.5400, 'Roatán'),
    (13.3400, -87.0800, 'San Marcos de Colón'),
    (14.9200, -88.1600, 'Quimistán'),
    (13.5000, -87.9000, 'Nacaome'),
    (14.3800, -89.1600, 'Copán Ruinas'),
    (14.1200, -87.1500, 'Valle de Ángeles'),
    (15.2000, -86.3500, 'Trujillo'),
    (15.0500, -86.1000, 'Tocoa'),
    (15.3200, -86.5600, 'Olanchito'),
    (14.0500, -86.5800, 'San Juan de Flores'),
]

HN_WATER_ZONES = [
    {'name': 'Golfo de Fonseca', 'lat_min': 13.0, 'lat_max': 13.35, 'lng_min': -87.95, 'lng_max': -87.45, 'type': 'gulf'},
    {'name': 'Caribe Norte', 'lat_min': 16.0, 'lat_max': 17.0, 'lng_min': -89.0, 'lng_max': -83.0, 'type': 'sea'},
    {'name': 'Caribe Costa', 'lat_min': 15.9, 'lat_max': 16.5, 'lng_min': -88.5, 'lng_max': -85.0, 'type': 'sea'},
    {'name': 'Lago de Yojoa', 'lat_min': 14.78, 'lat_max': 14.92, 'lng_min': -88.00, 'lng_max': -87.88, 'type': 'lake'},
    {'name': 'Pacífico Sur', 'lat_min': 12.5, 'lat_max': 13.1, 'lng_min': -88.5, 'lng_max': -86.5, 'type': 'sea'},
    {'name': 'Caribe profundo', 'lat_min': 16.5, 'lat_max': 18.0, 'lng_min': -89.0, 'lng_max': -83.0, 'type': 'sea'},
]

def _haversine_km(lat1, lng1, lat2, lng2):
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlng/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def _is_in_water(lat, lng):
    for zone in HN_WATER_ZONES:
        if zone['lat_min'] <= lat <= zone['lat_max'] and zone['lng_min'] <= lng <= zone['lng_max']:
            return zone
    if lat > 16.1 and -89.0 < lng < -83.0:
        return {'name': 'Mar Caribe', 'type': 'sea'}
    if lat < 13.0 and -89.0 < lng < -86.5:
        return {'name': 'Pacífico', 'type': 'sea'}
    return None

_ROAD_SNAP_CACHE = {}

def _snap_to_road(lat, lng, phone_number=None):
    import os
    cache_key = (round(lat, 5), round(lng, 5))
    if cache_key in _ROAD_SNAP_CACHE:
        cached = _ROAD_SNAP_CACHE[cache_key]
        return cached[0], cached[1], cached[2]

    api_key = os.environ.get('GOOGLE_MAPS_API_KEY')
    if not api_key:
        return lat, lng, False

    try:
        url = 'https://roads.googleapis.com/v1/nearestRoads'
        resp = requests.get(url, params={
            'points': f'{lat},{lng}',
            'key': api_key,
        }, timeout=3)
        if resp.status_code == 200:
            data = resp.json()
            snapped = data.get('snappedPoints', [])
            if snapped:
                loc = snapped[0]['location']
                new_lat = loc['latitude']
                new_lng = loc['longitude']
                dist_m = _haversine_km(lat, lng, new_lat, new_lng) * 1000
                if dist_m < 3000:
                    logging.info(f"Road-snap: [{lat:.6f},{lng:.6f}] → [{new_lat:.6f},{new_lng:.6f}] ({dist_m:.0f}m to road) for {phone_number}")
                    result = (round(new_lat, 6), round(new_lng, 6), True)
                    _ROAD_SNAP_CACHE[cache_key] = result
                    return result
                else:
                    logging.info(f"Road-snap: nearest road {dist_m:.0f}m away — too far, skipping for {phone_number}")
    except Exception as e:
        logging.debug(f"Road-snap API call failed: {e}")

    _ROAD_SNAP_CACHE[cache_key] = (lat, lng, False)
    return lat, lng, False


def _snap_to_nearest_road_reverse(lat, lng, phone_number=None):
    import os
    cache_key = ('rev', round(lat, 5), round(lng, 5))
    if cache_key in _ROAD_SNAP_CACHE:
        cached = _ROAD_SNAP_CACHE[cache_key]
        return cached[0], cached[1], cached[2]

    api_key = os.environ.get('GOOGLE_MAPS_API_KEY')
    if not api_key:
        return lat, lng, False

    try:
        url = 'https://maps.googleapis.com/maps/api/geocode/json'
        resp = requests.get(url, params={
            'latlng': f'{lat},{lng}',
            'result_type': 'street_address|route|premise',
            'key': api_key,
            'language': 'es',
        }, timeout=3)
        if resp.status_code == 200:
            data = resp.json()
            results = data.get('results', [])
            if results:
                geo = results[0].get('geometry', {}).get('location', {})
                new_lat = geo.get('lat', lat)
                new_lng = geo.get('lng', lng)
                dist_m = _haversine_km(lat, lng, new_lat, new_lng) * 1000
                addr = results[0].get('formatted_address', '')
                if dist_m < 2000:
                    logging.info(f"Reverse-snap: [{lat:.6f},{lng:.6f}] → [{new_lat:.6f},{new_lng:.6f}] ({dist_m:.0f}m) addr='{addr}' for {phone_number}")
                    result = (round(new_lat, 6), round(new_lng, 6), True)
                    _ROAD_SNAP_CACHE[cache_key] = result
                    return result
    except Exception as e:
        logging.debug(f"Reverse geocode snap failed: {e}")

    _ROAD_SNAP_CACHE[cache_key] = (lat, lng, False)
    return lat, lng, False


def _snap_to_land(lat, lng, city_hint=None, phone_number=None):
    water = _is_in_water(lat, lng)
    if water:
        best_anchor = None
        best_dist = float('inf')

        if city_hint and city_hint != 'Unknown':
            for a in HN_POPULATED_ANCHORS:
                if a[2].lower() == city_hint.lower():
                    best_anchor = a
                    best_dist = 0
                    break

        if not best_anchor:
            for a in HN_POPULATED_ANCHORS:
                d = _haversine_km(lat, lng, a[0], a[1])
                if d < best_dist:
                    best_dist = d
                    best_anchor = a

        if best_anchor:
            import random as _snap_rng
            seed_val = int(abs(lat * 1e6 + lng * 1e6)) & 0xFFFFFFFF
            r = _snap_rng.Random(seed_val)
            offset_lat = r.gauss(0, 0.003)
            offset_lng = r.gauss(0, 0.004)
            lat = best_anchor[0] + offset_lat
            lng = best_anchor[1] + offset_lng
            logging.info(f"Water-snap: moved from water ({water['name']}) to near {best_anchor[2]} for {phone_number}")

    road_lat, road_lng, snapped = _snap_to_road(lat, lng, phone_number)
    if snapped:
        return round(road_lat, 6), round(road_lng, 6), True

    rev_lat, rev_lng, rev_snapped = _snap_to_nearest_road_reverse(lat, lng, phone_number)
    if rev_snapped:
        return round(rev_lat, 6), round(rev_lng, 6), True

    if water:
        return round(lat, 6), round(lng, 6), True

    return lat, lng, False


def triangulate(towers, center_lat, center_lng, phone_number=None, country_code='HN', real_lat=None, real_lng=None, wifi_position=None):
    towers = _dedupe_towers(towers)
    if len(towers) < 3:
        return None

    cos_lat = math.cos(center_lat * DEG2RAD)
    m_per_lng = M_PER_DEG * cos_lat
    ref_lat = center_lat
    ref_lng = center_lng

    if phone_number:
        seed = phone_number_seed(phone_number)

        if real_lat is not None and real_lng is not None:
            connected, serving = simulate_cell_connection_real(
                towers, seed, real_lat, real_lng
            )
        else:
            connected, serving = simulate_cell_connection(towers, seed, center_lat, center_lng)
    else:
        seed = hash(f"{center_lat:.6f}{center_lng:.6f}") & 0xFFFFFFFF
        connected, serving = simulate_cell_connection(towers, seed, center_lat, center_lng)

    all_distances = [td['estimated_distance'] for td in connected if td.get('estimated_distance', 0) > 0]
    dist_min = min(all_distances) if all_distances else 100
    dist_max = max(all_distances) if all_distances else 10000
    all_rsrp = [td.get('rsrp', -100) for td in connected]
    rsrp_min = min(all_rsrp)
    rsrp_max = max(all_rsrp)

    circles = []
    for td in connected:
        t = td['tower']
        est_dist = td.get('estimated_distance', 0)
        rssi = td.get('rssi', -80)
        rsrp = td.get('rsrp', rssi)
        rsrq = td.get('rsrq', -10)

        dist_q = quant_ternary(est_dist, dist_min, dist_max)
        rsrp_q = quant_ternary(rsrp, rsrp_min, rsrp_max)

        quantized_dist = dequant_ternary(dist_q, dist_min, dist_max)

        signal_weight = ternary_weight(rsrp_q)
        rsrq_factor = max(0.1, 1.0 + (rsrq + 3.0) / 16.5)
        combined_weight = signal_weight * rsrq_factor

        vig_dist_q = quant_vigesimal(est_dist, dist_min, dist_max)
        vig_rsrp_q = quant_vigesimal(rsrp, rsrp_min, rsrp_max)
        vig_signal_w = vigesimal_weight(vig_rsrp_q)
        vig_combined = vig_signal_w * rsrq_factor
        vig_quantized_dist = dequant_vigesimal(vig_dist_q, dist_min, dist_max)

        qg_score = quality_gate_tower(td, dist_min, dist_max, rsrp_min, rsrp_max)
        vig_combined *= qg_score

        circles.append({
            'tower': t,
            'distance': td['base_dist'],
            'radius': max(est_dist, 50),
            'quality_gate': round(qg_score, 3),
            'quantized_radius': max(quantized_dist, 100),
            'rssi': round(rssi, 1),
            'rsrp': round(rsrp, 1),
            'rsrq': round(rsrq, 1),
            'weight': round(vig_combined, 4),
            'weight_ternary': round(combined_weight, 3),
            'timing_advance': round(td.get('timing_advance', 0), 2),
            'estimated_distance': round(est_dist),
            'quantized_distance': round(quantized_dist),
            'vig_distance': round(vig_quantized_dist),
            'ternary_dist': dist_q,
            'ternary_rsrp': rsrp_q,
            'vig_dist': vig_dist_q,
            'vig_rsrp': vig_rsrp_q,
            'ternary_dist_symbol': ternary_symbol(dist_q),
            'ternary_rsrp_symbol': ternary_symbol(rsrp_q),
            'vig_dist_symbol': vigesimal_symbol(vig_dist_q),
            'vig_rsrp_symbol': vigesimal_symbol(vig_rsrp_q),
            'frequency_mhz': td.get('frequency_mhz', 2100),
            'propagation_exponent': td.get('propagation_exponent', 3.5),
            'x': (t['lng'] - ref_lng) * m_per_lng,
            'y': (t['lat'] - ref_lat) * M_PER_DEG,
        })

    serving_tower = serving['tower']
    tower_tech = serving_tower.get('tech', 'LTE')
    tower_band = serving_tower.get('band', 'B4')
    tower_enodeb = serving_tower.get('enodeb', 0)
    tower_lac = serving_tower.get('lac', 0)

    if tower_tech == '2G':
        tech_str = f"2G GSM {tower_band}"
    elif tower_tech == 'LTE':
        tech_str = f"4G LTE {tower_band}"
    else:
        tech_str = f"{tower_tech} {tower_band}"

    import random as _rng
    _r = _rng.Random(seed)
    sector = _r.randint(0, 2)
    cell_id = tower_enodeb * 256 + sector if tower_enodeb else (seed & 0xFFFF)

    mcc = serving_tower.get('mcc', 708 if country_code == 'HN' else 704)
    mnc = serving_tower.get('mnc', 2)

    connection_info = {
        'serving_cell': serving_tower['id'],
        'serving_rssi': round(serving['rssi'], 1),
        'serving_rsrp': round(serving.get('rsrp', serving['rssi']), 1),
        'serving_rsrq': round(serving.get('rsrq', -10), 1),
        'technology': tech_str,
        'lac': tower_lac,
        'cell_id': cell_id,
        'enodeb': tower_enodeb,
        'band': tower_band,
        'band_name': serving_tower.get('band_name', tower_band),
        'frequency_mhz': serving_tower.get('frequency_mhz', 2100),
        'radio_type': serving_tower.get('radio_type', 'LTE'),
        'earfcn': serving_tower.get('earfcn', 2050),
        'mcc': mcc,
        'mnc': mnc,
    }

    if len(circles) >= 3:
        weights = [c['weight'] for c in circles]
        w_total = sum(weights)
        if w_total < 1e-10:
            w_total = 1.0
        norm_weights = [w / w_total for w in weights]

        def _trilaterate_triple(c0, c1, c2):
            ax, ay, ar = c0['x'], c0['y'], c0['radius']
            bx, by, br = c1['x'], c1['y'], c1['radius']
            cx_t, cy_t, cr = c2['x'], c2['y'], c2['radius']
            A = 2 * (bx - ax)
            B = 2 * (by - ay)
            C = ar * ar - br * br - ax * ax + bx * bx - ay * ay + by * by
            D = 2 * (cx_t - bx)
            E = 2 * (cy_t - by)
            F = br * br - cr * cr - bx * bx + cx_t * cx_t - by * by + cy_t * cy_t
            denom = A * E - B * D
            if abs(denom) < 1e-10:
                return None
            px_sol = (C * E - F * B) / denom
            py_sol = (A * F - D * C) / denom
            return (px_sol, py_sol)

        def _score_candidate(px_c, py_c, circle_set, use_huber=True):
            score = 0
            for c in circle_set:
                dx = px_c - c['x']
                dy = py_c - c['y']
                d = math.sqrt(dx * dx + dy * dy)
                err = d - c['radius']
                if use_huber:
                    abs_err = abs(err)
                    if abs_err <= 50:
                        score += c['weight'] * err * err
                    else:
                        score += c['weight'] * (50 * (2 * abs_err - 50))
                else:
                    score += c['weight'] * err * err
            return score

        n_circles = len(circles)
        sorted_by_weight = sorted(range(n_circles), key=lambda i: circles[i]['weight'], reverse=True)
        top_indices = sorted_by_weight[:min(n_circles, 8)]

        for c in circles:
            c['archetype'] = tower_archetype_6bit(c)

        phase1_candidates = []
        motif_stats = {MOTIF_ISO: 0, MOTIF_SCALE: 0, MOTIF_CROSS: 0}
        for ii in range(len(top_indices)):
            for jj in range(ii + 1, len(top_indices)):
                for kk in range(jj + 1, len(top_indices)):
                    i, j, k = top_indices[ii], top_indices[jj], top_indices[kk]
                    motif_type, motif_boost = classify_triangle_motif(circles[i], circles[j], circles[k])
                    motif_stats[motif_type] = motif_stats.get(motif_type, 0) + 1
                    pt = _trilaterate_triple(circles[i], circles[j], circles[k])
                    if pt:
                        triple_w = (circles[i]['weight'] + circles[j]['weight'] + circles[k]['weight']) * motif_boost
                        score = _score_candidate(pt[0], pt[1], circles)
                        score /= max(motif_boost, 0.1)
                        phase1_candidates.append((pt[0], pt[1], score, triple_w, motif_type))

        if phase1_candidates:
            phase1_candidates.sort(key=lambda c: c[2])
            top_k = min(len(phase1_candidates), 12)
            top_cands = phase1_candidates[:top_k]
        else:
            cx_wc = sum(c['x'] * w for c, w in zip(circles, norm_weights))
            cy_wc = sum(c['y'] * w for c, w in zip(circles, norm_weights))
            top_cands = [(cx_wc, cy_wc, 0, 1.0, MOTIF_ISO)]

        phase2_candidates = []
        for cx, cy, sc, tw, motif in top_cands:
            phase2_candidates.append((cx, cy, sc))
            for radius_frac in [0.1, 0.2, 0.35]:
                for angle_step in range(8):
                    angle = angle_step * math.pi / 4
                    avg_r = sum(c['radius'] for c in circles) / len(circles)
                    off = avg_r * radius_frac
                    nx = cx + off * math.cos(angle)
                    ny = cy + off * math.sin(angle)
                    ns = _score_candidate(nx, ny, circles)
                    phase2_candidates.append((nx, ny, ns))

        phase2_candidates.sort(key=lambda c: c[2])
        refined_top = phase2_candidates[:min(len(phase2_candidates), 10)]

        def _compute_cost(px, py, ws):
            total = 0
            for i, c in enumerate(circles):
                dx = px - c['x']
                dy = py - c['y']
                d = math.sqrt(dx * dx + dy * dy)
                total += ws[i] * (d - c['radius']) ** 2
            return total

        def _solve_gn_irls(start_x, start_y, base_weights):
            sx, sy = start_x, start_y
            irls_weights = list(base_weights)
            n_irls = 5
            n_gn = 40
            for irls_round in range(n_irls):
                lam = 5.0
                nu = 2.0
                cost_old = _compute_cost(sx, sy, irls_weights)
                for iteration in range(n_gn):
                    JtWJ = [[0.0, 0.0], [0.0, 0.0]]
                    JtWr = [0.0, 0.0]
                    for i, c in enumerate(circles):
                        dx = sx - c['x']
                        dy = sy - c['y']
                        d = math.sqrt(dx * dx + dy * dy)
                        if d < 1.0:
                            d = 1.0
                        residual = d - c['radius']
                        jx = dx / d
                        jy = dy / d
                        w = irls_weights[i]
                        JtWJ[0][0] += w * jx * jx
                        JtWJ[0][1] += w * jx * jy
                        JtWJ[1][0] += w * jy * jx
                        JtWJ[1][1] += w * jy * jy
                        JtWr[0] += w * jx * residual
                        JtWr[1] += w * jy * residual

                    JtWJ[0][0] += lam
                    JtWJ[1][1] += lam

                    det = JtWJ[0][0] * JtWJ[1][1] - JtWJ[0][1] * JtWJ[1][0]
                    if abs(det) < 1e-12:
                        break
                    step_x = (JtWr[0] * JtWJ[1][1] - JtWr[1] * JtWJ[0][1]) / det
                    step_y = (JtWJ[0][0] * JtWr[1] - JtWJ[1][0] * JtWr[0]) / det

                    new_x = sx - step_x
                    new_y = sy - step_y
                    cost_new = _compute_cost(new_x, new_y, irls_weights)

                    if cost_new < cost_old:
                        sx, sy = new_x, new_y
                        cost_old = cost_new
                        lam = max(lam * 0.33, 1e-7)
                        nu = 2.0
                    else:
                        lam *= nu
                        nu *= 2.0
                        if lam > 1e6:
                            break
                        continue

                    if abs(step_x) < 0.005 and abs(step_y) < 0.005:
                        break

                raw_residuals = []
                signed_residuals = []
                for c in circles:
                    dx = sx - c['x']
                    dy = sy - c['y']
                    d = math.sqrt(dx * dx + dy * dy)
                    raw_residuals.append(abs(d - c['radius']))
                    signed_residuals.append(d - c['radius'])
                if raw_residuals:
                    med_r = sorted(raw_residuals)[len(raw_residuals) // 2]
                    sigma = max(med_r * 1.4826, 10.0)
                    c_factor = 6.0 - irls_round * 0.263
                    c_thresh = c_factor * sigma
                    for i in range(len(circles)):
                        r = signed_residuals[i]
                        if r > 0:
                            asym_c = c_thresh * 0.7
                        else:
                            asym_c = c_thresh
                        norm_r = abs(r) / max(asym_c, 1.0)
                        if norm_r <= 1.0:
                            tukey_w = (1.0 - norm_r * norm_r) ** 2
                        else:
                            tukey_w = 0.0
                        irls_weights[i] = base_weights[i] * max(tukey_w, 0.001)

            cost = _compute_cost(sx, sy, irls_weights)
            return sx, sy, cost

        best_x, best_y, best_cost = _solve_gn_irls(refined_top[0][0], refined_top[0][1], weights)

        for cx, cy, _ in refined_top[1:]:
            cand_x, cand_y, cand_cost = _solve_gn_irls(cx, cy, weights)
            if cand_cost < best_cost:
                best_x, best_y, best_cost = cand_x, cand_y, cand_cost

        res_adj = bilateral_resonance(circles, best_x, best_y, coupling=0.25)
        adjusted_weights = [max(0.01, weights[i] * (1.0 + res_adj[i] * 0.001)) for i in range(len(circles))]
        res_x, res_y, res_cost = _solve_gn_irls(best_x, best_y, adjusted_weights)
        if res_cost < best_cost * 1.05:
            best_x, best_y, best_cost = res_x, res_y, res_cost

        px, py = best_x, best_y
        tri_lat = ref_lat + py / M_PER_DEG
        tri_lng = ref_lng + px / m_per_lng
    else:
        tri_lat = sum(c['tower']['lat'] for c in circles) / len(circles)
        tri_lng = sum(c['tower']['lng'] for c in circles) / len(circles)
        px, py = 0, 0

    tower_positions = [(c['x'], c['y']) for c in circles]
    gdop = compute_gdop(tower_positions, px, py)

    if wifi_position and wifi_position.get('lat') and wifi_position.get('lng'):
        wifi_lat = wifi_position['lat']
        wifi_lng = wifi_position['lng']
        wifi_acc = wifi_position.get('accuracy_m', 50)
        n_aps = wifi_position.get('aps_used', 3)

        wifi_dist = haversine_distance(tri_lat, tri_lng, wifi_lat, wifi_lng)

        avg_residual = 0
        for c in circles:
            dx_r = px - c['x']
            dy_r = py - c['y']
            d_r = math.sqrt(dx_r * dx_r + dy_r * dy_r)
            avg_residual += abs(d_r - c['radius'])
        avg_residual = avg_residual / max(len(circles), 1)
        cell_sigma = max(avg_residual * gdop * (1.0 / math.sqrt(max(len(circles), 1))), 10.0)

        ap_factor = max(0.5, 3.0 / max(n_aps, 1))
        wifi_sigma = max(wifi_acc * ap_factor, 5.0)

        max_reasonable = 3.0 * max(cell_sigma, wifi_sigma)

        if wifi_dist < max_reasonable and n_aps >= 3:
            w_cell = 1.0 / (cell_sigma ** 2)
            w_wifi = 1.0 / (wifi_sigma ** 2)
            w_total = w_cell + w_wifi

            cell_pct = w_cell / w_total
            wifi_pct = w_wifi / w_total

            tri_lat = cell_pct * tri_lat + wifi_pct * wifi_lat
            tri_lng = cell_pct * tri_lng + wifi_pct * wifi_lng

            wifi_fusion = {
                'cell_weight_pct': round(cell_pct * 100, 1),
                'wifi_weight_pct': round(wifi_pct * 100, 1),
                'wifi_aps': n_aps,
                'wifi_accuracy_m': round(wifi_acc, 1),
                'wifi_distance_m': round(wifi_dist, 1),
                'cell_sigma_m': round(cell_sigma, 1),
                'wifi_sigma_m': round(wifi_sigma, 1),
                'fused_sigma_m': round(math.sqrt(1.0 / w_total), 1),
                'method': 'TriNet + WiFi IVW Fusion',
            }
        else:
            wifi_fusion = {
                'cell_weight_pct': 100.0,
                'wifi_weight_pct': 0.0,
                'wifi_aps': n_aps,
                'wifi_accuracy_m': round(wifi_acc, 1),
                'wifi_distance_m': round(wifi_dist, 1),
                'method': 'TriNet (WiFi rejected)',
                'wifi_rejected': True,
                'rejection_reason': 'distance' if wifi_dist >= max_reasonable else 'insufficient_aps',
            }
    else:
        wifi_fusion = None

    tower_distances = []
    max_dist = max(c['distance'] for c in circles) * 1.2 if circles else 1
    for c in circles:
        td_entry = {
            'tower_id': c['tower']['id'],
            'tower_lat': c['tower']['lat'],
            'tower_lng': c['tower']['lng'],
            'distance_m': round(c['distance']),
            'radius_m': round(c.get('quantized_radius', c['radius'])),
            'vig_level': quant_vig(c['distance'], 0, max_dist),
            'ternary_dist': c['ternary_dist'],
            'ternary_rsrp': c['ternary_rsrp'],
            'ternary_dist_sym': c['ternary_dist_symbol'],
            'ternary_rsrp_sym': c['ternary_rsrp_symbol'],
            'vig_dist': c.get('vig_dist', 10),
            'vig_rsrp': c.get('vig_rsrp', 10),
            'vig_dist_sym': c.get('vig_dist_symbol', '━━'),
            'vig_rsrp_sym': c.get('vig_rsrp_symbol', '━━'),
            'vig_distance': c.get('vig_distance', 0),
            'archetype': c.get('archetype', 0),
            'band': c['tower'].get('band', ''),
            'tech': c['tower'].get('tech', ''),
            'enodeb': c['tower'].get('enodeb', 0),
            'radio_type': c['tower'].get('radio_type', 'LTE'),
            'frequency_mhz': c.get('frequency_mhz', c['tower'].get('frequency_mhz', 2100)),
            'band_name': c['tower'].get('band_name', ''),
            'source': c['tower'].get('source', 'OpenCelliD'),
            'rssi': c['rssi'],
            'rsrp': c['rsrp'],
            'rsrq': c['rsrq'],
            'timing_advance': c['timing_advance'],
            'estimated_distance': c.get('estimated_distance', 0),
            'quantized_distance': c.get('quantized_distance', 0),
            'propagation_exponent': c.get('propagation_exponent', 3.5),
            'weight': c.get('weight', 1.0),
            'quality_gate': c.get('quality_gate', 1.0),
        }
        tower_distances.append(td_entry)

    avg_dist = sum(c['distance'] for c in circles) / len(circles)
    max_radius = max(c['radius'] for c in circles) if circles else 1
    avg_qg = sum(c.get('quality_gate', 1.0) for c in circles) / max(len(circles), 1)

    gdop_penalty = max(0, (gdop - 2.0) * 5)
    tower_bonus = min(len(circles) - 3, 5) * 3 if len(circles) > 3 else 0
    qg_bonus = max(0, (avg_qg - 0.5) * 10)
    confidence = max(0, min(100, 100 - (avg_dist / max_radius) * 30 - gdop_penalty + tower_bonus + qg_bonus))
    if wifi_fusion and not wifi_fusion.get('wifi_rejected'):
        wifi_boost = min(15, wifi_fusion.get('wifi_weight_pct', 0) * 0.15)
        confidence = min(100, confidence + wifi_boost)
    confidence_q6 = quant6(confidence)
    confidence_final = dequant6(confidence_q6)

    pascal_weights = build_pascal(max(3, min(7, len(tower_distances))))
    pascal_confidence = sum(
        w * (100 - d['distance_m'] / 100) for w, d in zip(pascal_weights[:len(tower_distances)], tower_distances)
    ) / sum(pascal_weights[:len(tower_distances)])
    pascal_confidence = max(0, min(100, pascal_confidence))

    geo_method = 'gps_triangulation' if real_lat is not None else 'simulated'

    n_towers = len(circles)
    base_acc = 35.0 - min(n_towers - 3, 5) * 3.5
    gdop_factor = max(0.6, min(2.5, gdop / 1.5))
    qg_factor = max(0.7, min(1.2, 1.3 - avg_qg * 0.5))
    import random as _acc_rng
    _acc_r = _acc_rng.Random(seed ^ 0xACCE55)
    jitter = _acc_r.gauss(1.0, 0.12)
    accuracy = base_acc * gdop_factor * qg_factor * max(0.75, min(1.25, jitter))
    if wifi_fusion and not wifi_fusion.get('wifi_rejected'):
        wifi_factor = max(0.5, 1.0 - wifi_fusion.get('wifi_weight_pct', 0) / 200.0)
        accuracy *= wifi_factor
    accuracy = max(8, min(accuracy, 150))

    if country_code == 'HN':
        snapped_lat, snapped_lng, was_snapped = _snap_to_land(tri_lat, tri_lng, phone_number=phone_number)
        if was_snapped:
            tri_lat = snapped_lat
            tri_lng = snapped_lng
            logging.info(f"Triangulation road-snap applied for {phone_number}: position adjusted to nearest road/street")

    result = {
        'lat': round(tri_lat, 6),
        'lng': round(tri_lng, 6),
        'geo_method': geo_method,
        'towers_used': [c['tower'] for c in circles],
        'tower_distances': tower_distances,
        'towers_count': len(circles),
        'confidence': confidence_final,
        'pascal_confidence': round(pascal_confidence, 1),
        'accuracy_meters': round(accuracy),
        'gdop': round(gdop, 2),
        'method': 'TriNet-Pythag v2 (Tukey-IRLS+GainRatio)' + (' + WiFi-IVW' if wifi_fusion and not wifi_fusion.get('wifi_rejected') else ''),
        'quantization': 'vigesimal-20',
        'solver': 'GN-IRLS-TukeyBisquare',
        'quality_gates': {
            'avg_score': round(avg_qg, 3),
            'towers_gated': sum(1 for c in circles if c.get('quality_gate', 1.0) < 0.5),
            'towers_total': len(circles),
        },
        'motif_stats': motif_stats if 'motif_stats' in dir() else {},
    }
    if connection_info:
        result['connection'] = connection_info
    if wifi_fusion:
        result['wifi_fusion'] = wifi_fusion

    return result


def run_snn_layers(phone_data, towers, triangulation_result):
    layers = {}

    layers['L0'] = {
        'name': 'Parseo + Bake-in · Alpha',
        'status': 'complete',
        'horizon': 'alpha',
        'data': {
            'country': phone_data.get('country_code', ''),
            'carrier': phone_data.get('carrier', ''),
            'city': phone_data.get('city', ''),
            'area_code': phone_data.get('area_code', ''),
        }
    }

    layers['L1'] = {
        'name': 'Torres Filtradas (OpenCelliD) · Alpha',
        'status': 'complete',
        'horizon': 'alpha',
        'data': {
            'carrier_counts': {k: len(v) for k, v in towers.items() if v},
            'total': sum(len(v) for v in towers.values()),
            'source': 'OpenCelliD',
            'method': 'E-CID (RSRP+RSRQ+TA)',
        }
    }

    if triangulation_result:
        layers['L2'] = {
            'name': 'TriNet-Pythag v2 + Cost-231 · Alpha',
            'status': 'complete',
            'horizon': 'alpha',
            'data': {
                'lat': triangulation_result['lat'],
                'lng': triangulation_result['lng'],
                'towers_used': len(triangulation_result['towers_used']),
                'method': 'GN-IRLS Tukey Bisquare + Gain-Ratio LM',
                'propagation_model': 'Cost-231 Hata + Quality Gates',
                'weighting': 'Vigesimal RSRQ + NLOS Asymmetric Tukey',
                'fusion': triangulation_result.get('method', 'TriNet'),
            }
        }
    else:
        layers['L2'] = {
            'name': 'TriNet-Pythag v2 + Cost-231 · Alpha',
            'status': 'insufficient_data',
            'horizon': 'alpha',
            'data': {}
        }

    layers['L3'] = {
        'name': 'Suavizado SNN · Beta',
        'status': 'complete',
        'horizon': 'beta',
        'data': {
            'window_size': 5,
            'smoothing': 'moving_average',
            'alpha_q6': quant6(88 + (hash(str(phone_data)) % 12)),
            'beta_q6': quant6(68 + (hash(str(phone_data) + 'a') % 28)),
        }
    }

    if triangulation_result:
        pascal_w = build_pascal(5)
        layers['L4'] = {
            'name': 'Pascal Cascade · Beta',
            'status': 'complete',
            'horizon': 'beta',
            'data': {
                'depth': 5,
                'weights': [round(w, 4) for w in pascal_w],
                'gamma_confidence': triangulation_result['pascal_confidence'],
            }
        }
    else:
        layers['L4'] = {
            'name': 'Pascal Cascade · Beta',
            'status': 'waiting',
            'horizon': 'beta',
            'data': {}
        }

    if triangulation_result:
        td = triangulation_result.get('tower_distances', [])
        vig_cats = []
        for d in td:
            level = d['vig_level']
            if level < 4:
                cat = 'EXCELENTE'
            elif level < 8:
                cat = 'BUENA'
            elif level < 12:
                cat = 'MODERADA'
            elif level < 16:
                cat = 'BAJA'
            else:
                cat = 'MUY BAJA'
            vig_cats.append({'tower': d['tower_id'], 'level': level, 'category': cat})
        layers['L5'] = {
            'name': 'Cuantización Ternaria · Beta',
            'status': 'complete',
            'horizon': 'beta',
            'data': {
                'categories': vig_cats,
                'quantization': 'ternary',
                'symbols': ['◎', '•', '━'],
                'towers_count': len(td),
            }
        }
    else:
        layers['L5'] = {
            'name': 'Cuantización Ternaria · Beta',
            'status': 'waiting',
            'horizon': 'beta',
            'data': {}
        }

    layers['L6'] = {
        'name': 'Clima + AQI · Gamma',
        'status': 'deferred',
        'horizon': 'gamma',
        'data': {
            'method': 'async_client_fetch',
            'endpoint': '/api/weather',
            'note': 'Fetched asynchronously on client via Open-Meteo API',
        }
    }

    layers['L7'] = {
        'name': 'Latencia de Red · Gamma',
        'status': 'deferred',
        'horizon': 'gamma',
        'data': {
            'method': 'async_client_measurement',
            'timing': 'performance.now() (sub-millisecond)',
            'note': 'Network latency measured client-side; WASM computation benchmark runs independently',
        }
    }

    return layers


def fetch_weather_data(lat, lng):
    try:
        url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lng}&current=temperature_2m,relative_humidity_2m,rain,wind_speed_10m,cloud_cover,surface_pressure&temperature_unit=fahrenheit&wind_speed_unit=mph&timezone=auto"
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            current = data.get('current', {})
            return {
                'temperature': current.get('temperature_2m', 0),
                'humidity': current.get('relative_humidity_2m', 0),
                'rain': current.get('rain', 0),
                'wind_speed': current.get('wind_speed_10m', 0),
                'cloud_cover': current.get('cloud_cover', 0),
                'pressure': current.get('surface_pressure', 0),
            }
    except Exception as e:
        logging.error(f"Weather fetch error: {e}")
    return None


def fetch_aqi_data(lat, lng):
    try:
        url = f"https://air-quality-api.open-meteo.com/v1/air-quality?latitude={lat}&longitude={lng}&current=us_aqi,pm2_5,pm10,ozone,nitrogen_dioxide,sulphur_dioxide,carbon_monoxide"
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            current = data.get('current', {})
            return {
                'aqi': current.get('us_aqi', 0),
                'pm25': current.get('pm2_5', 0),
                'pm10': current.get('pm10', 0),
                'o3': current.get('ozone', 0),
                'no2': current.get('nitrogen_dioxide', 0),
                'so2': current.get('sulphur_dioxide', 0),
                'co': current.get('carbon_monoxide', 0),
            }
    except Exception as e:
        logging.error(f"AQI fetch error: {e}")
    return None
