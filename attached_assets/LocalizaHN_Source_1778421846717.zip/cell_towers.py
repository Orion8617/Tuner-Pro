import math
import logging

from opencellid_etl import load_towers_from_csv, MCC_CONFIGS

logger = logging.getLogger(__name__)

MCC_HN = 708
MCC_GT = 704
MCC_US = 310
MNC_TIGO_HN = 2
MNC_CLARO_HN = 1
MNC_DIGICEL_HN = 40
MNC_TIGO_GT = 1
MNC_CLARO_GT = 3
MNC_ATT_US = 410
MNC_TMOBILE_US = 260
MNC_VERIZON_US = 12

ALL_CARRIER_KEYS = set()
for _mcc_cfg in MCC_CONFIGS.values():
    for _op in _mcc_cfg["operators"].values():
        ALL_CARRIER_KEYS.add(_op["carrier_key"])


def _load_carrier_towers(carrier_key):
    result = {}
    for mcc, config in MCC_CONFIGS.items():
        country = config["country"]
        carriers = load_towers_from_csv(mcc)
        cities = carriers.get(carrier_key, {})
        if cities:
            result[country] = cities
    return result


TIGO_TOWERS = _load_carrier_towers("tigo")
CLARO_TOWERS = _load_carrier_towers("claro")
DIGICEL_TOWERS = _load_carrier_towers("digicel")
ATT_TOWERS = _load_carrier_towers("att")
TMOBILE_TOWERS = _load_carrier_towers("tmobile")
VERIZON_TOWERS = _load_carrier_towers("verizon")

CARRIER_TOWER_MAP = {
    "tigo": TIGO_TOWERS,
    "claro": CLARO_TOWERS,
    "digicel": DIGICEL_TOWERS,
    "att": ATT_TOWERS,
    "tmobile": TMOBILE_TOWERS,
    "verizon": VERIZON_TOWERS,
}

_tower_counts = {}
for _ck, _td in CARRIER_TOWER_MAP.items():
    _tower_counts[_ck] = sum(len(ts) for cc in _td.values() for ts in cc.values())
logger.info(
    f"Loaded towers from CSV: {', '.join(f'{k}={v}' for k, v in _tower_counts.items() if v > 0)}"
)

CARRIER_MAPPING = {
    "Tigo": "tigo",
    "TIGO": "tigo",
    "tigo": "tigo",
    "Claro": "claro",
    "CLARO": "claro",
    "claro": "claro",
    "Digicel": "digicel",
    "DIGICEL": "digicel",
    "digicel": "digicel",
    "Comunicaciones Celulares": "tigo",
    "Servicios de Comunicaciones": "claro",
    "Millicom": "tigo",
    "América Móvil": "claro",
    "Telefonica": "tigo",
    "Newcom": "claro",
    "Digicel Group": "digicel",
    "AT&T": "att",
    "ATT": "att",
    "att": "att",
    "AT&T Mobility": "att",
    "at&t": "att",
    "Cingular": "att",
    "AT&T Wireless": "att",
    "T-Mobile": "tmobile",
    "TMOBILE": "tmobile",
    "tmobile": "tmobile",
    "T-Mobile USA": "tmobile",
    "MetroPCS": "tmobile",
    "Sprint": "tmobile",
    "Verizon": "verizon",
    "VERIZON": "verizon",
    "verizon": "verizon",
    "Verizon Wireless": "verizon",
    "Cellco": "verizon",
}

HN_MOBILE_PREFIXES = {"9": "tigo", "8": "tigo", "3": "claro"}
GT_MOBILE_PREFIXES = {"5": "tigo", "4": "claro", "3": "claro"}
MOBILE_PREFIXES = {"HN": HN_MOBILE_PREFIXES, "GT": GT_MOBILE_PREFIXES}

HN_DEPARTMENTS = {
    "Atlántida": {
        "capital": "La Ceiba",
        "cities": [
            "La Ceiba",
            "Tela",
            "La Masica",
            "El Porvenir",
            "Jutiapa",
            "San Francisco",
            "Arizona",
            "Esparta",
        ],
    },
    "Colón": {
        "capital": "Trujillo",
        "cities": [
            "Trujillo",
            "Tocoa",
            "Sabá",
            "Sonaguera",
            "Bonito Oriental",
            "Balfate",
            "Iriona",
            "Limón",
            "Santa Fe",
            "Santa Rosa de Aguán",
        ],
    },
    "Comayagua": {
        "capital": "Comayagua",
        "cities": [
            "Comayagua",
            "Siguatepeque",
            "La Libertad",
            "Lejamaní",
            "Ajuterique",
            "San Jerónimo",
            "Las Lajas",
            "Taulabé",
        ],
    },
    "Copán": {
        "capital": "Santa Rosa de Copán",
        "cities": [
            "Santa Rosa de Copán",
            "Copán Ruinas",
            "La Entrada",
            "Florida",
            "Dulce Nombre",
            "San Pedro",
            "Cucuyagua",
        ],
    },
    "Cortés": {
        "capital": "San Pedro Sula",
        "cities": [
            "San Pedro Sula",
            "La Lima",
            "Choloma",
            "Villanueva",
            "Puerto Cortés",
            "Omoa",
            "Pimienta",
            "Potrerillos",
            "San Manuel",
            "San Francisco de Yojoa",
            "Santa Cruz de Yojoa",
        ],
    },
    "Choluteca": {
        "capital": "Choluteca",
        "cities": [
            "Choluteca",
            "Pespire",
            "San Marcos de Colón",
            "Marcovia",
            "El Triunfo",
            "Namasigüe",
            "El Corpus",
            "Concepción de María",
        ],
    },
    "El Paraíso": {
        "capital": "Yuscarán",
        "cities": [
            "Yuscarán",
            "Danlí",
            "El Paraíso",
            "Jacaleapa",
            "Morocelí",
            "Potrerillos",
            "San Antonio de Flores",
            "Alauca",
            "Güinope",
        ],
    },
    "Francisco Morazán": {
        "capital": "Tegucigalpa",
        "cities": [
            "Tegucigalpa",
            "Comayagüela",
            "Valle de Ángeles",
            "Santa Lucía",
            "Talanga",
            "Guaimaca",
            "Sabanagrande",
            "Ojojona",
            "San Juan de Flores",
        ],
    },
    "Gracias a Dios": {
        "capital": "Puerto Lempira",
        "cities": [
            "Puerto Lempira",
            "Brus Laguna",
            "Ahuas",
            "Juan Francisco Bulnes",
            "Villeda Morales",
            "Wampusirpi",
        ],
    },
    "Intibucá": {
        "capital": "La Esperanza",
        "cities": [
            "La Esperanza",
            "Intibucá",
            "Jesús de Otoro",
            "Yamaranguila",
            "San Juan",
            "San Marcos de la Sierra",
        ],
    },
    "Islas de la Bahía": {
        "capital": "Roatán",
        "cities": [
            "Roatán",
            "Coxen Hole",
            "French Harbour",
            "West End",
            "Utila",
            "Guanaja",
            "José Santos Guardiola",
        ],
    },
    "La Paz": {
        "capital": "La Paz",
        "cities": [
            "La Paz",
            "Marcala",
            "Cane",
            "Chinacla",
            "Santa Ana",
            "Santiago de Puringla",
        ],
    },
    "Lempira": {
        "capital": "Gracias",
        "cities": [
            "Gracias",
            "La Unión",
            "Lepaera",
            "San Manuel Colohete",
            "La Iguala",
            "Erandique",
            "San Andrés",
        ],
    },
    "Ocotepeque": {
        "capital": "Ocotepeque",
        "cities": [
            "Ocotepeque",
            "La Labor",
            "Sinuapa",
            "Concepción",
            "San Marcos",
            "Santa Fe",
            "Sensenti",
        ],
    },
    "Olancho": {
        "capital": "Juticalpa",
        "cities": [
            "Juticalpa",
            "Catacamas",
            "San Francisco de la Paz",
            "Gualaco",
            "Campamento",
            "Dulce Nombre de Culmí",
            "Salamá",
        ],
    },
    "Santa Bárbara": {
        "capital": "Santa Bárbara",
        "cities": [
            "Santa Bárbara",
            "Trinidad",
            "Quimistán",
            "Macuelizo",
            "Ilama",
            "Las Vegas",
            "Petoa",
            "Concepción del Norte",
        ],
    },
    "Valle": {
        "capital": "Nacaome",
        "cities": [
            "Nacaome",
            "San Lorenzo",
            "Langue",
            "Amapala",
            "Goascorán",
            "Alianza",
            "Caridad",
        ],
    },
    "Yoro": {
        "capital": "Yoro",
        "cities": [
            "Yoro",
            "El Progreso",
            "Morazán",
            "Olanchito",
            "Santa Rita",
            "Sulaco",
            "El Negrito",
            "Jocón",
            "Arenal",
            "Victoria",
        ],
    },
}

CITY_AREA_CODE_MAP = {
    "HN": {
        "22": "Tegucigalpa",
        "25": "San Pedro Sula",
        "24": "La Ceiba",
        "27": "Comayagua",
        "28": "Choluteca",
        "26": "Santa Rosa de Copán",
        "29": "Juticalpa",
        "31": "Puerto Cortés",
        "32": "El Progreso",
        "33": "Tela",
        "37": "Siguatepeque",
        "36": "Danlí",
    },
    "GT": {
        "22": "Ciudad de Guatemala",
        "23": "Ciudad de Guatemala",
        "77": "Quetzaltenango",
        "78": "Escuintla",
        "66": "Villa Nueva",
        "79": "Cobán",
    },
    "US": {
        "504": "New Orleans",
        "225": "Baton Rouge",
        "318": "Shreveport",
        "337": "Lafayette",
        "985": "Mandeville",
    },
}

NETWORK_INFO = {
    "HN": {
        "tigo": {
            "mcc": 708,
            "mnc": 2,
            "name": "Tigo Honduras (Millicom)",
            "plmn": "708-02",
            "bands_lte": ["B4 (AWS 1700/2100 EARFCN:2050)", "B5 (CLR 850 EARFCN:2543)"],
            "bands_gsm": ["850MHz"],
            "bands_umts": ["850MHz"],
            "market_share": 0.60,
            "lte_launch": "2014-12",
        },
        "claro": {
            "mcc": 708,
            "mnc": 1,
            "name": "Claro Honduras (América Móvil)",
            "plmn": "708-01",
            "bands_lte": ["B4 (AWS 1700/2100 EARFCN:2050)"],
            "bands_gsm": ["1900MHz"],
            "bands_umts": ["1900MHz (B2)"],
            "market_share": 0.39,
            "lte_launch": "2015-03",
        },
        "digicel": {
            "mcc": 708,
            "mnc": 40,
            "name": "Digicel Honduras (vendido a Claro 2011)",
            "plmn": "708-40",
            "bands_lte": [],
            "bands_gsm": ["850MHz"],
            "bands_umts": ["850MHz"],
            "market_share": 0.0,
            "status": "inactive_sold_2011",
        },
    },
    "GT": {
        "tigo": {
            "mcc": 704,
            "mnc": 1,
            "name": "Tigo Guatemala",
            "plmn": "704-01",
            "bands_lte": ["B2", "B4"],
            "bands_gsm": ["850MHz", "1900MHz"],
        },
        "claro": {
            "mcc": 704,
            "mnc": 3,
            "name": "Claro Guatemala",
            "plmn": "704-03",
            "bands_lte": ["B2", "B4"],
            "bands_gsm": ["850MHz", "1900MHz"],
        },
    },
    "US": {
        "att": {
            "mcc": 310,
            "mnc": 410,
            "name": "AT&T Mobility",
            "plmn": "310-410",
            "bands_lte": [
                "B2 (1900MHz)",
                "B4 (AWS 1700/2100)",
                "B12 (700MHz)",
                "B5 (850MHz)",
            ],
            "bands_gsm": ["850MHz", "1900MHz"],
            "bands_umts": ["850MHz", "1900MHz"],
        },
        "tmobile": {
            "mcc": 310,
            "mnc": 260,
            "name": "T-Mobile US",
            "plmn": "310-260",
            "bands_lte": ["B2 (1900MHz)", "B4 (AWS 1700/2100)", "B12 (700MHz)"],
            "bands_gsm": ["1900MHz"],
            "bands_umts": ["1900MHz"],
        },
        "verizon": {
            "mcc": 310,
            "mnc": 12,
            "name": "Verizon Wireless",
            "plmn": "310-12",
            "bands_lte": ["B2 (1900MHz)", "B4 (AWS 1700/2100)", "B12 (700MHz)"],
            "bands_gsm": [],
            "bands_umts": ["850MHz"],
        },
    },
}


def get_network_info(country_code, carrier_key):
    return NETWORK_INFO.get(country_code, {}).get(carrier_key, {})


def _get_country_carriers(country_code):
    for mcc, config in MCC_CONFIGS.items():
        if config["country"] == country_code:
            return [op["carrier_key"] for op in config["operators"].values()]
    return ["tigo", "claro", "digicel"]


def get_towers_for_carrier(country_code, city, carrier_key):
    tower_dict = CARRIER_TOWER_MAP.get(carrier_key)
    if tower_dict:
        return tower_dict.get(country_code, {}).get(city, [])
    return []


def get_all_towers_for_city(country_code, city):
    result = {}
    for carrier_key, tower_dict in CARRIER_TOWER_MAP.items():
        towers = tower_dict.get(country_code, {}).get(city, [])
        if towers:
            result[carrier_key] = towers
    if not result:
        for ck in _get_country_carriers(country_code):
            result[ck] = []
    return result


def get_available_cities(country_code):
    cities = set()
    for tower_dict in CARRIER_TOWER_MAP.values():
        for c in tower_dict.get(country_code, {}).keys():
            cities.add(c)
    return sorted(list(cities))


def resolve_carrier(carrier_name):
    if not carrier_name:
        return None
    for key, value in CARRIER_MAPPING.items():
        if key.lower() in carrier_name.lower():
            return value
    return None


def resolve_carrier_from_mobile_prefix(country_code, national_number):
    if not national_number or country_code not in MOBILE_PREFIXES:
        return None
    first_digit = str(national_number).strip()[0]
    return MOBILE_PREFIXES.get(country_code, {}).get(first_digit)


def is_mobile_number(country_code, national_number):
    if not national_number or country_code not in MOBILE_PREFIXES:
        return False
    first_digit = str(national_number).strip()[0]
    return first_digit in MOBILE_PREFIXES.get(country_code, {})


def get_city_from_area_code(country_code, area_code):
    return CITY_AREA_CODE_MAP.get(country_code, {}).get(area_code)


def get_department_for_city(city_name):
    for dept_name, dept_info in HN_DEPARTMENTS.items():
        if city_name in dept_info["cities"]:
            return dept_name
    return None


HN_MOBILE_CITIES_WEIGHTED = [
    ("San Pedro Sula", 30),
    ("Tegucigalpa", 28),
    ("La Ceiba", 8),
    ("Choloma", 7),
    ("El Progreso", 5),
    ("Comayagua", 4),
    ("Choluteca", 4),
    ("La Lima", 3),
    ("Puerto Cortés", 3),
    ("Villanueva", 3),
    ("Danlí", 2),
    ("Siguatepeque", 2),
    ("Juticalpa", 1),
]

GT_MOBILE_CITIES_WEIGHTED = [
    ("Ciudad de Guatemala", 50),
    ("Quetzaltenango", 15),
    ("Mixco", 10),
    ("Villa Nueva", 8),
    ("Escuintla", 5),
    ("Cobán", 4),
    ("Huehuetenango", 4),
    ("Mazatenango", 4),
]


def detect_city_for_mobile(country_code, phone_number):
    if country_code == "HN":
        city_list = HN_MOBILE_CITIES_WEIGHTED
    elif country_code == "GT":
        city_list = GT_MOBILE_CITIES_WEIGHTED
    else:
        return get_default_city_for_mobile(country_code)

    digits = "".join(c for c in str(phone_number) if c.isdigit())
    h = 0
    for ch in digits:
        h = (h * 31 + int(ch)) & 0xFFFFFFFF

    total_weight = sum(w for _, w in city_list)
    pick = h % total_weight
    cumulative = 0
    for city_name, weight in city_list:
        cumulative += weight
        if pick < cumulative:
            return city_name
    return city_list[0][0]


def get_default_city_for_mobile(country_code):
    if country_code == "HN":
        return "San Pedro Sula"
    elif country_code == "GT":
        return "Ciudad de Guatemala"
    elif country_code == "US":
        return "New Orleans"
    return None


CITY_TO_DEPARTMENT = {}
for _dept, _info in HN_DEPARTMENTS.items():
    for _city in _info["cities"]:
        CITY_TO_DEPARTMENT[_city] = _dept


def get_all_towers_in_department(country_code, department):
    all_tigo = []
    all_claro = []
    all_digicel = []
    dept_info = HN_DEPARTMENTS.get(department)
    if not dept_info:
        return {"tigo": [], "claro": [], "digicel": []}
    dept_cities = dept_info["cities"]
    for city in dept_cities:
        tigo = TIGO_TOWERS.get(country_code, {}).get(city, [])
        claro = CLARO_TOWERS.get(country_code, {}).get(city, [])
        digicel = DIGICEL_TOWERS.get(country_code, {}).get(city, [])
        for t in tigo:
            t_copy = dict(t)
            t_copy["city"] = city
            all_tigo.append(t_copy)
        for t in claro:
            t_copy = dict(t)
            t_copy["city"] = city
            all_claro.append(t_copy)
        for t in digicel:
            t_copy = dict(t)
            t_copy["city"] = city
            all_digicel.append(t_copy)
    return {"tigo": all_tigo, "claro": all_claro, "digicel": all_digicel}


def _collect_towers_in_range(
    tower_dict, country_code, center_lat, center_lng, cos_lat, range_km
):
    result = []
    for city, towers in tower_dict.get(country_code, {}).items():
        for t in towers:
            dlat = (t["lat"] - center_lat) * 111.32
            dlng = (t["lng"] - center_lng) * 111.32 * cos_lat
            dist = math.sqrt(dlat * dlat + dlng * dlng)
            if dist <= range_km:
                t_copy = dict(t)
                t_copy["city"] = city
                t_copy["dist_km"] = round(dist, 2)
                result.append(t_copy)
    result.sort(key=lambda t: t["dist_km"])
    return result


def get_all_towers_in_range(country_code, center_lat, center_lng, range_km=25):
    cos_lat = math.cos(center_lat * math.pi / 180)
    result = {}
    for carrier_key, tower_dict in CARRIER_TOWER_MAP.items():
        collected = _collect_towers_in_range(
            tower_dict, country_code, center_lat, center_lng, cos_lat, range_km
        )
        if collected:
            result[carrier_key] = collected
    if not result:
        for ck in _get_country_carriers(country_code):
            result[ck] = []
    return result


def detect_location_from_towers(country_code, center_lat, center_lng, carrier_key=None):
    towers = get_all_towers_in_range(country_code, center_lat, center_lng, range_km=30)
    if carrier_key and carrier_key in towers:
        nearby = towers[carrier_key]
    else:
        nearby = []
        for t_list in towers.values():
            nearby.extend(t_list)
        nearby.sort(key=lambda t: t.get("dist_km", 999))
    if nearby:
        closest = nearby[0]
        return closest.get("city", "Unknown")
    return "Unknown"
