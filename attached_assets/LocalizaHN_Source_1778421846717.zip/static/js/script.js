// Client-side phone number handling with country selection
document.addEventListener('DOMContentLoaded', function() {
    const countrySelect = document.getElementById('country_select');
    const phoneDisplay = document.getElementById('phone_display');
    const phoneNumberField = document.getElementById('phone_number');
    const selectedCodeSpan = document.getElementById('selected-code');
    const phoneForm = document.getElementById('phone-form');
    const areaCodesContainer = document.getElementById('area-codes-container');
    let areaCodesLoaded = {};
    
    // Function to format phone number based on country
    function formatPhoneNumber(phoneNumber, countryCode) {
        // Remove all non-digit characters
        const digits = phoneNumber.replace(/\D/g, '');
        
        // Format based on country code
        switch(countryCode) {
            case 'US':
            case 'CA':
                // Format: (XXX) XXX-XXXX
                if (digits.length <= 3) {
                    return digits;
                } else if (digits.length <= 6) {
                    return `(${digits.substring(0, 3)}) ${digits.substring(3)}`;
                } else {
                    return `(${digits.substring(0, 3)}) ${digits.substring(3, 6)}-${digits.substring(6, 10)}`;
                }
                
            case 'GB':
                // UK format: XXXX XXXXXX
                if (digits.length <= 4) {
                    return digits;
                } else {
                    return `${digits.substring(0, 4)} ${digits.substring(4)}`;
                }
                
            case 'ES':
                // Spain format: XXX XX XX XX
                if (digits.length <= 3) {
                    return digits;
                } else if (digits.length <= 5) {
                    return `${digits.substring(0, 3)} ${digits.substring(3)}`;
                } else if (digits.length <= 7) {
                    return `${digits.substring(0, 3)} ${digits.substring(3, 5)} ${digits.substring(5)}`;
                } else {
                    return `${digits.substring(0, 3)} ${digits.substring(3, 5)} ${digits.substring(5, 7)} ${digits.substring(7)}`;
                }
                
            case 'MX':
            case 'AR':
            case 'BR':
            case 'CO':
                // Latin American format: XXX XXX XXXX
                if (digits.length <= 3) {
                    return digits;
                } else if (digits.length <= 6) {
                    return `${digits.substring(0, 3)} ${digits.substring(3)}`;
                } else {
                    return `${digits.substring(0, 3)} ${digits.substring(3, 6)} ${digits.substring(6)}`;
                }
                
            // Default formatting (groups of 3-4 digits)
            default:
                if (digits.length <= 4) {
                    return digits;
                } else {
                    // Group in chunks of 3 or 4
                    let formatted = '';
                    for (let i = 0; i < digits.length; i += 3) {
                        if (formatted) formatted += ' ';
                        formatted += digits.substring(i, Math.min(i + 3, digits.length));
                    }
                    return formatted;
                }
        }
    }
    
    // Function to update the hidden phone field with the full international format
    function updatePhoneNumber() {
        if (!phoneDisplay || !phoneNumberField || !countrySelect) return;
        
        const selectedOption = countrySelect.options[countrySelect.selectedIndex];
        const countryCode = selectedOption.value;
        const phoneCode = selectedOption.dataset.phoneCode;
        
        // Get only the digits from the display field
        const digits = phoneDisplay.value.replace(/\D/g, '');
        
        // Set the hidden field with the international format: +[code][number]
        phoneNumberField.value = `+${phoneCode}${digits}`;
    }
    
    // Function to load and display area codes for a country
    function loadAreaCodes(countryCode) {
        if (!areaCodesContainer) return;
        
        // If we've already loaded this country's codes, just show them
        if (areaCodesLoaded[countryCode]) {
            areaCodesContainer.innerHTML = areaCodesLoaded[countryCode];
            areaCodesContainer.style.display = 'block';
            return;
        }
        
        // Otherwise fetch from the server
        fetch(`/area-codes/${countryCode}`)
            .then(response => response.json())
            .then(data => {
                if (Object.keys(data).length === 0) {
                    areaCodesContainer.style.display = 'none';
                    return;
                }
                
                // Create HTML for the area codes
                let html = `
                    <div class="card mt-3">
                        <div class="card-header bg-secondary text-white">
                            <h5 class="mb-0">
                                <i class="fas fa-map-marker-alt me-2"></i>
                                Common Area Codes
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                `;
                
                // Add each city with its area codes
                for (const city in data) {
                    html += `
                        <div class="col-md-6 col-lg-4">
                            <div class="d-flex align-items-center">
                                <span class="badge bg-info me-2">
                                    ${data[city]}
                                </span>
                                <span>${city}</span>
                            </div>
                        </div>
                    `;
                }
                
                html += `
                            </div>
                        </div>
                    </div>
                `;
                
                // Save the generated HTML
                areaCodesLoaded[countryCode] = html;
                
                // Display the area codes if we're still on the same country
                const currentCountry = countrySelect.options[countrySelect.selectedIndex].value;
                if (currentCountry === countryCode) {
                    areaCodesContainer.innerHTML = html;
                    areaCodesContainer.style.display = 'block';
                }
            })
            .catch(error => {
                console.error('Error loading area codes:', error);
                areaCodesContainer.style.display = 'none';
            });
    }
    
    // Update phone code display when country changes
    if (countrySelect && selectedCodeSpan) {
        // Initial setup
        const initialOption = countrySelect.options[countrySelect.selectedIndex];
        selectedCodeSpan.textContent = initialOption.dataset.phoneCode;
        
        // Load the initial country's area codes
        if (areaCodesContainer) {
            loadAreaCodes(initialOption.value);
        }
        
        // When country changes
        countrySelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const countryCode = selectedOption.value;
            selectedCodeSpan.textContent = selectedOption.dataset.phoneCode;
            
            // Also update the phone number field formatting
            if (phoneDisplay) {
                const currentDigits = phoneDisplay.value.replace(/\D/g, '');
                phoneDisplay.value = formatPhoneNumber(currentDigits, countryCode);
                updatePhoneNumber();
            }
            
            // Load area codes for the selected country
            if (areaCodesContainer) {
                loadAreaCodes(countryCode);
            }
        });
    }
    
    // Format phone number as user types
    if (phoneDisplay) {
        phoneDisplay.addEventListener('input', function() {
            const countryCode = countrySelect.options[countrySelect.selectedIndex].value;
            
            // Store cursor position
            const cursorPos = this.selectionStart;
            const oldLength = this.value.length;
            
            // Format the number
            const digits = this.value.replace(/\D/g, '');
            const formatted = formatPhoneNumber(digits, countryCode);
            this.value = formatted;
            
            // Adjust cursor position after formatting
            const newLength = this.value.length;
            const cursorAdjust = newLength - oldLength;
            this.setSelectionRange(cursorPos + cursorAdjust, cursorPos + cursorAdjust);
            
            // Update the hidden field
            updatePhoneNumber();
        });
    }
    
    // Handle form submission
    if (phoneForm) {
        phoneForm.addEventListener('submit', function(e) {
            // Make sure to update the hidden field with the full international number
            updatePhoneNumber();
            
            // Additional validation for the hidden field
            if (phoneNumberField && (!phoneNumberField.value || phoneNumberField.value === '+')) {
                e.preventDefault();
                alert('Please enter a valid phone number');
            }
        });
    }
});
