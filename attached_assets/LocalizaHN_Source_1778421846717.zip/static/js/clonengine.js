const DEG2RAD = Math.PI / 180;
const M_PER_DEG = 111320;
const ARC = 50.3;
const VIG_LEVELS = 20;
const Q6_MAX = 63;
const Q6_INV = 100 / Q6_MAX;
const HIST_SIZE = 5;

let wasmEngine = null;
let wasmReady = false;
let wasmSnnWarnShown = false;
let map = null;
let carrierLayers = {};
let carrierVisible = {};
let triangulationLayerGroup = null;
let neatGen = 0;
let snnInterval = null;
let clockInterval = null;
let measureMode = false;
let measurePoints = [];
let measureLine = null;
let measureMarkers = [];
let measureTooltip = null;
let accuracyCircle = null;
let layerPanelOpen = false;
let lastTriData = null;
let darkTileLayer = null;
let satTileLayer = null;
let isSatellite = false;

const CARRIER_COLORS = {
  tigo: '#58a6ff', claro: '#4488ff', digicel: '#ff6633',
  att: '#00a8e0', tmobile: '#e20074', verizon: '#cd040b',
};
const CARRIER_LABELS = {
  tigo: 'TIGO', claro: 'CLARO', digicel: 'DIGICEL',
  att: 'AT&T', tmobile: 'T-MOBILE', verizon: 'VERIZON',
};

const PASCAL_CACHE = {};
function buildPascal(n) {
  if (PASCAL_CACHE[n]) return PASCAL_CACHE[n];
  let row = [1];
  for (let i = 1; i <= n; i++) {
    const nx = [1];
    for (let j = 1; j < row.length; j++) nx.push(row[j - 1] + row[j]);
    nx.push(1);
    row = nx;
  }
  const s = row.reduce((a, b) => a + b, 0);
  PASCAL_CACHE[n] = row.map(v => v / s);
  return PASCAL_CACHE[n];
}
[3, 4, 5, 6, 7].forEach(buildPascal);

function quantVig(value, min, max) {
  if (max === min) return 0;
  const norm = Math.max(0, Math.min(1, (value - min) / (max - min)));
  return Math.round(norm * (VIG_LEVELS - 1));
}

function quant6(pct) {
  return Math.round(Math.max(0, Math.min(100, pct)) / 100 * Q6_MAX);
}

function dequant6(q) {
  return Math.round(q * Q6_INV);
}

function smoothIntensity(cell, newVal) {
  if (!cell.hist) cell.hist = Array(HIST_SIZE).fill(newVal);
  cell.hist.push(newVal);
  if (cell.hist.length > HIST_SIZE) cell.hist.shift();
  return cell.hist.reduce((a, b) => a + b, 0) / cell.hist.length;
}

async function initWasm() {
  try {
    const script = document.createElement('script');
    script.type = 'module';
    const cacheBust = Date.now();
    script.textContent = `
      import init, * as wasm from '/static/wasm/triangulation_engine.js?v=${cacheBust}';
      await init();
      wasm.init_engine();
      window.__wasmEngine = wasm;
      window.dispatchEvent(new Event('wasm-ready'));
    `;
    document.head.appendChild(script);

    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('WASM timeout')), 10000);
      window.addEventListener('wasm-ready', () => {
        clearTimeout(timeout);
        resolve();
      }, { once: true });
    });

    wasmEngine = window.__wasmEngine;
    wasmReady = true;
    pushAlert('ok', 'MOTOR', 'Motor de cálculo cargado');
    updateLoadingMsg('MOTOR DE CÁLCULO ACTIVO');

    const info = JSON.parse(wasmEngine.engine_info());
    console.log('LocalizaHN WASM:', info);

    return true;
  } catch (e) {
    console.warn('WASM load failed, using JS fallback:', e);
    pushAlert('warn', 'MOTOR', 'Usando motor JavaScript alternativo');
    return false;
  }
}

function updateLoadingMsg(msg) {
  const el = document.getElementById('ldMsg');
  if (el) el.textContent = msg;
}

let phoneMarker = null;
let pingLayerGroup = null;

function initMap(lat, lng, city, zoomLevel) {
  map = L.map('map', {
    center: [lat, lng],
    zoom: zoomLevel || 13,
    zoomControl: false,
    attributionControl: false,
    keyboard: true,
    doubleClickZoom: true,
    scrollWheelZoom: true,
    touchZoom: true,
    boxZoom: true,
  });

  darkTileLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    maxZoom: 19,
    attribution: '&copy; CartoDB'
  }).addTo(map);

  satTileLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19,
    attribution: '&copy; Esri'
  });

  triangulationLayerGroup = L.layerGroup().addTo(map);
  pingLayerGroup = L.layerGroup().addTo(map);

  const coordsEl = document.getElementById('mapCoords');
  if (coordsEl) {
    map.on('mousemove', function(e) {
      coordsEl.textContent = e.latlng.lat.toFixed(6) + ', ' + e.latlng.lng.toFixed(6) + ' · Z' + map.getZoom();
    });
    map.on('zoomend', function() {
      const c = map.getCenter();
      coordsEl.textContent = c.lat.toFixed(6) + ', ' + c.lng.toFixed(6) + ' · Z' + map.getZoom();
    });
  }

  map.on('click', function(e) {
    if (measureMode) {
      addMeasurePoint(e.latlng);
    }
  });
}

function mapZoomIn() { if (map) map.zoomIn(1, { animate: true }); }
function mapZoomOut() { if (map) map.zoomOut(1, { animate: true }); }
function mapFitAll() {
  if (!map) return;
  const group = new L.FeatureGroup();
  Object.values(carrierLayers).forEach(lg => lg.eachLayer(l => group.addLayer(l)));
  if (phoneMarker) group.addLayer(phoneMarker);
  if (group.getLayers().length > 0) {
    map.fitBounds(group.getBounds().pad(0.15), { animate: true, duration: .6 });
  }
}
function mapCenterTarget() {
  if (!map || !lastTriData) return;
  map.setView([lastTriData.lat, lastTriData.lng], 16, { animate: true, duration: .6 });
}

function toggleMeasure() {
  measureMode = !measureMode;
  const btn = document.getElementById('tbMeasure');
  if (btn) btn.classList.toggle('active', measureMode);
  if (!measureMode) {
    clearMeasure();
  } else {
    measurePoints = [];
    if (map) map.getContainer().style.cursor = 'crosshair';
    pushAlert('ok', 'MEDIR', 'Haz clic en el mapa para medir distancias');
  }
}

function addMeasurePoint(latlng) {
  measurePoints.push(latlng);
  const dot = L.circleMarker(latlng, {
    radius: 4, color: '#58a6ff', fillColor: '#58a6ff', fillOpacity: 1, weight: 2,
  }).addTo(map);
  measureMarkers.push(dot);

  if (measurePoints.length > 1) {
    if (measureLine) map.removeLayer(measureLine);
    measureLine = L.polyline(measurePoints, {
      color: '#58a6ff', weight: 2, dashArray: '6 4', opacity: .8,
    }).addTo(map);

    let totalDist = 0;
    for (let i = 1; i < measurePoints.length; i++) {
      totalDist += measurePoints[i-1].distanceTo(measurePoints[i]);
    }
    let label = totalDist < 1000
      ? Math.round(totalDist) + ' m'
      : (totalDist / 1000).toFixed(2) + ' km';

    if (measureTooltip) map.removeLayer(measureTooltip);
    const last = measurePoints[measurePoints.length - 1];
    measureTooltip = L.marker(last, {
      icon: L.divIcon({
        className: 'measure-tooltip',
        html: label,
        iconAnchor: [-8, 12],
      })
    }).addTo(map);
  }
}

function clearMeasure() {
  measurePoints = [];
  if (measureLine) { map.removeLayer(measureLine); measureLine = null; }
  measureMarkers.forEach(m => map.removeLayer(m));
  measureMarkers = [];
  if (measureTooltip) { map.removeLayer(measureTooltip); measureTooltip = null; }
  if (map) map.getContainer().style.cursor = '';
  const btn = document.getElementById('tbMeasure');
  if (btn) btn.classList.remove('active');
  measureMode = false;
}

function toggleLayerPanel() {
  layerPanelOpen = !layerPanelOpen;
  const panel = document.getElementById('layerPanel');
  const btn = document.getElementById('tbLayers');
  if (panel) panel.classList.toggle('hidden', !layerPanelOpen);
  if (btn) btn.classList.toggle('active', layerPanelOpen);
}

function toggleLayerFromPanel(key) {
  carrierVisible[key] = !carrierVisible[key];
  if (carrierVisible[key]) {
    map.addLayer(carrierLayers[key]);
  } else {
    map.removeLayer(carrierLayers[key]);
  }
  refreshLayerPanel();
}

function refreshLayerPanel() {
  const panel = document.getElementById('layerPanel');
  if (!panel) return;
  const items = panel.querySelectorAll('.layer-item');
  items.forEach(item => {
    const key = item.dataset.carrier;
    const check = item.querySelector('.layer-check');
    if (check) {
      check.classList.toggle('on', carrierVisible[key]);
    }
  });
}

function showAccuracyCircle(lat, lng, radiusM) {
  if (accuracyCircle) map.removeLayer(accuracyCircle);
  accuracyCircle = L.circle([lat, lng], {
    radius: radiusM,
    className: 'accuracy-circle',
    color: '#58a6ff',
    fillColor: 'rgba(88,166,255,.06)',
    weight: 1.5,
    dashArray: '4 3',
    interactive: false,
  }).addTo(map);
}

function initCarrierLayers(towers) {
  const toggleContainer = document.getElementById('towerToggles');
  const panelContainer = document.getElementById('layerPanelItems');
  Object.keys(towers).forEach(key => {
    if (!towers[key] || towers[key].length === 0) return;
    const lg = L.layerGroup().addTo(map);
    carrierLayers[key] = lg;
    carrierVisible[key] = true;
    const color = CARRIER_COLORS[key] || '#58a6ff';
    const label = CARRIER_LABELS[key] || key.toUpperCase();
    const count = towers[key].length;

    if (toggleContainer) {
      const btn = document.createElement('button');
      btn.className = `layer-toggle ${key}-toggle active`;
      btn.textContent = `● ${label}`;
      btn.style.color = color;
      btn.style.borderColor = color;
      btn.onclick = () => toggleCarrier(key, btn);
      toggleContainer.appendChild(btn);
    }

    if (panelContainer) {
      const item = document.createElement('div');
      item.className = 'layer-item';
      item.dataset.carrier = key;
      item.style.color = color;
      item.onclick = () => {
        toggleLayerFromPanel(key);
        const oldBtn = toggleContainer ? toggleContainer.querySelector(`.${key}-toggle`) : null;
        if (oldBtn) {
          oldBtn.classList.toggle('active', carrierVisible[key]);
        }
      };
      item.innerHTML = `<div class="layer-check on" style="border-color:${color};color:${color}"></div>
        <span class="layer-name">${label}</span>
        <span class="layer-count">${count}</span>`;
      panelContainer.appendChild(item);
    }
  });
}

function toggleCarrier(key, btn) {
  carrierVisible[key] = !carrierVisible[key];
  if (carrierVisible[key]) {
    map.addLayer(carrierLayers[key]);
    btn.classList.add('active');
  } else {
    map.removeLayer(carrierLayers[key]);
    btn.classList.remove('active');
  }
}

function placePhoneMarker(lat, lng, number, connection, triData) {
  triData = triData || {};
  if (phoneMarker) {
    map.removeLayer(phoneMarker);
  }

  const connInfo = connection || {};
  const servingCell = connInfo.serving_cell || '?';
  const rssi = connInfo.serving_rssi || '?';
  const rsrp = connInfo.serving_rsrp || '?';
  const rsrq = connInfo.serving_rsrq || '?';
  const tech = connInfo.technology || '?';
  const lac = connInfo.lac || '?';
  const cellId = connInfo.cell_id || '?';
  const freqMhz = connInfo.frequency_mhz || '?';
  const radioType = connInfo.radio_type || '?';
  const bandName = connInfo.band_name || connInfo.band || '?';

  const phoneIcon = L.divIcon({
    className: 'phone-marker',
    html: `<div class="phone-loc-marker">
      <div class="phone-loc-glow"></div>
      <div class="phone-loc-ring2"></div>
      <div class="phone-loc-ring1"></div>
      <div class="phone-loc-dot"></div>
    </div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12]
  });

  const popupStyle = 'font-family:system-ui,-apple-system,sans-serif;background:#161b22;color:#e6edf3;padding:14px 16px;border-radius:8px;border:1px solid rgba(136,198,255,.1);min-width:250px;box-shadow:0 8px 32px rgba(0,0,0,.5);line-height:1.5;font-size:12px;';
  const sectionStyle = 'border-top:1px solid rgba(136,198,255,.08);padding-top:8px;margin-top:8px;';
  const labelStyle = 'font-size:10px;font-weight:600;letter-spacing:1px;text-transform:uppercase;margin-bottom:4px;';
  const valStyle = 'color:#79c0ff;';
  const dimStyle = 'color:#484f58;font-size:11px;';

  phoneMarker = L.marker([lat, lng], { icon: phoneIcon, zIndexOffset: 1000 })
    .addTo(map)
    .bindPopup(`<div style="${popupStyle}">
      <div style="font-weight:700;font-size:15px;color:#e6edf3;margin-bottom:8px;">📱 ${number || 'OBJETIVO'}</div>
      <div style="${sectionStyle}">
        <div style="${labelStyle}color:#8b949e;">POSICIÓN ${triData.geo_method === 'gps_triangulation' ? '<span style="color:#58a6ff">● CELL ID</span>' : 'ESTIMADA'}</div>
        <div>Lat: <span style="${valStyle}">${lat.toFixed(6)}</span></div>
        <div>Lng: <span style="${valStyle}">${lng.toFixed(6)}</span></div>
      </div>
      ${triData.cell_id_info ? `<div style="${sectionStyle}">
        <div style="${labelStyle}color:#58a6ff;">IDENTIFICACIÓN CELULAR</div>
        <div>CID: <span style="${valStyle}">${triData.cell_id_info.cell_id}</span> <span style="${dimStyle}">(${triData.cell_id_info.cell_id_hex})</span></div>
        <div>eNB: <span style="color:#58a6ff">${triData.cell_id_info.enodeb_id}</span> <span style="${dimStyle}">(${triData.cell_id_info.enodeb_hex})</span></div>
        <div>Sector: <span style="color:#d29922">${triData.cell_id_info.sector_id}</span></div>
        <div>MCC/MNC: <span style="${valStyle}">${triData.cell_id_info.mcc}/${triData.cell_id_info.mnc}</span> · LAC: <span style="${valStyle}">${triData.cell_id_info.lac}</span></div>
        <div>Tipo: <span style="color:#bc8cff">${triData.cell_id_info.network_type}</span></div>
      </div>` : ''}
      <div style="${sectionStyle}">
        <div style="${labelStyle}color:#d29922;">CONEXIÓN CELULAR</div>
        <div>Torre: <span style="color:#58a6ff">${servingCell}</span></div>
        <div>RSRP: <span style="color:${rsrp < -100 ? '#f85149' : rsrp < -80 ? '#d29922' : '#58a6ff'}">${rsrp} dBm</span> · RSRQ: <span style="color:${rsrq < -15 ? '#f85149' : rsrq < -10 ? '#d29922' : '#58a6ff'}">${rsrq} dB</span></div>
        <div>Radio: <span style="color:#bc8cff">${radioType}</span> · ${bandName} (${freqMhz}MHz)</div>
      </div>
    </div>`, { className: 'clean-popup', maxWidth: 300 });

  return phoneMarker;
}

async function runPingSequence(towers, triData, number, carrier) {
  if (!triData) return;

  const conn = triData.connection || {};
  const towerList = triData.towers_used || [];
  const triLat = triData.lat;
  const triLng = triData.lng;
  const towersCount = triData.towers_count || towerList.length;

  pushAlert('warn', 'SEÑAL', `Midiendo señal en ${towersCount} torres...`);
  await new Promise(r => setTimeout(r, 600));

  for (let i = 0; i < Math.min(towersCount, triData.tower_distances.length); i++) {
    const td = triData.tower_distances[i];
    const sym = (td.ternary_dist_sym || '•') + (td.ternary_rsrp_sym || '•');
    pushAlert('ok', td.tower_id, `Avance temporal: ${td.timing_advance} · Distancia: ${(td.distance_m/1000).toFixed(1)} km [${sym}]`);
    await new Promise(r => setTimeout(r, 150));
  }

  pushAlert('ok', 'TORRES', `Trilateración de ${towersCount} torres · GDOP: ${(triData.gdop||0).toFixed(1)}`);
  if (triData.wifi_fusion) {
    pushAlert('ok', 'WiFi', `Fusión: Celular ${triData.wifi_fusion.cell_weight_pct}% + WiFi ${triData.wifi_fusion.wifi_weight_pct}%`);
  }
  await new Promise(r => setTimeout(r, 400));

  placePhoneMarker(triLat, triLng, number, conn, triData);
  lastTriData = triData;
  showAccuracyCircle(triLat, triLng, triData.accuracy_meters || 50);
  map.setView([triLat, triLng], 15, { animate: true, duration: 1 });

  pushAlert('ok', 'UBICACIÓN', `${number} localizado · ±${triData.accuracy_meters} m · ${triData.method || 'WLS-RTT'}`);
}

function towerPopupHtml(label, color, t) {
  const radioType = t.radio_type || t.tech || '?';
  const freqMhz = t.frequency_mhz || '?';
  const bandName = t.band_name || t.band || '?';
  const avgSig = t.avg_signal || t.power_dbm || '?';
  const samples = t.samples || '?';
  const earfcn = t.earfcn || '?';
  const source = t.source || 'OpenCelliD';
  const mcc = t.mcc || '?';
  const mnc = t.mnc || '?';
  return `<div style="font-family:system-ui,-apple-system,sans-serif;background:#161b22;color:#e6edf3;padding:12px 14px;border-radius:8px;border:1px solid rgba(136,198,255,.1);min-width:220px;box-shadow:0 8px 32px rgba(0,0,0,.5);font-size:12px;line-height:1.6;">
    <div style="font-weight:700;font-size:13px;color:${color};margin-bottom:6px;">${label} ${t.id}</div>
    <div style="color:#8b949e;font-size:11px;">MCC:${mcc} · MNC:${mnc}</div>
    <div style="color:#79c0ff;">${t.lat.toFixed(6)}, ${t.lng.toFixed(6)}</div>
    <div style="border-top:1px solid rgba(136,198,255,.08);margin-top:6px;padding-top:6px;">
      <div>Alcance: <span style="color:#79c0ff">${t.range_km} km</span> · <span style="color:#79c0ff">${t.power_dbm} dBm</span></div>
      <div>Radio: <span style="color:#bc8cff">${radioType}</span> · ${bandName} (${freqMhz}MHz)</div>
      <div>Señal: <span style="color:#79c0ff">${avgSig} dBm</span> · EARFCN: ${earfcn}</div>
      ${t.enodeb ? '<div>eNodeB: <span style="color:#58a6ff">' + t.enodeb + '</span>' + (t.lac ? ' · LAC: ' + t.lac : '') + '</div>' : ''}
    </div>
    <div style="color:#484f58;font-size:10px;margin-top:4px;">${source}</div>
  </div>`;
}

function renderTowers(towers) {
  Object.keys(carrierLayers).forEach(key => carrierLayers[key].clearLayers());

  Object.keys(towers).forEach(carrierKey => {
    const towerList = towers[carrierKey] || [];
    const lg = carrierLayers[carrierKey];
    if (!lg) return;
    const color = CARRIER_COLORS[carrierKey] || '#58a6ff';
    const label = CARRIER_LABELS[carrierKey] || carrierKey.toUpperCase();

    towerList.forEach(t => {
      const marker = L.circleMarker([t.lat, t.lng], {
        radius: 4, color: color, fillColor: color, fillOpacity: 0.7, weight: 1,
      });
      marker.bindPopup(towerPopupHtml(label, color, t));
      lg.addLayer(marker);
    });
  });
}

function renderTriangulation(triData) {
  if (!triData || !triData.tower_distances) return;
  triangulationLayerGroup.clearLayers();

  updateDashboard(triData);
}


function updateDashboard(triData) {
  const conn = triData.connection || {};
  const method = triData.method || 'WLS-RTT';
  const towersCount = triData.towers_count || triData.tower_distances.length;
  const gdop = triData.gdop || '--';
  const wifiFusion = triData.wifi_fusion;

  const el = document.getElementById('dashMetrics');
  if (el) {
    let html = `<div class="dash-row"><span class="dash-label">MÉTODO</span><span class="dash-val">${method}</span></div>`;
    html += `<div class="dash-row"><span class="dash-label">TORRES</span><span class="dash-val">${towersCount}</span></div>`;
    html += `<div class="dash-row"><span class="dash-label">GDOP</span><span class="dash-val" style="color:${gdop < 3 ? '#58a6ff' : gdop < 6 ? '#d29922' : '#f85149'}">${typeof gdop === 'number' ? gdop.toFixed(1) : gdop}</span></div>`;
    html += `<div class="dash-row"><span class="dash-label">PRECISIÓN</span><span class="dash-val">±${triData.accuracy_meters} m</span></div>`;

    if (conn.serving_cell) {
      html += `<div class="dash-row"><span class="dash-label">TORRE PRINCIPAL</span><span class="dash-val">${conn.serving_cell}</span></div>`;
      html += `<div class="dash-row"><span class="dash-label">RSRP</span><span class="dash-val" style="color:${(conn.serving_rsrp||0) < -100 ? '#f85149' : '#58a6ff'}">${conn.serving_rsrp || '?'} dBm</span></div>`;
      html += `<div class="dash-row"><span class="dash-label">RADIO</span><span class="dash-val">${conn.technology || '?'}</span></div>`;
    }

    const qg = triData.quality_gates;
    if (qg) {
      html += `<div class="dash-divider"></div>`;
      const qgColor = qg.avg_score > 0.7 ? '#58a6ff' : qg.avg_score > 0.4 ? '#d29922' : '#f85149';
      html += `<div class="dash-row"><span class="dash-label">Q-GATE</span><span class="dash-val" style="color:${qgColor}">${(qg.avg_score*100).toFixed(0)}%</span></div>`;
      if (qg.towers_gated > 0) {
        html += `<div class="dash-row"><span class="dash-label">NLOS FILTRADAS</span><span class="dash-val" style="color:#f85149">${qg.towers_gated}/${qg.towers_total}</span></div>`;
      }
    }

    if (wifiFusion) {
      html += `<div class="dash-divider"></div>`;
      html += `<div class="dash-row"><span class="dash-label">WiFi APs</span><span class="dash-val">${wifiFusion.wifi_aps}</span></div>`;
      html += `<div class="dash-row"><span class="dash-label">CELL %</span><span class="dash-val">${wifiFusion.cell_weight_pct}%</span></div>`;
      html += `<div class="dash-row"><span class="dash-label">WiFi %</span><span class="dash-val">${wifiFusion.wifi_weight_pct}%</span></div>`;
      if (wifiFusion.wifi_sigma) {
        html += `<div class="dash-row"><span class="dash-label">WiFi σ</span><span class="dash-val">${wifiFusion.wifi_sigma.toFixed(1)}m</span></div>`;
      }
    }

    el.innerHTML = html;
  }

  const sigEl = document.getElementById('sigNum');
  if (sigEl) sigEl.textContent = triData.accuracy_meters || 0;

  triData.tower_distances.forEach(td => {
    const sym = (td.ternary_dist_sym || '•') + (td.ternary_rsrp_sym || '•');
    td._ternary_display = sym;
  });
}

function updateArc(id, pct, max) {
  const el = document.getElementById(id);
  if (!el) return;
  const val = Math.min(pct / max, 1) * ARC;
  el.setAttribute('stroke-dasharray', `${val} ${ARC}`);
}

function setMetric(valId, arcId, value, maxVal, unit) {
  const el = document.getElementById(valId);
  if (el) el.textContent = typeof value === 'number' ? Math.round(value) : value;
  if (arcId) updateArc(arcId, typeof value === 'number' ? value : 0, maxVal);
}

const _snnCache = {};
function tickSNN() {
  neatGen++;

  if (wasmReady) {
    try {
      const stateJson = wasmEngine.tick_snn();
      JSON.parse(stateJson);
    } catch (e) {
      if (!wasmSnnWarnShown) { console.warn('WASM SNN tick fallback'); wasmSnnWarnShown = true; }
    }
  }
}

function clock() {
  const now = new Date();
  const el = document.getElementById('hC');
  if (el) el.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
}

function toggleSatellite() {
  if (!map) return;
  const btn = document.getElementById('tbSatellite');
  if (isSatellite) {
    map.removeLayer(satTileLayer);
    darkTileLayer.addTo(map);
    if (btn) btn.classList.remove('active');
    isSatellite = false;
  } else {
    map.removeLayer(darkTileLayer);
    satTileLayer.addTo(map);
    if (btn) btn.classList.add('active');
    isSatellite = true;
  }
}

function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * DEG2RAD;
  const dLng = (lng2 - lng1) * DEG2RAD;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * DEG2RAD) * Math.cos(lat2 * DEG2RAD) *
    Math.sin(dLng/2) * Math.sin(dLng/2);
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function updateLocationMetrics(triData, cfg) {
  if (!triData) return;

  const towersCount = triData.towers_count || 0;

  const locCity = document.getElementById('locCity');
  if (locCity && cfg.city) locCity.textContent = cfg.city;
  const locCoords = document.getElementById('locCoords');
  if (locCoords && triData.lat && triData.lng) {
    locCoords.textContent = triData.lat.toFixed(5) + ', ' + triData.lng.toFixed(5);
  }

  if (cfg && cfg.userLat && cfg.userLng && triData.lat && triData.lng) {
    const distKm = haversineKm(cfg.userLat, cfg.userLng, triData.lat, triData.lng);
    const distUnitEl = document.getElementById('mDistUnit');
    if (distKm < 1) {
      setMetric('mDist', 'arcDist', Math.round(distKm * 1000), 5000, 'm');
      if (distUnitEl) distUnitEl.textContent = 'm';
    } else {
      const mDistEl2 = document.getElementById('mDist');
      if (mDistEl2) mDistEl2.textContent = distKm.toFixed(1);
      updateArc('arcDist', distKm, 100);
      if (distUnitEl) distUnitEl.textContent = 'km';
    }
  } else {
    const mDistEl = document.getElementById('mDist');
    if (mDistEl) mDistEl.textContent = '--';
  }

  let zone = 'Rural';
  let zonePct = 20;
  if (towersCount >= 8) { zone = 'Urbana'; zonePct = 90; }
  else if (towersCount >= 5) { zone = 'Suburbana'; zonePct = 55; }
  else if (towersCount >= 3) { zone = 'Periurbana'; zonePct = 35; }
  const mZone = document.getElementById('mZone');
  if (mZone) mZone.textContent = zone;
  updateArc('arcZone', zonePct, 100);

  const confidence = triData.confidence || triData.pascal_confidence || 0;
  setMetric('mConf', 'arcConf', Math.round(confidence), 100, '%');

  if (triData.lat && triData.lng) {
    fetchStudy(triData.lat, triData.lng);
  }

  pushAlert('ok', 'MÉTRICAS', `Zona: ${zone} · Confianza: ${Math.round(confidence)}%`);
}

function fetchStudy(lat, lng) {
  const container = document.getElementById('studySections');
  if (!container) return;
  container.innerHTML = '<div class="study-loading">Analizando zona...</div>';
  fetch(`/api/study?lat=${lat}&lng=${lng}`)
    .then(r => {
      if (r.status === 403) {
        return r.json().then(d => {
          container.innerHTML = '<div class="study-section"><div class="study-section-title"><span class="study-icon">🔒</span> PREMIUM REQUERIDO</div><div class="study-empty" style="text-align:center"><div style="margin-bottom:8px">El Estudio de Zona requiere Plan Premium</div><a href="/planes" style="color:#FFB800;text-decoration:none;font-weight:700;font-size:11px"><i class="fas fa-crown"></i> Ver Planes — $9.99/mes</a></div></div>';
          return null;
        });
      }
      return r.json();
    })
    .then(data => {
      if (!data) return;
      if (data.error) {
        container.innerHTML = '<div class="study-empty">No disponible</div>';
        return;
      }
      const icons = { moteles: '🏨', bares: '🍻' };
      const titles = { moteles: 'MOTELES / HOTELES', bares: 'BARES / DISCOTECAS' };
      let html = '';
      for (const [key, places] of Object.entries(data)) {
        html += `<div class="study-section">`;
        html += `<div class="study-section-title"><span class="study-icon">${icons[key] || '📍'}</span> ${titles[key] || key.toUpperCase()}</div>`;
        if (places.length === 0) {
          html += `<div class="study-empty">Ninguno encontrado</div>`;
        } else {
          places.forEach(p => {
            const openDot = p.open === true ? ' 🟢' : p.open === false ? ' 🔴' : '';
            html += `<div class="study-item"><span class="study-item-name">${p.name}${openDot}</span><span class="study-item-dist">${p.dist}</span></div>`;
          });
        }
        html += `</div>`;
      }
      html += `<div class="study-section study-donate">`;
      html += `<div class="study-section-title"><span class="study-icon">☕</span> APÓYANOS</div>`;
      html += `<div class="donate-text">¿Te fue útil LocalizaHN? Regálanos un cafecito</div>`;
      html += `<a href="/donar" class="donate-btn"><i class="fas fa-coffee"></i> Regálame un Café</a>`;
      html += `</div>`;
      container.innerHTML = html;
      pushAlert('ok', 'ESTUDIO', 'Análisis de zona completado');
    })
    .catch(() => {
      container.innerHTML = '<div class="study-empty">Error al cargar datos</div>';
    });
}

function pushAlert(type, source, msg) {
  const scroll = document.getElementById('aScroll');
  if (!scroll) return;
  const span = document.createElement('span');
  span.className = `ac ${type}`;
  span.innerHTML = `● [${source}] ${msg}`;
  scroll.appendChild(span);
  const dup = span.cloneNode(true);
  scroll.appendChild(dup);
  while (scroll.children.length > 30) {
    scroll.removeChild(scroll.firstChild);
  }
}

function updateIEC(confidence) {
  const iecN = document.getElementById('iecN');
  const iecL = document.getElementById('iecL');
  if (!iecN) return;
  const q = quant6(confidence);
  const display = dequant6(q);
  iecN.textContent = display;
  let label = 'EXCELENTE';
  if (display < 30) { label = 'DÉBIL'; iecN.style.color = '#f85149'; }
  else if (display < 50) { label = 'MODERADA'; iecN.style.color = '#d29922'; }
  else if (display < 70) { label = 'BUENA'; iecN.style.color = '#e3b341'; }
  else { iecN.style.color = '#58a6ff'; }
  if (iecL) iecL.textContent = label;
}

function updatePredPanel(triData) {
  const container = document.getElementById('predRows');
  if (!container || !triData || !triData.tower_distances) return;
  let html = '';
  triData.tower_distances.forEach(td => {
    const sym = (td.ternary_dist_sym || '•') + (td.ternary_rsrp_sym || '•');
    const w = td.weight || 1;
    let wColor = '#58a6ff';
    if (w < 0.5) wColor = '#f85149';
    else if (w < 0.8) wColor = '#d29922';
    html += `<div class="pred-row">
      <span class="pr-name">${td.tower_id} <span style="color:#888;font-size:9px">TA:${td.timing_advance}</span></span>
      <span class="pr-dist">${(td.distance_m/1000).toFixed(1)}km</span>
      <span class="pr-conf" style="color:${wColor};border-color:${wColor}">${sym}</span>
    </div>`;
  });
  container.innerHTML = html;
}

function filterTowersByCarrier(towers, carrier) {
  let all = [];
  Object.values(towers).forEach(t => { if (t) all = all.concat(t); });
  if (!carrier) return all;
  const key = carrier.toLowerCase();
  if (towers[key] && towers[key].length >= 3) return towers[key];
  return all;
}

async function runWasmTriangulation(towers, centerLat, centerLng, carrier) {
  if (!wasmReady) return null;
  try {
    const filteredTowers = filterTowersByCarrier(towers, carrier);
    if (filteredTowers.length < 3) return null;
    const towersJson = JSON.stringify(filteredTowers);
    const resultJson = wasmEngine.triangulate(towersJson, centerLat, centerLng);
    return JSON.parse(resultJson);
  } catch (e) {
    console.warn('WASM triangulation unavailable, using server-side solver');
    return null;
  }
}

async function measureNetworkLatency() {
  try {
    const iterations = 5;
    const latencies = [];
    for (let i = 0; i < iterations; i++) {
      const t0 = performance.now();
      await fetch(`/api/ping?_t=${Date.now()}`, { cache: 'no-store' }).catch(() => {});
      const t1 = performance.now();
      latencies.push(t1 - t0);
    }
    latencies.sort((a, b) => a - b);
    const median = latencies[Math.floor(latencies.length / 2)];
    const avg = latencies.reduce((a, b) => a + b, 0) / latencies.length;
    return {
      latency_ms: Math.round(median * 100) / 100,
      avg_ms: Math.round(avg * 100) / 100,
      iterations,
      q6_latency: quant6(Math.min(median / 5, 100)),
      timing: 'performance.now()',
    };
  } catch (e) {
    console.error('Network latency measurement error:', e);
    return null;
  }
}

function processWasmPing(latencyMs) {
  if (!wasmReady) return null;
  try {
    const resultJson = wasmEngine.process_ping_signal(latencyMs);
    return JSON.parse(resultJson);
  } catch (e) {
    console.error('WASM ping processing error:', e);
    return null;
  }
}

async function changeCity(selectEl) {
  const city = selectEl.value;
  const countryCode = selectEl.dataset.country;
  const carrier = selectEl.dataset.carrier;

  pushAlert('warn', 'CIUDAD', `Cambiando a ${city}...`);

  try {
    const resp = await fetch('/api/triangulate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ country_code: countryCode, city: city, carrier: carrier })
    });
    const data = await resp.json();

    if (data.towers) {
      Object.keys(data.towers).forEach(key => {
        if (!carrierLayers[key] && data.towers[key] && data.towers[key].length > 0) {
          const lg = L.layerGroup().addTo(map);
          carrierLayers[key] = lg;
          carrierVisible[key] = true;
        }
      });
      renderTowers(data.towers);

      let triResult = data.triangulation || null;
      if (wasmReady && triResult) {
        const filteredTowers = filterTowersByCarrier(data.towers, carrier);
        if (filteredTowers.length >= 3) {
          const wasmTri = await runWasmTriangulation(data.towers, triResult.lat, triResult.lng, carrier);
          if (wasmTri && !wasmTri.error) {
            triResult.wasm_computation_ms = wasmTri.computation_ms;
            triResult.wasm_lat = wasmTri.lat;
            triResult.wasm_lng = wasmTri.lng;
            pushAlert('ok', 'CÁLCULO', `Tiempo de cálculo: ${wasmTri.computation_ms.toFixed(3)} ms`);
          }
        }
      }

      if (triResult) {
        renderTriangulation(triResult);
        updateIEC(triResult.confidence || triResult.pascal_confidence || 50);
        updatePredPanel(triResult);
        map.setView([triResult.lat, triResult.lng], 13);
        updateLocationMetrics(triResult, window.__bootConfig || {});
        pushAlert('ok', 'LOCALIZACIÓN', `${city} · Confianza: ${triResult.confidence}%`);
      }

      const mapTitle = document.querySelector('.map-title');
      if (mapTitle) mapTitle.textContent = `📡 ${city.toUpperCase()} · LOCALIZACIÓN CELULAR`;
      const hCityEl = document.getElementById('hCity');
      if (hCityEl) hCityEl.textContent = city;
    }
  } catch (e) {
    console.error('City change error:', e);
    pushAlert('err', 'ERROR', 'Fallo al cambiar ciudad');
  }
}

function revealCadLayer(id, delay) {
  setTimeout(() => {
    const el = document.getElementById(id);
    if (el) el.classList.add('cad-visible');
  }, delay);
}

async function boot(config) {
  window.__bootConfig = config;
  updateLoadingMsg('ANALIZANDO TORRES CERCANAS...');
  pushAlert('ok', 'INICIO', 'Iniciando análisis de cobertura...');

  updateLoadingMsg('CARGANDO MOTOR DE CÁLCULO...');
  await initWasm();

  updateLoadingMsg('PREPARANDO MAPA...');
  const mapLat = config.lat !== null ? config.lat : 15.2;
  const mapLng = config.lng !== null ? config.lng : -86.5;
  initMap(mapLat, mapLng, config.city, config.zoom || 8);

  updateLoadingMsg('DETECTANDO TORRES CELULARES...');
  if (config.towers) {
    initCarrierLayers(config.towers);
    renderTowers(config.towers);
  }

  updateLoadingMsg('CALCULANDO UBICACIÓN...');
  let triResult = config.triangulation;

  if (wasmReady && config.towers) {
    const wasmTri = await runWasmTriangulation(config.towers, config.lat, config.lng, config.carrier);
    if (wasmTri && !wasmTri.error) {
      if (triResult) {
        triResult.wasm_computation_ms = wasmTri.computation_ms;
        triResult.wasm_lat = wasmTri.lat;
        triResult.wasm_lng = wasmTri.lng;
      }
      pushAlert('ok', 'CÁLCULO', `Tiempo de cálculo: ${wasmTri.computation_ms.toFixed(3)} ms`);
    }
  }

  if (triResult) {
    lastTriData = triResult;
    renderTriangulation(triResult);
    updateIEC(triResult.confidence || triResult.pascal_confidence || 50);
    updatePredPanel(triResult);
    map.setView([triResult.lat, triResult.lng], 15, { animate: true, duration: 1 });
  }

  window._mapReady = true;

  pushAlert('ok', 'MAPA', 'Mapa cargado correctamente');

  if (triResult && config.isTriangulation) {
    await runPingSequence(config.towers, triResult, config.number, config.carrier);
  }

  pushAlert('ok', 'ANÁLISIS', 'Procesando datos de torres...');
  revealCadLayer('cadLayer2', 1800);

  setTimeout(() => {
    revealCadLayer('cadMetrics', 200);
    updateLocationMetrics(triResult, config);
  }, 2500);

  updateLoadingMsg('MIDIENDO LATENCIA DE RED...');
  const networkPing = await measureNetworkLatency();
  if (networkPing) {
    const pingSignal = processWasmPing(networkPing.latency_ms);
    if (pingSignal && triResult) {
      const adjustedConf = Math.max(0, Math.min(100, (triResult.confidence || 80) + pingSignal.confidence_adjustment));
      updateIEC(adjustedConf);
      pushAlert('ok', 'RED', `Latencia: ${networkPing.latency_ms.toFixed(1)} ms · Ajuste confianza: ${pingSignal.confidence_adjustment > 0 ? '+' : ''}${pingSignal.confidence_adjustment}%`);
    } else {
      pushAlert('ok', 'RED', `Latencia de red: ${networkPing.latency_ms.toFixed(1)} ms`);
    }
  }

  snnInterval = setInterval(tickSNN, 900);
  clockInterval = setInterval(clock, 1000);
  tickSNN();
  clock();

  pushAlert('ok', 'LISTO', 'LocalizaHN v3.0 · Sistema de localización activo');

  if (config.snnLayers) {
    const statusMap = { complete: 'completado', deferred: 'pendiente', pending: 'en proceso', error: 'error' };
    Object.entries(config.snnLayers).forEach(([key, layer]) => {
      pushAlert(
        layer.status === 'complete' ? 'ok' : (layer.status === 'deferred' || layer.status === 'pending') ? 'warn' : 'err',
        'CAPA',
        `${layer.name} · ${statusMap[layer.status] || layer.status}`
      );
    });
  }
}

window.changeCity = changeCity;
window.boot = boot;
window.mapZoomIn = mapZoomIn;
window.mapZoomOut = mapZoomOut;
window.mapFitAll = mapFitAll;
window.mapCenterTarget = mapCenterTarget;
window.toggleMeasure = toggleMeasure;
window.clearMeasure = clearMeasure;
window.toggleLayerPanel = toggleLayerPanel;
window.toggleLayerFromPanel = toggleLayerFromPanel;
window.toggleSatellite = toggleSatellite;
