/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function init_engine(): void;
export function triangulate(a: number, b: number, c: number, d: number, e: number): void;
export function process_ping_signal(a: number, b: number): void;
export function tick_snn(a: number): void;
export function quant_vigesimal(a: number, b: number, c: number): number;
export function dequant_vigesimal(a: number, b: number, c: number): number;
export function quantize_6bit(a: number): number;
export function dequantize_6bit(a: number): number;
export function get_pascal_weights(a: number, b: number): void;
export function pythagorean_distance(a: number, b: number, c: number, d: number): number;
export function engine_info(a: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_export_0(a: number, b: number): number;
export function __wbindgen_export_1(a: number, b: number, c: number, d: number): number;
export function __wbindgen_export_2(a: number, b: number, c: number): void;
