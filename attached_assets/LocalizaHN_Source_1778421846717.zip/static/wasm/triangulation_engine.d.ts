/* tslint:disable */
/* eslint-disable */
/**
*/
export function init_engine(): void;
/**
* @param {string} towers_json
* @param {number} center_lat
* @param {number} center_lng
* @returns {string}
*/
export function triangulate(towers_json: string, center_lat: number, center_lng: number): string;
/**
* @param {number} latency_ms
* @returns {string}
*/
export function process_ping_signal(latency_ms: number): string;
/**
* @returns {string}
*/
export function tick_snn(): string;
/**
* @param {number} value
* @param {number} min
* @param {number} max
* @returns {number}
*/
export function quant_vigesimal(value: number, min: number, max: number): number;
/**
* @param {number} level
* @param {number} min
* @param {number} max
* @returns {number}
*/
export function dequant_vigesimal(level: number, min: number, max: number): number;
/**
* @param {number} pct
* @returns {number}
*/
export function quantize_6bit(pct: number): number;
/**
* @param {number} q
* @returns {number}
*/
export function dequantize_6bit(q: number): number;
/**
* @param {number} depth
* @returns {string}
*/
export function get_pascal_weights(depth: number): string;
/**
* @param {number} lat1
* @param {number} lng1
* @param {number} lat2
* @param {number} lng2
* @returns {number}
*/
export function pythagorean_distance(lat1: number, lng1: number, lat2: number, lng2: number): number;
/**
* @returns {string}
*/
export function engine_info(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly init_engine: () => void;
  readonly triangulate: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly process_ping_signal: (a: number, b: number) => void;
  readonly tick_snn: (a: number) => void;
  readonly quant_vigesimal: (a: number, b: number, c: number) => number;
  readonly dequant_vigesimal: (a: number, b: number, c: number) => number;
  readonly quantize_6bit: (a: number) => number;
  readonly dequantize_6bit: (a: number) => number;
  readonly get_pascal_weights: (a: number, b: number) => void;
  readonly pythagorean_distance: (a: number, b: number, c: number, d: number) => number;
  readonly engine_info: (a: number) => void;
  readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
  readonly __wbindgen_export_0: (a: number, b: number) => number;
  readonly __wbindgen_export_1: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_export_2: (a: number, b: number, c: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {SyncInitInput} module
*
* @returns {InitOutput}
*/
export function initSync(module: SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {InitInput | Promise<InitInput>} module_or_path
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: InitInput | Promise<InitInput>): Promise<InitOutput>;
