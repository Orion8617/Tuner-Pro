import sqlite3
import os
import time
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), 'users.db')

PLAN_LOCALIZADOR = 'localizador'
PLAN_PREMIUM = 'premium'
PLAN_NONE = 'none'

FREE_SEARCH_LIMIT = 2

PLAN_PRICES = {
    PLAN_LOCALIZADOR: 5.99,
    PLAN_PREMIUM: 9.99,
}

PLAN_NAMES = {
    PLAN_LOCALIZADOR: 'Plan Localizador',
    PLAN_PREMIUM: 'Plan Rastreo Premium',
    PLAN_NONE: 'Sin Plan',
}

PLAN_FEATURES = {
    PLAN_LOCALIZADOR: [
        'Localizar número de teléfono',
        'Búsquedas ilimitadas',
        'Ver operador/carrier',
        'Zona aproximada en mapa',
        'Historial de 7 días',
    ],
    PLAN_PREMIUM: [
        'Todo lo del Plan Localizador',
        'Estudio de Zona (moteles/bares)',
        'Escudo Anti-Localización',
        'Rastreo en vivo en tiempo real',
        'Alertas de proximidad',
        'Mapa de calor de movimiento',
        'Dispositivos cercanos',
        'Historial de 30 días',
        'Directorio de contactos',
    ],
}


def _get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_user_db():
    conn = _get_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            active_plan TEXT DEFAULT 'none',
            stripe_customer_id TEXT,
            stripe_subscription_id TEXT,
            subscription_start REAL,
            subscription_end REAL,
            free_searches_used INTEGER DEFAULT 0,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
        CREATE INDEX IF NOT EXISTS idx_users_stripe ON users(stripe_customer_id);

        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            stripe_payment_id TEXT,
            amount REAL NOT NULL,
            currency TEXT DEFAULT 'usd',
            plan TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at REAL NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
        CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(user_id);

        CREATE TABLE IF NOT EXISTS protected_numbers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            phone_number TEXT NOT NULL,
            label TEXT DEFAULT '',
            created_at REAL NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
        CREATE INDEX IF NOT EXISTS idx_protected_user ON protected_numbers(user_id);
        CREATE INDEX IF NOT EXISTS idx_protected_phone ON protected_numbers(phone_number);
    """)
    try:
        conn.execute("ALTER TABLE users ADD COLUMN free_searches_used INTEGER DEFAULT 0")
        conn.commit()
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS protected_numbers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            phone_number TEXT NOT NULL,
            label TEXT DEFAULT '',
            created_at REAL NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_protected_user ON protected_numbers(user_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_protected_phone ON protected_numbers(phone_number)")
        conn.commit()
    except sqlite3.OperationalError:
        pass
    conn.commit()
    conn.close()


def create_user(email, password):
    conn = _get_conn()
    now = time.time()
    pw_hash = generate_password_hash(password)
    try:
        conn.execute(
            "INSERT INTO users (email, password_hash, active_plan, free_searches_used, created_at, updated_at) VALUES (?, ?, 'none', 0, ?, ?)",
            (email.lower().strip(), pw_hash, now, now)
        )
        conn.commit()
        user_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.close()
        return user_id
    except sqlite3.IntegrityError:
        conn.close()
        return None


def authenticate_user(email, password):
    conn = _get_conn()
    row = conn.execute("SELECT * FROM users WHERE email = ?", (email.lower().strip(),)).fetchone()
    conn.close()
    if row and check_password_hash(row['password_hash'], password):
        return dict(row)
    return None


def get_user_by_id(user_id):
    conn = _get_conn()
    row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_by_email(email):
    conn = _get_conn()
    row = conn.execute("SELECT * FROM users WHERE email = ?", (email.lower().strip(),)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_by_stripe_customer(stripe_customer_id):
    conn = _get_conn()
    row = conn.execute("SELECT * FROM users WHERE stripe_customer_id = ?", (stripe_customer_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def update_user_plan(user_id, plan, stripe_customer_id=None, stripe_subscription_id=None, subscription_end=None):
    conn = _get_conn()
    now = time.time()
    if plan == PLAN_NONE:
        conn.execute(
            "UPDATE users SET active_plan = ?, stripe_subscription_id = NULL, subscription_end = NULL, updated_at = ? WHERE id = ?",
            (plan, now, user_id)
        )
    else:
        sub_end = subscription_end or (now + 30 * 86400)
        params = [plan, now, sub_end, now]
        sql = "UPDATE users SET active_plan = ?, subscription_start = ?, subscription_end = ?, updated_at = ?"
        if stripe_customer_id:
            sql += ", stripe_customer_id = ?"
            params.append(stripe_customer_id)
        if stripe_subscription_id:
            sql += ", stripe_subscription_id = ?"
            params.append(stripe_subscription_id)
        sql += " WHERE id = ?"
        params.append(user_id)
        conn.execute(sql, params)
    conn.commit()
    conn.close()


def cancel_user_plan(user_id):
    conn = _get_conn()
    now = time.time()
    conn.execute(
        "UPDATE users SET active_plan = 'none', stripe_subscription_id = NULL, subscription_end = NULL, updated_at = ? WHERE id = ?",
        (now, user_id)
    )
    conn.commit()
    conn.close()


def record_payment(user_id, amount, plan, stripe_payment_id=None, status='completed'):
    conn = _get_conn()
    now = time.time()
    conn.execute(
        "INSERT INTO payments (user_id, stripe_payment_id, amount, plan, status, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, stripe_payment_id, amount, plan, status, now)
    )
    conn.commit()
    conn.close()


def get_user_payments(user_id, limit=20):
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
        (user_id, limit)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def increment_free_searches(user_id):
    conn = _get_conn()
    conn.execute(
        "UPDATE users SET free_searches_used = COALESCE(free_searches_used, 0) + 1, updated_at = ? WHERE id = ?",
        (time.time(), user_id)
    )
    conn.commit()
    conn.close()


def get_free_searches_used(user_id):
    conn = _get_conn()
    row = conn.execute("SELECT free_searches_used FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    if row:
        return row['free_searches_used'] or 0
    return 0


def get_free_searches_remaining(user_id):
    used = get_free_searches_used(user_id)
    return max(0, FREE_SEARCH_LIMIT - used)


def add_protected_number(user_id, phone_number, label=''):
    conn = _get_conn()
    now = time.time()
    normalized = phone_number.replace(' ', '').replace('-', '')
    existing = conn.execute(
        "SELECT id FROM protected_numbers WHERE user_id = ? AND phone_number = ?",
        (user_id, normalized)
    ).fetchone()
    if existing:
        conn.close()
        return None
    conn.execute(
        "INSERT INTO protected_numbers (user_id, phone_number, label, created_at) VALUES (?, ?, ?, ?)",
        (user_id, normalized, label, now)
    )
    conn.commit()
    row_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.close()
    return row_id


def remove_protected_number(user_id, number_id):
    conn = _get_conn()
    conn.execute(
        "DELETE FROM protected_numbers WHERE id = ? AND user_id = ?",
        (number_id, user_id)
    )
    conn.commit()
    conn.close()


def get_protected_numbers(user_id):
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM protected_numbers WHERE user_id = ? ORDER BY created_at DESC",
        (user_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def is_number_protected(phone_number):
    conn = _get_conn()
    normalized = phone_number.replace(' ', '').replace('-', '')
    variants = [normalized]
    if normalized.startswith('+'):
        variants.append(normalized[1:])
    if normalized.startswith('+504'):
        variants.append(normalized[4:])
    elif not normalized.startswith('+'):
        variants.append('+' + normalized)
        variants.append('+504' + normalized)
    placeholders = ','.join(['?'] * len(variants))
    row = conn.execute(
        f"SELECT pn.*, u.email FROM protected_numbers pn JOIN users u ON pn.user_id = u.id WHERE pn.phone_number IN ({placeholders})",
        variants
    ).fetchone()
    conn.close()
    if row:
        return dict(row)
    return None


def user_has_access(user, feature):
    if not user:
        return False
    plan = user.get('active_plan', PLAN_NONE)
    if plan == PLAN_NONE:
        return False
    sub_end = user.get('subscription_end')
    if sub_end and sub_end < time.time():
        return False
    if feature == 'locate':
        return plan in (PLAN_LOCALIZADOR, PLAN_PREMIUM)
    if feature == 'track':
        return plan == PLAN_PREMIUM
    if feature == 'history_30':
        return plan == PLAN_PREMIUM
    if feature == 'history_7':
        return plan in (PLAN_LOCALIZADOR, PLAN_PREMIUM)
    if feature == 'nearby':
        return plan == PLAN_PREMIUM
    if feature == 'heatmap':
        return plan == PLAN_PREMIUM
    if feature == 'contacts':
        return plan == PLAN_PREMIUM
    if feature == 'alerts':
        return plan == PLAN_PREMIUM
    if feature == 'study_zone':
        return plan == PLAN_PREMIUM
    if feature == 'shield':
        return plan == PLAN_PREMIUM
    return False


init_user_db()
