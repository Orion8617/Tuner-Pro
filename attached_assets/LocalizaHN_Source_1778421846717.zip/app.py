import os
import logging
import phonenumbers
import json
import requests as http_requests
import stripe
from functools import wraps
from flask import Flask, render_template, request, flash, redirect, url_for, jsonify, session, g
from models import (
    create_user, authenticate_user, get_user_by_id, get_user_by_email,
    get_user_by_stripe_customer, update_user_plan, cancel_user_plan,
    record_payment, get_user_payments, user_has_access,
    increment_free_searches, get_free_searches_remaining, get_free_searches_used,
    add_protected_number, remove_protected_number, get_protected_numbers, is_number_protected,
    PLAN_LOCALIZADOR, PLAN_PREMIUM, PLAN_NONE, PLAN_PRICES, PLAN_NAMES, PLAN_FEATURES,
    FREE_SEARCH_LIMIT
)

from phone_validator import validate_phone_number
from cell_towers import (
    get_towers_for_carrier, get_all_towers_for_city,
    get_available_cities, resolve_carrier, get_city_from_area_code,
    resolve_carrier_from_mobile_prefix, is_mobile_number,
    get_default_city_for_mobile, get_department_for_city,
    get_all_towers_in_range, detect_location_from_towers,
    CITY_TO_DEPARTMENT
)
from cellid_lookup import lookup_cell_location, parse_cell_id, phone_to_cell_id
from triangulation_engine import (
    triangulate, run_snn_layers, fetch_weather_data, fetch_aqi_data,
    phone_number_seed
)
import re

import time as _time
import random as _random
import math as _math
from datetime import datetime, timezone, timedelta

HN_TZ = timezone(timedelta(hours=-6))
DIAS_ES = {'Monday': 'Lunes', 'Tuesday': 'Martes', 'Wednesday': 'Miércoles',
           'Thursday': 'Jueves', 'Friday': 'Viernes', 'Saturday': 'Sábado', 'Sunday': 'Domingo'}

def _hn_now():
    return datetime.now(HN_TZ)

def _hn_strftime(fmt):
    dt = _hn_now()
    result = dt.strftime(fmt)
    for en, es in DIAS_ES.items():
        result = result.replace(en, es)
    return result

def _hn_hour():
    return _hn_now().hour
from honduras_area_codes import HONDURAS_MOBILE_CITIES
from tracking_db import (insert_tracking, upsert_tracked_phone, get_history, get_tracked_phones,
                         find_nearby_phones, scan_hotel_companions, save_contact, get_contact,
                         get_contact_by_normalized, list_contacts, delete_contact,
                         record_search, get_recent_searches, get_search_stats)

KNOWN_HOMES = {
    '50495829200': {
        'lat': 15.4589615,
        'lng': -87.9464532,
        'label': 'Colonia Planeta, La Lima',
        'city': 'La Lima',
        'department': 'Cortés',
    },
}

PLACE_TEMPLATES = [
    {'suffix': 'Mall / Centro Comercial', 'type': 'centro comercial', 'dist_km': (1.5, 6.0), 'weight': 20, 'hours': list(range(9, 20))},
    {'suffix': 'Mercado Municipal', 'type': 'mercado', 'dist_km': (0.5, 3.0), 'weight': 12, 'hours': list(range(6, 14))},
    {'suffix': 'Zona Comercial / Centro', 'type': 'zona comercial', 'dist_km': (2.0, 8.0), 'weight': 18, 'hours': list(range(7, 18))},
    {'suffix': 'Parque / Plaza', 'type': 'parque', 'dist_km': (0.3, 2.5), 'weight': 8, 'hours': list(range(5, 21))},
    {'suffix': 'Zona Industrial', 'type': 'trabajo', 'dist_km': (2.0, 10.0), 'weight': 15, 'hours': list(range(6, 17))},
    {'suffix': 'Hospital / Clínica', 'type': 'salud', 'dist_km': (1.0, 5.0), 'weight': 5, 'hours': list(range(7, 20))},
    {'suffix': 'Colonia Residencial', 'type': 'visita', 'dist_km': (0.5, 4.0), 'weight': 10, 'hours': list(range(8, 22))},
]

HOTEL_MOTEL_LOCATIONS = [
    {'name': 'Motel Las Cascadas', 'lat': 15.4385, 'lng': -87.9180, 'type': 'motel'},
    {'name': 'Hotel & Motel El Paso', 'lat': 15.4622, 'lng': -87.9540, 'type': 'motel'},
    {'name': 'Auto Hotel La Ceiba', 'lat': 15.4470, 'lng': -87.9620, 'type': 'motel'},
    {'name': 'Motel Los Arcos', 'lat': 15.4510, 'lng': -87.9050, 'type': 'motel'},
    {'name': 'Hotel Executive', 'lat': 15.4545, 'lng': -87.9335, 'type': 'hotel'},
    {'name': 'Hotel Casa del Árbol', 'lat': 15.4690, 'lng': -87.9380, 'type': 'hotel'},
    {'name': 'Hotel Gran Central', 'lat': 15.5020, 'lng': -88.0180, 'type': 'hotel'},
    {'name': 'Motel Flamingo', 'lat': 15.4440, 'lng': -87.9750, 'type': 'motel'},
    {'name': 'Auto Hotel El Secreto', 'lat': 15.4350, 'lng': -87.9420, 'type': 'motel'},
    {'name': 'Hotel Princess', 'lat': 15.4785, 'lng': -87.9510, 'type': 'hotel'},
    {'name': 'Motel San Martín', 'lat': 15.4925, 'lng': -87.9870, 'type': 'motel'},
    {'name': 'Hotel Real Colonial', 'lat': 15.5085, 'lng': -88.0310, 'type': 'hotel'},
]

WATCHED_PHONES = {'50495829200'}

HOTEL_ALERT_RADIUS_M = 150
HOTEL_MIN_PERMANENCE_S = 600

HOTEL_PROXIMITY_TRACKING = {}

def _check_hotel_proximity(lat, lng):
    import math
    for hotel in HOTEL_MOTEL_LOCATIONS:
        h_lat = hotel['lat']
        h_lng = hotel['lng']
        d_lat = math.radians(lat - h_lat)
        d_lng = math.radians(lng - h_lng)
        a = math.sin(d_lat/2)**2 + math.cos(math.radians(lat)) * math.cos(math.radians(h_lat)) * math.sin(d_lng/2)**2
        dist_m = 6371000 * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        if dist_m <= HOTEL_ALERT_RADIUS_M:
            return {'name': hotel['name'], 'type': hotel['type'], 'distance_m': round(dist_m, 1),
                    'hotel_lat': h_lat, 'hotel_lng': h_lng}
    return None

PHONE_MOVEMENT_STATE = {}
GENERATED_PROFILES = {}

def normalize_phone_for_lookup(phone_str):
    return re.sub(r'\D', '', phone_str.replace('+', ''))

ORIGIN_ZONE = {'lat': None, 'lng': None, 'city': None, 'department': None}

def set_origin_zone(lat, lng, city='', department=''):
    ORIGIN_ZONE['lat'] = lat
    ORIGIN_ZONE['lng'] = lng
    ORIGIN_ZONE['city'] = city or ''
    ORIGIN_ZONE['department'] = department or ''

def _get_phone_profile(phone_str, country_code='HN'):
    normalized = normalize_phone_for_lookup(phone_str)
    if not normalized.startswith('504'):
        normalized = '504' + normalized

    if normalized in GENERATED_PROFILES:
        return GENERATED_PROFILES[normalized]

    contact = get_contact_by_normalized(normalized)
    if contact:
        home = {
            'lat': contact['lat'],
            'lng': contact['lng'],
            'label': f"{contact.get('colonia', '')}, {contact.get('city', '')}".strip(', '),
            'city': contact.get('city', ''),
            'department': contact.get('department', ''),
        }
    elif normalized in KNOWN_HOMES:
        home = KNOWN_HOMES[normalized]
    else:
        seed_val = 0
        for ch in normalized:
            if ch.isdigit():
                seed_val = (seed_val * 31 + int(ch)) & 0xFFFFFFFF
        rng = _random.Random(seed_val)

        zone_lat = ORIGIN_ZONE.get('lat')
        zone_lng = ORIGIN_ZONE.get('lng')
        if zone_lat and zone_lng:
            center_lat = zone_lat
            center_lng = zone_lng
            zone_city = ORIGIN_ZONE.get('city', '')
            zone_dept = ORIGIN_ZONE.get('department', '')
            if not zone_city:
                best_dist = float('inf')
                for cn, cd in HONDURAS_MOBILE_CITIES.items():
                    d = abs(cd['latitude'] - center_lat) + abs(cd['longitude'] - center_lng)
                    if d < best_dist:
                        best_dist = d
                        zone_city = cn
                        zone_dept = cd.get('department', cd.get('region', ''))
            city_name = zone_city
            dept = zone_dept
        else:
            cities = list(HONDURAS_MOBILE_CITIES.items())
            city_name, city_data = rng.choice(cities)
            center_lat = city_data['latitude']
            center_lng = city_data['longitude']
            dept = city_data.get('department', city_data.get('region', ''))

        spread_km = rng.uniform(0.5, 8.0)
        angle = rng.uniform(0, 2 * _math.pi)
        d_lat = (spread_km * 1000 * _math.cos(angle)) / 111320
        d_lng = (spread_km * 1000 * _math.sin(angle)) / (111320 * _math.cos(center_lat * _math.pi / 180))

        colonias = [
            'Col. Kennedy', 'Col. Modelo', 'Col. Satelite', 'Col. Palmira',
            'Col. Las Brisas', 'Col. San José', 'Col. El Centro', 'Col. Independencia',
            'Col. Los Ángeles', 'Res. El Valle', 'Col. Torocagua', 'Barrio Abajo',
            'Barrio El Centro', 'Col. La Pradera', 'Col. San Juan', 'Res. Las Palmas',
            'Col. Moderna', 'Col. El Pedregal', 'Col. El Progreso', 'Col. La Esperanza',
        ]
        colonia = rng.choice(colonias)

        home = {
            'lat': center_lat + d_lat,
            'lng': center_lng + d_lng,
            'label': f"{colonia}, {city_name}",
            'city': city_name,
            'department': dept,
        }

    from triangulation_engine import _snap_to_road, _snap_to_nearest_road_reverse
    snapped_lat, snapped_lng, did_snap = _snap_to_road(home['lat'], home['lng'], phone_number=normalized)
    if not did_snap:
        snapped_lat, snapped_lng, did_snap = _snap_to_nearest_road_reverse(home['lat'], home['lng'], phone_number=normalized)
    if did_snap:
        home['lat'] = snapped_lat
        home['lng'] = snapped_lng

    home_rng = _random.Random(hash(normalized) & 0xFFFFFFFF)
    num_places = home_rng.randint(3, 6)
    selected_templates = home_rng.sample(PLACE_TEMPLATES, min(num_places, len(PLACE_TEMPLATES)))

    places = [{
        'lat': home['lat'], 'lng': home['lng'],
        'label': home['label'],
        'type': 'residencia',
        'weight': 40,
        'hours': [0,1,2,3,4,5,6,7,19,20,21,22,23],
    }]

    for tmpl in selected_templates:
        dist_km = home_rng.uniform(tmpl['dist_km'][0], tmpl['dist_km'][1])
        ang = home_rng.uniform(0, 2 * _math.pi)
        p_lat = home['lat'] + (dist_km * 1000 * _math.cos(ang)) / 111320
        p_lng = home['lng'] + (dist_km * 1000 * _math.sin(ang)) / (111320 * _math.cos(home['lat'] * _math.pi / 180))

        pl_snap_lat, pl_snap_lng, pl_snapped = _snap_to_road(p_lat, p_lng, phone_number=normalized)
        if not pl_snapped:
            pl_snap_lat, pl_snap_lng, pl_snapped = _snap_to_nearest_road_reverse(p_lat, p_lng, phone_number=normalized)
        if pl_snapped:
            p_lat = pl_snap_lat
            p_lng = pl_snap_lng

        places.append({
            'lat': p_lat, 'lng': p_lng,
            'label': f"{tmpl['suffix']}, {home['city']}",
            'type': tmpl['type'],
            'weight': tmpl['weight'],
            'hours': tmpl['hours'],
        })

    profile = {'home': home, 'places': places}
    GENERATED_PROFILES[normalized] = profile
    return profile

def get_current_position(phone_str, country_code='HN'):
    normalized = normalize_phone_for_lookup(phone_str)
    if not normalized.startswith('504'):
        normalized = '504' + normalized

    profile = _get_phone_profile(phone_str, country_code)

    now = _time.time()
    hour = _hn_hour()

    state = PHONE_MOVEMENT_STATE.get(normalized)
    if state and (now - state['ts'] < 120):
        return state['pos']

    places = profile['places']
    candidates = [p for p in places if hour in p.get('hours', list(range(24)))]
    if not candidates:
        candidates = places

    rng = _random.Random(int(now / 300) ^ hash(normalized))
    weights = [p['weight'] for p in candidates]
    total = sum(weights)
    r = rng.uniform(0, total)
    cumul = 0
    chosen = candidates[0]
    for p in candidates:
        cumul += p['weight']
        if r <= cumul:
            chosen = p
            break

    jitter_m = rng.uniform(5, 80)
    angle = rng.uniform(0, 2 * _math.pi)
    d_lat = (jitter_m * _math.cos(angle)) / 111320
    d_lng = (jitter_m * _math.sin(angle)) / (111320 * _math.cos(chosen['lat'] * _math.pi / 180))

    home = profile['home']
    pos = {
        'lat': chosen['lat'] + d_lat,
        'lng': chosen['lng'] + d_lng,
        'location': chosen['label'],
        'type': chosen['type'],
        'city': home['city'],
        'department': home['department'],
        'home_lat': home['lat'],
        'home_lng': home['lng'],
        'moving': abs(chosen['lat'] - home['lat']) > 0.001 or abs(chosen['lng'] - home['lng']) > 0.001,
    }

    PHONE_MOVEMENT_STATE[normalized] = {'ts': now, 'pos': pos}
    return pos

def lookup_known_position(phone_str):
    normalized = normalize_phone_for_lookup(phone_str)
    if not normalized.startswith('504'):
        normalized = '504' + normalized

    contact = get_contact_by_normalized(normalized)
    if contact and contact.get('lat') and contact.get('lng'):
        return get_current_position(phone_str)

    if normalized in KNOWN_HOMES:
        return get_current_position(phone_str)

    return None

logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)

@app.template_filter('from_json')
def from_json_filter(value):
    if isinstance(value, str):
        return json.loads(value)
    return value

app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")
app.permanent_session_lifetime = timedelta(days=30)

stripe.api_key = os.environ.get("STRIPE_SECRET_KEY", "")
STRIPE_PUBLISHABLE_KEY = os.environ.get("STRIPE_PUBLISHABLE_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")

STRIPE_PRICE_IDS = {
    PLAN_LOCALIZADOR: os.environ.get("STRIPE_PRICE_LOCALIZADOR", ""),
    PLAN_PREMIUM: os.environ.get("STRIPE_PRICE_PREMIUM", ""),
}


@app.before_request
def load_current_user():
    g.current_user = None
    user_id = session.get('user_id')
    if user_id:
        user = get_user_by_id(user_id)
        if user:
            import time as _t
            if user.get('subscription_end') and user['subscription_end'] < _t.time() and user['active_plan'] != PLAN_NONE:
                cancel_user_plan(user['id'])
                user['active_plan'] = PLAN_NONE
            g.current_user = user


@app.context_processor
def inject_user():
    return dict(current_user=g.get('current_user'))


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not g.get('current_user'):
            flash('Inicia sesión para acceder a esta función', 'error')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated


def plan_required(feature):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = g.get('current_user')
            if feature == 'locate':
                if not user:
                    flash('Inicia sesión para localizar números', 'error')
                    return redirect(url_for('login', next=request.url))
                if user_has_access(user, 'locate'):
                    return f(*args, **kwargs)
                remaining = get_free_searches_remaining(user['id'])
                if remaining > 0:
                    return f(*args, **kwargs)
                return render_template('limit_reached.html',
                                       free_used=get_free_searches_used(user['id']),
                                       free_limit=FREE_SEARCH_LIMIT)
            if not user:
                flash('Inicia sesión para acceder a esta función', 'error')
                return redirect(url_for('login', next=request.url))
            if not user_has_access(user, feature):
                plan = user.get('active_plan', PLAN_NONE)
                if plan == PLAN_NONE:
                    flash('Necesitas una suscripción para usar esta función', 'warning')
                    return redirect(url_for('planes'))
                else:
                    messages = {
                        'track': 'El rastreo en vivo requiere el Plan Rastreo Premium ($9.99/mes)',
                        'nearby': 'Ver dispositivos cercanos requiere el Plan Rastreo Premium',
                        'heatmap': 'El mapa de calor requiere el Plan Rastreo Premium',
                        'contacts': 'El directorio de contactos requiere el Plan Rastreo Premium',
                        'alerts': 'Las alertas requieren el Plan Rastreo Premium',
                        'history_30': 'El historial de 30 días requiere el Plan Rastreo Premium',
                    }
                    return render_template('upgrade.html',
                                           message=messages.get(feature, 'Esta función requiere un plan superior'),
                                           feature=feature.replace('_', ' ').title())
            return f(*args, **kwargs)
        return decorated
    return decorator


@app.route('/registro', methods=['GET', 'POST'])
def register():
    if g.get('current_user'):
        return redirect(url_for('index'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        password_confirm = request.form.get('password_confirm', '')
        if not email or not password:
            flash('Todos los campos son obligatorios', 'error')
            return render_template('register.html')
        if len(password) < 6:
            flash('La contraseña debe tener al menos 6 caracteres', 'error')
            return render_template('register.html')
        if password != password_confirm:
            flash('Las contraseñas no coinciden', 'error')
            return render_template('register.html')
        user_id = create_user(email, password)
        if user_id is None:
            flash('Ya existe una cuenta con ese correo electrónico', 'error')
            return render_template('register.html')
        session['user_id'] = user_id
        session.permanent = True
        flash('Cuenta creada exitosamente. Elige un plan para comenzar.', 'success')
        return redirect(url_for('planes'))
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if g.get('current_user'):
        return redirect(url_for('index'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        user = authenticate_user(email, password)
        if user:
            session['user_id'] = user['id']
            session.permanent = True
            next_url = request.args.get('next') or request.form.get('next')
            if next_url and next_url.startswith('/'):
                return redirect(next_url)
            return redirect(url_for('index'))
        flash('Correo o contraseña incorrectos', 'error')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Has cerrado sesión', 'success')
    return redirect(url_for('index'))


@app.route('/planes')
def planes():
    return render_template('planes.html')

@app.route('/donar')
def donar():
    return render_template('donar.html')


@app.route('/cuenta')
@login_required
def account():
    user = g.current_user
    from datetime import datetime, timezone
    plan_name = PLAN_NAMES.get(user['active_plan'], 'Sin Plan')
    sub_start = ''
    sub_end = ''
    if user.get('subscription_start'):
        sub_start = datetime.fromtimestamp(user['subscription_start'], tz=timezone.utc).strftime('%d/%m/%Y %H:%M')
    if user.get('subscription_end'):
        sub_end = datetime.fromtimestamp(user['subscription_end'], tz=timezone.utc).strftime('%d/%m/%Y %H:%M')
    member_since = datetime.fromtimestamp(user['created_at'], tz=timezone.utc).strftime('%d/%m/%Y')
    raw_payments = get_user_payments(user['id'])
    payments = []
    for p in raw_payments:
        payments.append({
            'date': datetime.fromtimestamp(p['created_at'], tz=timezone.utc).strftime('%d/%m/%Y'),
            'plan_name': PLAN_NAMES.get(p['plan'], p['plan']),
            'amount': p['amount'],
            'status': p['status'],
        })
    protected = get_protected_numbers(user['id']) if user_has_access(user, 'shield') else []
    free_used = get_free_searches_used(user['id'])
    free_limit = FREE_SEARCH_LIMIT
    return render_template('account.html', user=user, plan_name=plan_name,
                           sub_start=sub_start, sub_end=sub_end,
                           member_since=member_since, payments=payments,
                           protected_numbers=protected, free_used=free_used,
                           free_limit=free_limit)


@app.route('/subscribe/<plan>')
@login_required
def subscribe(plan):
    if plan not in (PLAN_LOCALIZADOR, PLAN_PREMIUM):
        flash('Plan no válido', 'error')
        return redirect(url_for('planes'))

    user = g.current_user

    if not stripe.api_key or not STRIPE_PRICE_IDS.get(plan):
        import time as _t
        update_user_plan(user['id'], plan)
        record_payment(user['id'], PLAN_PRICES[plan], plan, stripe_payment_id='demo_' + str(int(_t.time())), status='completed')
        flash(f'Suscripción activada: {PLAN_NAMES[plan]} (modo demo)', 'success')
        return redirect(url_for('account'))

    try:
        customer_id = user.get('stripe_customer_id')
        if not customer_id:
            customer = stripe.Customer.create(email=user['email'])
            customer_id = customer.id
            from models import _get_conn
            conn = _get_conn()
            conn.execute("UPDATE users SET stripe_customer_id = ? WHERE id = ?", (customer_id, user['id']))
            conn.commit()
            conn.close()

        domain = request.host_url.rstrip('/')
        checkout_session = stripe.checkout.Session.create(
            customer=customer_id,
            payment_method_types=['card'],
            line_items=[{
                'price': STRIPE_PRICE_IDS[plan],
                'quantity': 1,
            }],
            mode='subscription',
            success_url=domain + url_for('subscription_success') + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=domain + url_for('planes'),
            metadata={'plan': plan, 'user_id': str(user['id'])},
        )
        return redirect(checkout_session.url, code=303)
    except stripe.error.StripeError as e:
        logging.error(f"Stripe error: {e}")
        flash('Error al procesar el pago. Intenta de nuevo.', 'error')
        return redirect(url_for('planes'))


@app.route('/subscription/success')
@login_required
def subscription_success():
    session_id = request.args.get('session_id')
    if session_id and stripe.api_key:
        try:
            checkout = stripe.checkout.Session.retrieve(session_id)
            plan = checkout.metadata.get('plan', PLAN_LOCALIZADOR)
            sub_id = checkout.subscription
            customer_id = checkout.customer

            update_user_plan(
                g.current_user['id'], plan,
                stripe_customer_id=customer_id,
                stripe_subscription_id=sub_id
            )
            record_payment(
                g.current_user['id'], PLAN_PRICES.get(plan, 0), plan,
                stripe_payment_id=checkout.payment_intent, status='completed'
            )
            flash(f'Suscripción activada: {PLAN_NAMES.get(plan, plan)}', 'success')
        except Exception as e:
            logging.error(f"Subscription success error: {e}")
            flash('Pago procesado. Tu plan se activará en breve.', 'success')
    else:
        flash('Suscripción activada exitosamente', 'success')
    return redirect(url_for('account'))


@app.route('/webhook/stripe', methods=['POST'])
def stripe_webhook():
    payload = request.get_data(as_text=True)
    sig_header = request.headers.get('Stripe-Signature')

    if STRIPE_WEBHOOK_SECRET and sig_header:
        try:
            event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
        except ValueError:
            return jsonify({'error': 'Invalid payload'}), 400
        except stripe.error.SignatureVerificationError:
            return jsonify({'error': 'Invalid signature'}), 400
    else:
        try:
            event = json.loads(payload)
        except json.JSONDecodeError:
            return jsonify({'error': 'Invalid JSON'}), 400

    event_type = event.get('type', '')

    if event_type == 'checkout.session.completed':
        session_data = event['data']['object']
        customer_id = session_data.get('customer')
        plan = session_data.get('metadata', {}).get('plan', PLAN_LOCALIZADOR)
        user_id = session_data.get('metadata', {}).get('user_id')
        sub_id = session_data.get('subscription')

        user = None
        if user_id:
            user = get_user_by_id(int(user_id))
        if not user and customer_id:
            user = get_user_by_stripe_customer(customer_id)

        if user:
            update_user_plan(user['id'], plan, stripe_customer_id=customer_id, stripe_subscription_id=sub_id)
            record_payment(user['id'], PLAN_PRICES.get(plan, 0), plan,
                           stripe_payment_id=session_data.get('payment_intent'), status='completed')

    elif event_type == 'customer.subscription.deleted':
        sub_data = event['data']['object']
        customer_id = sub_data.get('customer')
        user = get_user_by_stripe_customer(customer_id) if customer_id else None
        if user:
            cancel_user_plan(user['id'])

    elif event_type == 'invoice.payment_failed':
        invoice_data = event['data']['object']
        customer_id = invoice_data.get('customer')
        user = get_user_by_stripe_customer(customer_id) if customer_id else None
        if user:
            cancel_user_plan(user['id'])

    return jsonify({'status': 'ok'}), 200


@app.route('/cancel-subscription', methods=['POST'])
@login_required
def cancel_subscription():
    user = g.current_user
    if user.get('stripe_subscription_id') and stripe.api_key:
        try:
            stripe.Subscription.cancel(user['stripe_subscription_id'])
        except Exception as e:
            logging.error(f"Stripe cancel error: {e}")
    cancel_user_plan(user['id'])
    flash('Tu suscripción ha sido cancelada', 'success')
    return redirect(url_for('account'))


@app.route('/escudo/agregar', methods=['POST'])
@login_required
def shield_add():
    user = g.current_user
    if not user_has_access(user, 'shield'):
        flash('El Escudo Anti-Localización requiere el Plan Premium ($9.99/mes)', 'warning')
        return redirect(url_for('planes'))
    phone = request.form.get('phone_number', '').strip()
    label = request.form.get('label', '').strip()
    if not phone:
        flash('Ingresa un número de teléfono para proteger', 'error')
        return redirect(url_for('account'))
    phone = re.sub(r'[\s\-\(\)]+', '', phone)
    if not phone.startswith('+'):
        if len(phone) == 8:
            phone = '+504' + phone
        elif phone.startswith('504') and len(phone) == 11:
            phone = '+' + phone
        else:
            phone = '+' + phone
    result = add_protected_number(user['id'], phone, label)
    if result:
        flash(f'Número {phone} protegido con el Escudo Anti-Localización', 'success')
    else:
        flash(f'El número {phone} ya está protegido', 'warning')
    return redirect(url_for('account'))


@app.route('/escudo/quitar/<int:number_id>', methods=['POST'])
@login_required
def shield_remove(number_id):
    user = g.current_user
    remove_protected_number(user['id'], number_id)
    flash('Número removido del Escudo Anti-Localización', 'success')
    return redirect(url_for('account'))


def get_countries_with_codes():
    return [
        {'name': 'Honduras', 'code': 'HN', 'phone_code': '504', 'flag': '\U0001F1ED\U0001F1F3', 'placeholder': '9582-9200'},
    ]


AREA_CODES = {
    'US': {
        'New York': '212, 646, 917',
        'Los Angeles': '213, 310, 323',
        'Chicago': '312, 773',
        'Miami': '305, 786',
        'Dallas': '214, 469, 972',
        'San Francisco': '415, 628',
        'Boston': '617, 857',
        'Washington DC': '202',
        'Seattle': '206, 253',
        'Houston': '713, 281, 832'
    },
    'CA': {
        'Toronto': '416, 647',
        'Montreal': '514, 438',
        'Vancouver': '604, 778',
        'Ottawa': '613, 343',
        'Calgary': '403, 587',
        'Edmonton': '780, 587'
    },
    'MX': {
        'Mexico City': '55',
        'Guadalajara': '33',
        'Monterrey': '81',
        'Puebla': '222',
        'Tijuana': '664'
    },
    'ES': {
        'Madrid': '91',
        'Barcelona': '93',
        'Valencia': '96',
        'Sevilla': '95',
        'Bilbao': '94',
        'Zaragoza': '976'
    },
    'GB': {
        'London': '20, 203, 207',
        'Manchester': '161',
        'Birmingham': '121',
        'Glasgow': '141',
        'Liverpool': '151',
        'Leeds': '113',
        'Edinburgh': '131',
        'Bristol': '117'
    },
    'HN': {
        'Tegucigalpa': '22',
        'San Pedro Sula': '25',
        'La Ceiba': '24',
        'Comayagua': '27',
        'Choluteca': '28',
        'Roatán': '24',
        'Santa Rosa de Copán': '26'
    },
    'GT': {
        'Ciudad de Guatemala': '22, 23',
        'Quetzaltenango': '77',
        'Escuintla': '78',
        'Mixco': '22',
        'Villa Nueva': '66',
        'Antigua Guatemala': '78',
        'Huehuetenango': '77',
        'Cobán': '79',
        'Petén': '79',
        'Puerto Barrios': '79'
    }
}


@app.route('/', methods=['GET'])
def index():
    countries = get_countries_with_codes()
    recent = []
    try:
        recent = get_recent_searches(5)
    except Exception:
        pass
    user = g.get('current_user')
    free_remaining = None
    free_limit = FREE_SEARCH_LIMIT
    has_plan = False
    if user:
        has_plan = user_has_access(user, 'locate')
        if not has_plan:
            free_remaining = get_free_searches_remaining(user['id'])
    return render_template('index.html', countries=countries, recent_searches=recent,
                           free_remaining=free_remaining, free_limit=free_limit, has_plan=has_plan)


@app.route('/estadisticas')
@plan_required('locate')
def estadisticas():
    stats = get_search_stats()
    return render_template('estadisticas.html', stats=stats)


@app.route('/area-codes/<country_code>', methods=['GET'])
def get_area_codes(country_code):
    if country_code in AREA_CODES:
        return jsonify(AREA_CODES[country_code])
    return jsonify({})


@app.route('/api/geolocate-ip', methods=['GET'])
def geolocate_ip():
    return jsonify({
        'lat': 14.0723,
        'lng': -87.1921,
        'city': 'Tegucigalpa',
        'country': 'Honduras',
        'isp': '',
        'accuracy_km': 50,
        'ip': ''
    })


@app.route('/api/google-geolocate', methods=['POST'])
def google_geolocate():
    api_key = os.environ.get('GOOGLE_MAPS_API_KEY')
    if not api_key:
        return jsonify({'error': 'No API key'})

    data = request.get_json() or {}
    cell_towers = data.get('cellTowers', [])
    wifi_points = data.get('wifiAccessPoints', [])

    payload = {}
    if cell_towers:
        payload['cellTowers'] = cell_towers
    if wifi_points:
        payload['wifiAccessPoints'] = wifi_points

    if not payload:
        return jsonify({'error': 'No cell or wifi data provided'})

    try:
        resp = http_requests.post(
            f"https://www.googleapis.com/geolocation/v1/geolocate?key={api_key}",
            json=payload,
            timeout=5
        )
        if resp.status_code == 200:
            result = resp.json()
            loc = result.get('location', {})
            return jsonify({
                'lat': loc.get('lat'),
                'lng': loc.get('lng'),
                'accuracy': result.get('accuracy'),
                'source': 'google_geolocation'
            })
    except Exception as e:
        logging.error(f"Google Geolocation error: {e}")

    return jsonify({'error': 'Google Geolocation failed'})


@app.route('/validate', methods=['POST', 'GET'])
@plan_required('locate')
def validate():
    if request.method == 'POST':
        phone_number = request.form.get('phone_number', '').strip()
    else:
        phone_number = request.args.get('phone_number', '').strip()

    if not phone_number:
        flash('Ingrese un número de teléfono', 'error')
        return redirect(url_for('index'))

    phone_number = re.sub(r'[\s\-\(\)]+', '', phone_number)
    if not phone_number.startswith('+'):
        if phone_number.startswith('504') and len(phone_number) == 11:
            phone_number = '+' + phone_number
        elif len(phone_number) == 8:
            phone_number = '+504' + phone_number
        else:
            phone_number = '+' + phone_number

    shield_info = is_number_protected(phone_number)
    if shield_info:
        return render_template('shield_blocked.html', phone_number=phone_number)

    user_lat_str = request.form.get('user_lat', '') or request.args.get('user_lat', '')
    user_lng_str = request.form.get('user_lng', '') or request.args.get('user_lng', '')
    geo_source = request.form.get('geo_source', '') or request.args.get('geo_source', '')
    user_lat = float(user_lat_str) if user_lat_str else None
    user_lng = float(user_lng_str) if user_lng_str else None

    result = validate_phone_number(phone_number)

    if result.get('valid'):
        country_code = result.get('country_code', '')
        carrier_name = result.get('carrier', '')
        city = result.get('city', 'Unknown')

        is_triangulation_country = country_code in ('HN', 'GT', 'US')

        parsed = phonenumbers.parse(phone_number)
        national = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL)
        national_digits = re.sub(r'\D', '', national)

        mobile_detected = False
        mobile_carrier = None
        area_code = None

        if is_triangulation_country:
            if is_mobile_number(country_code, national_digits):
                mobile_detected = True
                mobile_carrier = resolve_carrier_from_mobile_prefix(country_code, national_digits)
                logging.debug(f"Mobile number detected: prefix={national_digits[0]}, carrier={mobile_carrier}")
                from cell_towers import detect_city_for_mobile
                city = detect_city_for_mobile(country_code, phone_number) or 'San Pedro Sula'
            else:
                match = re.search(r'^\(?(\d{2})\)?', national)
                area_code = match.group(1) if match else None
                if area_code:
                    detected_city = get_city_from_area_code(country_code, area_code)
                    if detected_city:
                        city = detected_city

        carrier_key = resolve_carrier(carrier_name)
        if not carrier_key and mobile_carrier:
            carrier_key = mobile_carrier

        CARRIER_DISPLAY = {
            'tigo': 'Tigo', 'claro': 'Claro', 'digicel': 'Digicel',
            'att': 'AT&T', 'tmobile': 'T-Mobile', 'verizon': 'Verizon',
        }
        if carrier_key and (not carrier_name or carrier_name == 'Unknown'):
            carrier_name = CARRIER_DISPLAY.get(carrier_key, carrier_key)
            result['carrier'] = carrier_name

        result['is_mobile'] = mobile_detected

        towers = {}
        triangulation_result = None
        snn_layers = {}
        available_cities = []

        if is_triangulation_country:
            from honduras_area_codes import HONDURAS_MOBILE_CITIES

            cell_id_data = None
            cell_location = None

            if mobile_detected and country_code == 'HN':
                cell_id_data = lookup_cell_location(
                    phone_number,
                    carrier=carrier_key or 'tigo',
                    country_code=country_code,
                    detected_city=city if city != 'Unknown' else None
                )
                if cell_id_data:
                    loc = cell_id_data.get('location', {})
                    if loc.get('found'):
                        cell_precision = loc.get('precision', '')
                        cell_range = loc.get('range', 0)

                        if cell_precision != 'lac_centroid' and cell_range < 5000:
                            cell_location = (loc['lat'], loc['lng'])
                            result['geo_source'] = 'cell_id'
                            result['latitude'] = loc['lat']
                            result['longitude'] = loc['lng']
                            result['cell_range'] = cell_range

                            detected = detect_location_from_towers(
                                country_code, loc['lat'], loc['lng'], carrier_key
                            )
                            if detected and detected != 'Unknown':
                                city = detected
                                dept = CITY_TO_DEPARTMENT.get(city, '')
                                result['location'] = f"{city}, {dept}" if dept else city
                        else:
                            logging.info(
                                f"Cell ID returned LAC centroid (precision={cell_precision}, range={cell_range}m) — "
                                f"using city center for {city} instead"
                            )

                        logging.info(
                            f"Cell ID lookup: CID={cell_id_data['cell_id']} "
                            f"eNB={cell_id_data['enodeb_id']} sector={cell_id_data['sector_id']} "
                            f"LAC={cell_id_data['lac']} => {loc['lat']:.5f}, {loc['lng']:.5f} "
                            f"(precision={cell_precision}, range={cell_range}m)"
                        )

                    result['cell_id_info'] = cell_id_data

            if user_lat and user_lng and geo_source == 'gps' and not cell_location:
                    from math import radians, sin, cos, sqrt, atan2 as _atan2
                    def _haversine_km(lat1, lng1, lat2, lng2):
                        dlat = radians(lat2 - lat1); dlng = radians(lng2 - lng1)
                        a = sin(dlat/2)**2 + cos(radians(lat1))*cos(radians(lat2))*sin(dlng/2)**2
                        return 6371 * 2 * _atan2(sqrt(a), sqrt(1-a))

                    city_data = HONDURAS_MOBILE_CITIES.get(city) if city and city != 'Unknown' else None
                    if city_data:
                        city_lat = city_data['latitude']
                        city_lng = city_data['longitude']
                    else:
                        from phone_validator import COUNTRY_COORDINATES
                        cc_coords = COUNTRY_COORDINATES.get(country_code, {})
                        city_lat = cc_coords.get('latitude', 0)
                        city_lng = cc_coords.get('longitude', 0)

                    gps_to_city_km = _haversine_km(user_lat, user_lng, city_lat, city_lng) if city_lat else 9999

                    if gps_to_city_km < 100:
                        result['latitude'] = user_lat
                        result['longitude'] = user_lng
                        result['geo_source'] = 'gps'
                        logging.info(f"Using real GPS position: {user_lat}, {user_lng} (within {gps_to_city_km:.0f}km of {city})")

                        detected = detect_location_from_towers(country_code, user_lat, user_lng, carrier_key)
                        if detected and detected != 'Unknown':
                            city = detected
                            dept = CITY_TO_DEPARTMENT.get(city, '')
                            result['location'] = f"{city}, {dept}" if dept else city
                    else:
                        logging.info(f"Ignoring browser GPS ({user_lat:.4f}, {user_lng:.4f}) — {gps_to_city_km:.0f}km from {city}, user is not near target phone")
            elif user_lat and user_lng and geo_source == 'ip':
                    logging.info(f"Ignoring IP geolocation ({user_lat}, {user_lng}) — unreliable for phone localization")

            if city and city != 'Unknown' and is_triangulation_country:
                city_location_data = HONDURAS_MOBILE_CITIES.get(city)
                if city_location_data:
                    if not cell_location and result.get('geo_source') != 'gps':
                        result['latitude'] = city_location_data['latitude']
                        result['longitude'] = city_location_data['longitude']
                        result['geo_source'] = 'area_code'
                    result['location'] = city
                    dept = city_location_data.get('department', city_location_data.get('region', ''))
                    if dept:
                        result['location'] = f"{city}, {dept}"
            elif not result.get('latitude') and city and city != 'Unknown':
                city_location_data = HONDURAS_MOBILE_CITIES.get(city)
                if city_location_data:
                    result['latitude'] = city_location_data['latitude']
                    result['longitude'] = city_location_data['longitude']
                    result['location'] = city
                    result['geo_source'] = 'area_code'
                    dept = city_location_data.get('department', city_location_data.get('region', ''))
                    if dept:
                        result['location'] = f"{city}, {dept}"

            validate_known = lookup_known_position(phone_number) if country_code == 'HN' else None
            if validate_known:
                result['latitude'] = validate_known['lat']
                result['longitude'] = validate_known['lng']
                result['geo_source'] = 'known'
                result['location'] = validate_known.get('location', '')
                city = validate_known.get('city', city)
                logging.info(f"Validate: using KNOWN position for {phone_number}: {validate_known['lat']}, {validate_known['lng']}")

            center_lat = result.get('latitude', 0)
            center_lng = result.get('longitude', 0)

            if center_lat != 0 and center_lng != 0:
                towers = get_all_towers_in_range(country_code, center_lat, center_lng, range_km=30)
                total = sum(len(v) for v in towers.values())
                if total < 3:
                    towers = get_all_towers_in_range(country_code, center_lat, center_lng, range_km=60)
                    total = sum(len(v) for v in towers.values())
                if total < 3:
                    towers = get_all_towers_in_range(country_code, center_lat, center_lng, range_km=100)
            else:
                towers = get_all_towers_for_city(country_code, city) if city and city != 'Unknown' else {}

            available_cities = get_available_cities(country_code)

            if not carrier_key and is_triangulation_country and towers:
                best_carrier = max(towers.keys(), key=lambda k: len(towers.get(k, [])), default=None)
                if best_carrier and len(towers.get(best_carrier, [])) >= 3:
                    carrier_key = best_carrier
                    carrier_name = CARRIER_DISPLAY.get(carrier_key, carrier_key)
                    result['carrier'] = carrier_name
                    logging.info(f"Auto-detected carrier from towers: {carrier_key} ({len(towers[carrier_key])} towers)")

            if carrier_key:
                carrier_towers = towers.get(carrier_key, [])
            else:
                carrier_towers = []

            if carrier_key and len(carrier_towers) >= 3:
                all_towers = carrier_towers
            else:
                all_towers = []
                for t_list in towers.values():
                    if t_list:
                        all_towers.extend(t_list)

            if validate_known:
                real_lat = validate_known['lat']
                real_lng = validate_known['lng']
            elif user_lat and user_lng and geo_source == 'gps':
                real_lat = user_lat
                real_lng = user_lng
            else:
                real_lat = None
                real_lng = None

            if len(all_towers) >= 3:
                triangulation_result = triangulate(all_towers, center_lat, center_lng, phone_number=phone_number, country_code=country_code, wifi_position=None)

                wifi_pos_for_fusion = None
                if triangulation_result and is_triangulation_country:
                    tri_ref_lat = triangulation_result['lat']
                    tri_ref_lng = triangulation_result['lng']
                    try:
                        from wifi_positioning import wifi_scan_and_position
                        _wifi_seed = phone_number_seed(phone_number) if phone_number else hash(f"{tri_ref_lat}{tri_ref_lng}") & 0xFFFFFFFF
                        _wifi_result = wifi_scan_and_position(tri_ref_lat, tri_ref_lng, _wifi_seed)
                        if _wifi_result and _wifi_result.get('wps'):
                            wifi_pos_for_fusion = _wifi_result['wps']
                            triangulation_result = triangulate(all_towers, center_lat, center_lng, phone_number=phone_number, country_code=country_code, wifi_position=wifi_pos_for_fusion)
                    except Exception as e:
                        logging.warning(f"WiFi scan for fusion failed: {e}")

                if triangulation_result:
                    tri_lat = triangulation_result['lat']
                    tri_lng = triangulation_result['lng']
                    detected = detect_location_from_towers(country_code, tri_lat, tri_lng, carrier_key)
                    if detected and detected != 'Unknown':
                        city = detected
                        dept = CITY_TO_DEPARTMENT.get(city, '')
                        if dept:
                            result['location'] = f"{city}, {dept}"
                        else:
                            result['location'] = city

                    if not validate_known:
                        result['latitude'] = tri_lat
                        result['longitude'] = tri_lng
                        result['geo_source'] = 'tower_triangulation'
                        if not result.get('location') or result['location'] in ('', 'Unknown'):
                            result['location'] = f"Zona estimada por torres, {city}" if city and city != 'Unknown' else 'Zona estimada por torres'
                        logging.info(f"Validate: ESTIMATED position for {phone_number} via triangulation: {tri_lat:.6f}, {tri_lng:.6f}")

            phone_data = {
                'country_code': country_code,
                'carrier': carrier_name,
                'city': city,
                'area_code': area_code,
                'is_mobile': mobile_detected,
                'mobile_prefix': national_digits[0] if mobile_detected else None,
            }
            snn_layers = run_snn_layers(phone_data, towers, triangulation_result)

        result['carrier_key'] = carrier_key
        result['detected_city'] = city

        if cell_id_data and triangulation_result:
                triangulation_result['cell_id_info'] = {
                    'cell_id': cell_id_data.get('cell_id'),
                    'cell_id_hex': cell_id_data.get('cell_id_hex'),
                    'enodeb_id': cell_id_data.get('enodeb_id'),
                    'enodeb_hex': cell_id_data.get('enodeb_hex'),
                    'sector_id': cell_id_data.get('sector_id'),
                    'sector_hex': cell_id_data.get('sector_hex'),
                    'lac': cell_id_data.get('lac'),
                    'lac_name': cell_id_data.get('lac_name'),
                    'mcc': cell_id_data.get('mcc'),
                    'mnc': cell_id_data.get('mnc'),
                    'network_type': cell_id_data.get('network_type'),
                }

        try:
            record_search(
                phone=result.get('number', phone_number),
                carrier=carrier_name,
                city=city,
                lat=result.get('latitude'),
                lng=result.get('longitude'),
                country_code=country_code
            )
        except Exception as e:
            logging.warning(f"Failed to record search: {e}")

        user = g.get('current_user')
        if user and not user_has_access(user, 'locate'):
            increment_free_searches(user['id'])
        is_premium = user and user_has_access(user, 'study_zone')

        return render_template('result.html',
                               result=result,
                               is_triangulation=is_triangulation_country,
                               towers=json.dumps(towers),
                               triangulation=json.dumps(triangulation_result),
                               snn_layers=json.dumps(snn_layers),
                               available_cities=json.dumps(available_cities),
                               country_code=country_code,
                               user_lat=user_lat,
                               user_lng=user_lng,
                               is_premium=is_premium)
    else:
        flash(result.get('message', 'Invalid phone number'), 'error')
        return redirect(url_for('index'))


@app.route('/track')
@plan_required('track')
def track_page():
    return render_template('track.html')


@app.route('/api/track', methods=['POST'])
def api_track():
    user = g.get('current_user')
    if not user or not user_has_access(user, 'track'):
        return jsonify({'error': 'Requiere Plan Rastreo Premium'}), 403

    data = request.get_json()
    if not data:
        return jsonify({'error': 'Datos inválidos'}), 400

    origin_num = data.get('origin', '')
    dest_num = data.get('destination', '')
    conn_type = data.get('connection_type', 'call')
    browser_lat = data.get('user_lat')
    browser_lng = data.get('user_lng')

    if not origin_num or not dest_num:
        return jsonify({'error': 'Ingrese ambos números'}), 400

    origin_result = validate_phone_number(origin_num)
    dest_result = validate_phone_number(dest_num)

    if not origin_result.get('valid'):
        return jsonify({'error': f'Número origen inválido: {origin_num}'}), 400
    if not dest_result.get('valid'):
        return jsonify({'error': f'Número destino inválido: {dest_num}'}), 400

    origin_cc = origin_result.get('country_code', '')
    dest_cc = dest_result.get('country_code', '')

    origin_parsed = phonenumbers.parse(origin_num)
    dest_parsed = phonenumbers.parse(dest_num)
    origin_national = re.sub(r'\D', '', phonenumbers.format_number(origin_parsed, phonenumbers.PhoneNumberFormat.NATIONAL))
    dest_national = re.sub(r'\D', '', phonenumbers.format_number(dest_parsed, phonenumbers.PhoneNumberFormat.NATIONAL))

    origin_carrier_key = None
    dest_carrier_key = None
    if origin_cc in ('HN', 'GT') and is_mobile_number(origin_cc, origin_national):
        origin_carrier_key = resolve_carrier_from_mobile_prefix(origin_cc, origin_national)
    if dest_cc in ('HN', 'GT') and is_mobile_number(dest_cc, dest_national):
        dest_carrier_key = resolve_carrier_from_mobile_prefix(dest_cc, dest_national)

    if not origin_carrier_key:
        origin_carrier_key = resolve_carrier(origin_result.get('carrier', ''))
    if not dest_carrier_key:
        dest_carrier_key = resolve_carrier(dest_result.get('carrier', ''))

    from triangulation_engine import simulate_cell_connection, simulate_cell_connection_real, phone_number_seed, simulate_phone_position

    origin_is_tri = origin_cc in ('HN', 'GT', 'US')
    dest_is_tri = dest_cc in ('HN', 'GT', 'US')

    if dest_cc in ('HN', 'GT'):
        from cell_towers import detect_city_for_mobile
        dest_city = detect_city_for_mobile(dest_cc, dest_num) or ('San Pedro Sula' if dest_cc == 'HN' else 'Ciudad de Guatemala')
    elif dest_cc == 'US':
        dest_national_3 = dest_national[:3] if len(dest_national) >= 3 else ''
        us_area_cities = {'504': 'New Orleans', '225': 'Baton Rouge', '318': 'Shreveport', '337': 'Lafayette', '985': 'Mandeville'}
        dest_city = us_area_cities.get(dest_national_3, 'New Orleans')
    else:
        dest_city = 'Unknown'

    origin_known = lookup_known_position(origin_num) if origin_cc == 'HN' else None
    if browser_lat and browser_lng:
        origin_lat = float(browser_lat)
        origin_lng = float(browser_lng)
    elif origin_known:
        origin_lat = origin_known['lat']
        origin_lng = origin_known['lng']
    else:
        origin_lat = None
        origin_lng = None

    if origin_lat and origin_lng:
        set_origin_zone(origin_lat, origin_lng)
    elif origin_known:
        set_origin_zone(origin_known['lat'], origin_known['lng'])

    dest_cell_data = None
    if dest_cc in ('HN', 'GT'):
        dest_cell_data = lookup_cell_location(
            dest_num, carrier=dest_carrier_key or 'tigo',
            country_code=dest_cc, detected_city=dest_city
        )

    dest_known_pos = lookup_known_position(dest_num) if dest_cc == 'HN' else None

    from phone_validator import COUNTRY_COORDINATES
    default_coords = COUNTRY_COORDINATES.get(dest_cc, {'latitude': 15.45, 'longitude': -87.95})

    if dest_is_tri:
        dest_center_lat = default_coords['latitude']
        dest_center_lng = default_coords['longitude']

        if dest_cc == 'US':
            us_city_coords = {
                'New Orleans': (29.9511, -90.0715), 'Baton Rouge': (30.4583, -91.1403),
                'Shreveport': (32.5252, -93.7502), 'Lafayette': (30.2241, -92.0198),
                'Mandeville': (30.3571, -90.0758),
            }
            if dest_city in us_city_coords:
                dest_center_lat, dest_center_lng = us_city_coords[dest_city]

        if dest_known_pos:
            dest_center_lat = dest_known_pos['lat']
            dest_center_lng = dest_known_pos['lng']
            logging.info(f"Using KNOWN position for tower search: {dest_center_lat}, {dest_center_lng}")
        elif dest_cell_data and dest_cell_data.get('location', {}).get('found'):
            cell_prec = dest_cell_data['location'].get('precision', '')
            cell_rng = dest_cell_data['location'].get('range', 0)
            if cell_prec != 'lac_centroid' and cell_rng < 5000:
                dest_center_lat = dest_cell_data['location']['lat']
                dest_center_lng = dest_cell_data['location']['lng']
            else:
                city_data = HONDURAS_MOBILE_CITIES.get(dest_city)
                if city_data:
                    dest_center_lat = city_data['latitude']
                    dest_center_lng = city_data['longitude']

        towers = get_all_towers_in_range(dest_cc, dest_center_lat, dest_center_lng, range_km=40)
        total_towers = sum(len(v) for v in towers.values())
        if total_towers < 3:
            towers = get_all_towers_in_range(dest_cc, dest_center_lat, dest_center_lng, range_km=80)
    elif origin_is_tri:
        o_center = origin_lat or default_coords['latitude']
        o_center_lng = origin_lng or default_coords['longitude']
        towers = get_all_towers_in_range(origin_cc, o_center, o_center_lng, range_km=40)
        dest_center_lat = o_center
        dest_center_lng = o_center_lng
    else:
        towers = {}
        dest_center_lat = default_coords['latitude']
        dest_center_lng = default_coords['longitude']

    if not dest_carrier_key and towers:
        best_carrier = max(towers.keys(), key=lambda k: len(towers.get(k, [])), default=None)
        if best_carrier and len(towers.get(best_carrier, [])) >= 3:
            dest_carrier_key = best_carrier
    if not origin_carrier_key and towers:
        best_o = max(towers.keys(), key=lambda k: len(towers.get(k, [])), default=None)
        if best_o and len(towers.get(best_o, [])) >= 3:
            origin_carrier_key = best_o

    if dest_carrier_key and len(towers.get(dest_carrier_key, [])) >= 3:
        all_towers = towers[dest_carrier_key]
    else:
        all_towers = []
        for t_list in towers.values():
            if t_list:
                all_towers.extend(t_list)

    CARRIER_DISPLAY_TRACK = {
        'tigo': 'Tigo', 'claro': 'Claro', 'digicel': 'Digicel',
        'att': 'AT&T', 'tmobile': 'T-Mobile', 'verizon': 'Verizon',
    }
    dest_carrier_name = dest_result.get('carrier', '')
    if dest_carrier_key and (not dest_carrier_name or dest_carrier_name == 'Unknown'):
        dest_carrier_name = CARRIER_DISPLAY_TRACK.get(dest_carrier_key, dest_carrier_key)
    origin_carrier_name = origin_result.get('carrier', '')
    if origin_carrier_key and (not origin_carrier_name or origin_carrier_name == 'Unknown'):
        origin_carrier_name = CARRIER_DISPLAY_TRACK.get(origin_carrier_key, origin_carrier_key)

    origin_data = {
        'number_short': phonenumbers.format_number(origin_parsed, phonenumbers.PhoneNumberFormat.NATIONAL),
        'carrier': origin_carrier_name,
        'carrier_key': origin_carrier_key,
        'country_code': origin_cc,
        'country_name': origin_result.get('country_name', ''),
        'is_international': not origin_is_tri,
    }

    if origin_lat and origin_lng:
        origin_data['lat'] = origin_lat
        origin_data['lng'] = origin_lng
        origin_data['geo_source'] = 'gps' if browser_lat else ('known' if origin_known else 'simulated')
        if origin_known:
            origin_data['location'] = origin_known.get('location', '')
        if origin_is_tri and all_towers:
            o_seed = phone_number_seed(origin_num)
            o_connected, o_serving = simulate_cell_connection_real(all_towers, o_seed, origin_lat, origin_lng)
            origin_data['serving_tower'] = o_serving['tower']['id']
            origin_data['rssi'] = round(o_serving['rssi'], 1)
        elif not origin_is_tri:
            origin_data['serving_tower'] = 'Red ' + (origin_cc or 'INT')
            origin_data['rssi'] = -55
            origin_data['network'] = origin_result.get('carrier', 'Internacional')
    else:
        if origin_is_tri and all_towers:
            o_seed = phone_number_seed(origin_num)
            o_lat, o_lng = simulate_phone_position(o_seed, dest_center_lat, dest_center_lng, radius_km=15.0)
            origin_data['lat'] = o_lat
            origin_data['lng'] = o_lng
            origin_data['geo_source'] = 'simulated'
            o_connected, o_serving = simulate_cell_connection(all_towers, o_seed, dest_center_lat, dest_center_lng)
            origin_data['serving_tower'] = o_serving['tower']['id']
            origin_data['rssi'] = round(o_serving['rssi'], 1)
        else:
            origin_data['lat'] = 0
            origin_data['lng'] = 0
            origin_data['geo_source'] = 'unknown'
            origin_data['serving_tower'] = 'Red ' + (origin_cc or 'INT')
            origin_data['rssi'] = -55

    dest_data = {
        'number_short': phonenumbers.format_number(dest_parsed, phonenumbers.PhoneNumberFormat.NATIONAL),
        'carrier': dest_carrier_name,
        'carrier_key': dest_carrier_key,
        'country_code': dest_cc,
    }

    dest_known = lookup_known_position(dest_num) if dest_cc == 'HN' else None
    if dest_is_tri and all_towers:
        d_seed = phone_number_seed(dest_num)
        if dest_known:
            d_lat = dest_known['lat']
            d_lng = dest_known['lng']
            dest_data['location'] = dest_known.get('location', '')
            dest_data['city'] = dest_known.get('city', '')
            dest_data['place_type'] = dest_known.get('type', '')
            dest_data['is_moving'] = dest_known.get('moving', False)
            dest_data['home_lat'] = dest_known.get('home_lat')
            dest_data['home_lng'] = dest_known.get('home_lng')
            d_connected, d_serving = simulate_cell_connection_real(all_towers, d_seed, d_lat, d_lng)
            logging.info(f"Track dest position: {d_lat:.6f}, {d_lng:.6f} ({dest_known.get('location','')}) moving={dest_known.get('moving',False)}")
        else:
            d_lat, d_lng = simulate_phone_position(d_seed, dest_center_lat, dest_center_lng, radius_km=18.0)
            d_connected, d_serving = simulate_cell_connection(all_towers, d_seed, dest_center_lat, dest_center_lng)
            dest_data['geo_source'] = 'tower_estimate'
            dest_data['location'] = f"Zona estimada, {dest_city}" if dest_city != 'Unknown' else 'Zona estimada'
        dest_data['lat'] = d_lat
        dest_data['lng'] = d_lng
        dest_data['serving_tower'] = d_serving['tower']['id']
        dest_data['rssi'] = round(d_serving['rssi'], 1)
    else:
        d_seed = phone_number_seed(dest_num)
        dest_data['lat'] = dest_center_lat
        dest_data['lng'] = dest_center_lng
        dest_data['serving_tower'] = 'Red ' + (dest_cc or 'INT')
        dest_data['rssi'] = -60

    if dest_cell_data:
        dest_data['cell_id'] = dest_cell_data.get('cell_id')
        dest_data['enodeb'] = dest_cell_data.get('enodeb_id')
        dest_data['sector'] = dest_cell_data.get('sector_id')
        dest_data['lac'] = dest_cell_data.get('lac')
        dest_data['lac_name'] = dest_cell_data.get('lac_name')

    from wifi_positioning import wifi_scan_and_position, hybrid_position

    wifi_data = None
    hybrid_data = None
    wifi_center_lat = dest_known['lat'] if dest_known else dest_data.get('lat')
    wifi_center_lng = dest_known['lng'] if dest_known else dest_data.get('lng')
    if dest_is_tri and wifi_center_lat and wifi_center_lng:
        d_seed_wifi = phone_number_seed(dest_num)
        wifi_result = wifi_scan_and_position(wifi_center_lat, wifi_center_lng, d_seed_wifi)
        wifi_data = wifi_result

        if wifi_result.get('wps') and dest_data.get('rssi'):
            cell_acc = abs(dest_data['rssi']) * 15
            wifi_acc = wifi_result['wps']['accuracy_m']
            hybrid_data = hybrid_position(
                dest_data['lat'], dest_data['lng'], cell_acc,
                wifi_result['wps']['lat'], wifi_result['wps']['lng'], wifi_acc
            )

    conn_info = {
        'type': conn_type,
        'encryption': 'AES-256-GCM' if conn_type == 'whatsapp' else 'A5/1-GSM' if conn_type == 'call' else 'None',
        'protocol': 'Signal Protocol' if conn_type == 'whatsapp' else 'SS7/MAP' if conn_type == 'call' else 'SS7/SMS-PP',
    }

    logging.info(f"Track: {origin_num} → {dest_num} via {conn_type}")

    dest_normalized = normalize_phone_for_lookup(dest_num)
    if not dest_normalized.startswith('504'):
        dest_normalized = '504' + dest_normalized
    hotel_alert = None
    if dest_normalized in WATCHED_PHONES:
        d_lat_check = dest_data.get('lat', 0)
        d_lng_check = dest_data.get('lng', 0)
        if d_lat_check and d_lng_check:
            proximity = _check_hotel_proximity(d_lat_check, d_lng_check)
            now_ts = _time.time()

            if proximity:
                hotel_key = dest_normalized + ':' + proximity['name']
                tracking_entry = HOTEL_PROXIMITY_TRACKING.get(hotel_key)

                if not tracking_entry:
                    HOTEL_PROXIMITY_TRACKING[hotel_key] = {
                        'first_seen': now_ts,
                        'hotel_name': proximity['name'],
                        'hotel_type': proximity['type'],
                        'detections': 1,
                    }
                    logging.info(f"🏨 PROXIMIDAD DETECTADA: {dest_num} cerca de {proximity['name']} ({proximity['distance_m']}m) — esperando permanencia de 10 min")
                    dest_data['hotel_pending'] = {
                        'name': proximity['name'],
                        'type': proximity['type'],
                        'distance_m': proximity['distance_m'],
                        'first_seen': now_ts,
                        'elapsed_s': 0,
                        'required_s': HOTEL_MIN_PERMANENCE_S,
                    }
                else:
                    tracking_entry['detections'] += 1
                    elapsed = now_ts - tracking_entry['first_seen']

                    if elapsed >= HOTEL_MIN_PERMANENCE_S and tracking_entry['detections'] >= 2:
                        hotel_alert = proximity
                        dest_data['hotel_alert'] = hotel_alert
                        dest_data['hotel_alert']['timestamp'] = now_ts
                        dest_data['hotel_alert']['datetime'] = _hn_strftime('%A %d/%m/%Y %H:%M:%S')
                        dest_data['hotel_alert']['day'] = _hn_strftime('%A')
                        dest_data['hotel_alert']['date'] = _hn_strftime('%d/%m/%Y')
                        dest_data['hotel_alert']['time'] = _hn_strftime('%H:%M:%S')
                        dest_data['hotel_alert']['permanence_min'] = round(elapsed / 60, 1)
                        dest_data['hotel_alert']['detections'] = tracking_entry['detections']

                        companions = scan_hotel_companions(
                            dest_num,
                            hotel_alert['hotel_lat'], hotel_alert['hotel_lng'],
                            hotel_alert['name'], scan_radius_m=200
                        )
                        dest_data['hotel_alert']['companions'] = companions

                        if companions:
                            dest_data['hotel_alert']['confidence'] = 'CONFIRMADO'
                            for comp in companions:
                                logging.warning(f"   📱 ACOMPAÑANTE: {comp['phone']} — {comp['shared_aps']} APs, {comp['distance_m']}m"
                                                + (f" — {comp['contact_name']}" if comp.get('contact_name') else '')
                                                + (f" ({comp['contact_owner']})" if comp.get('contact_owner') else '')
                                                + (f" [{comp['contact_model']}]" if comp.get('contact_model') else ''))
                        else:
                            dest_data['hotel_alert']['confidence'] = 'PROBABLE'

                        logging.warning(f"⚠️ ALERTA [{dest_data['hotel_alert']['confidence']}]: {dest_num} en {hotel_alert['name']} ({hotel_alert['type']}) — {dest_data['hotel_alert']['permanence_min']} min, {tracking_entry['detections']} detecciones, {hotel_alert['distance_m']}m")
                    else:
                        remaining = HOTEL_MIN_PERMANENCE_S - elapsed
                        logging.info(f"🏨 PERMANENCIA: {dest_num} cerca de {proximity['name']} — {round(elapsed/60,1)} min (faltan {round(remaining/60,1)} min)")
                        dest_data['hotel_pending'] = {
                            'name': proximity['name'],
                            'type': proximity['type'],
                            'distance_m': proximity['distance_m'],
                            'first_seen': tracking_entry['first_seen'],
                            'elapsed_s': round(elapsed),
                            'required_s': HOTEL_MIN_PERMANENCE_S,
                            'detections': tracking_entry['detections'],
                        }
            else:
                keys_to_remove = [k for k in HOTEL_PROXIMITY_TRACKING if k.startswith(dest_normalized + ':')]
                for k in keys_to_remove:
                    removed = HOTEL_PROXIMITY_TRACKING.pop(k, None)
                    if removed:
                        elapsed = now_ts - removed['first_seen']
                        logging.info(f"🏨 DESCARTADO: {dest_num} dejó zona de {removed['hotel_name']} tras {round(elapsed/60,1)} min (no alcanzó 10 min)")

    try:
        d_lat_val = dest_data.get('lat', 0)
        d_lng_val = dest_data.get('lng', 0)
        d_loc = dest_data.get('location', '')
        d_ptype = dest_data.get('place_type', '')
        d_city = dest_data.get('city', '')
        d_dept = dest_data.get('department', '')
        d_moving = dest_data.get('is_moving', False)
        alert_type = ''
        alert_detail = ''
        if hotel_alert:
            confidence = dest_data.get('hotel_alert', {}).get('confidence', 'PROBABLE')
            alert_type = f"{hotel_alert['type']}:{confidence}"
            comp_list = dest_data.get('hotel_alert', {}).get('companions', [])
            perm_min = dest_data.get('hotel_alert', {}).get('permanence_min', 0)
            comp_info = ''
            if comp_list:
                comp_phones = [c['phone'] + (' [' + c['contact_name'] + ']' if c.get('contact_name') else '') for c in comp_list]
                comp_info = ' | WiFi: ' + ', '.join(comp_phones)
            alert_detail = f"[{confidence}] {hotel_alert['name']} ({hotel_alert['distance_m']}m, {perm_min} min){comp_info}"
        insert_tracking(dest_num, d_lat_val, d_lng_val, d_loc, d_ptype, d_city, d_dept, d_moving, alert_type, alert_detail)
        upsert_tracked_phone(dest_num, dest_cc, dest_data.get('carrier', ''), d_city, d_lat_val, d_lng_val, d_loc)
    except Exception as e:
        logging.error(f"Tracking DB error: {e}")

    response = {
        'origin': origin_data,
        'destination': dest_data,
        'towers': towers,
        'connection': conn_info,
        'hotel_locations': HOTEL_MOTEL_LOCATIONS if dest_normalized in WATCHED_PHONES else [],
    }

    if wifi_data:
        response['wifi'] = wifi_data
    if hybrid_data:
        response['hybrid'] = hybrid_data

    return jsonify(response)


@app.route('/api/history/<path:phone>', methods=['GET'])
def api_history(phone):
    phone = phone.strip()
    if not phone:
        return jsonify({'error': 'Missing phone'}), 400
    limit = request.args.get('limit', 200, type=int)
    history = get_history(phone, limit=limit)
    return jsonify({'phone': phone, 'history': history})


@app.route('/api/tracked-phones', methods=['GET'])
def api_tracked_phones():
    phones = get_tracked_phones(limit=50)
    return jsonify({'phones': phones})


@app.route('/api/nearby/<path:phone>', methods=['GET'])
def api_nearby(phone):
    phone = phone.strip()
    lat = request.args.get('lat', type=float)
    lng = request.args.get('lng', type=float)
    if lat is None or lng is None:
        return jsonify({'error': 'Missing lat/lng'}), 400
    radius = request.args.get('radius', 250, type=int)
    nearby = find_nearby_phones(phone, lat, lng, radius_m=radius)
    return jsonify({'phone': phone, 'nearby': nearby})


@app.route('/api/contacts', methods=['GET'])
def api_list_contacts():
    contacts = list_contacts(limit=100)
    return jsonify({'contacts': contacts})

@app.route('/api/contacts', methods=['POST'])
def api_save_contact():
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Datos inválidos'}), 400
    phone = data.get('phone', '').strip()
    name = data.get('name', '').strip()
    lat = data.get('lat')
    lng = data.get('lng')
    if not phone or not name or lat is None or lng is None:
        return jsonify({'error': 'Faltan campos requeridos: phone, name, lat, lng'}), 400
    try:
        lat = float(lat)
        lng = float(lng)
    except (ValueError, TypeError):
        return jsonify({'error': 'Coordenadas inválidas'}), 400
    colonia = data.get('colonia', '')
    city = data.get('city', '')
    department = data.get('department', '')
    owner_name = data.get('owner_name', '')
    phone_model = data.get('phone_model', '')
    save_contact(phone, name, lat, lng, colonia, city, department, owner_name, phone_model)
    normalized = normalize_phone_for_lookup(phone)
    if not normalized.startswith('504'):
        normalized = '504' + normalized
    if normalized in GENERATED_PROFILES:
        del GENERATED_PROFILES[normalized]
    if normalized in PHONE_MOVEMENT_STATE:
        del PHONE_MOVEMENT_STATE[normalized]
    return jsonify({'ok': True, 'phone': phone, 'name': name})

@app.route('/api/contacts/<path:phone>', methods=['DELETE'])
def api_delete_contact(phone):
    phone = phone.strip()
    delete_contact(phone)
    normalized = normalize_phone_for_lookup(phone)
    if not normalized.startswith('504'):
        normalized = '504' + normalized
    if normalized in GENERATED_PROFILES:
        del GENERATED_PROFILES[normalized]
    if normalized in PHONE_MOVEMENT_STATE:
        del PHONE_MOVEMENT_STATE[normalized]
    return jsonify({'ok': True})

@app.route('/api/study', methods=['GET'])
def api_study():
    user = g.get('current_user')
    if not user or not user_has_access(user, 'study_zone'):
        return jsonify({'error': 'El Estudio de Zona requiere Plan Premium ($9.99/mes)', 'upgrade': True}), 403
    lat = request.args.get('lat', type=float)
    lng = request.args.get('lng', type=float)
    if lat is None or lng is None:
        return jsonify({'error': 'Missing lat/lng'}), 400
    api_key = os.environ.get('GOOGLE_MAPS_API_KEY')
    if not api_key:
        return jsonify({'error': 'Maps API not configured'}), 500
    categories = {
        'moteles': 'lodging',
        'bares': 'night_club',
    }
    results = {}
    for label, place_type in categories.items():
        try:
            url = 'https://maps.googleapis.com/maps/api/place/nearbysearch/json'
            params = {
                'location': f'{lat},{lng}',
                'radius': 3000,
                'type': place_type,
                'key': api_key,
                'language': 'es'
            }
            if label == 'moteles':
                params['keyword'] = 'motel|auto hotel|hotel'
            elif label == 'bares':
                params['keyword'] = 'bar|discoteca|club nocturno|cantina|lounge'
            resp = http_requests.get(url, params=params, timeout=8)
            data = resp.json()
            places = []
            for p in data.get('results', [])[:5]:
                loc = p.get('geometry', {}).get('location', {})
                plat = loc.get('lat', lat)
                plng = loc.get('lng', lng)
                from math import radians, sin, cos, sqrt, atan2
                R = 6371
                dlat = radians(plat - lat)
                dlng = radians(plng - lng)
                a = sin(dlat/2)**2 + cos(radians(lat))*cos(radians(plat))*sin(dlng/2)**2
                dist_km = R * 2 * atan2(sqrt(a), sqrt(1-a))
                if dist_km < 1:
                    dist_str = f"{int(dist_km*1000)}m"
                else:
                    dist_str = f"{dist_km:.1f}km"
                places.append({
                    'name': p.get('name', 'Sin nombre'),
                    'dist': dist_str,
                    'lat': plat,
                    'lng': plng,
                    'rating': p.get('rating', 0),
                    'open': p.get('opening_hours', {}).get('open_now', None)
                })
            results[label] = places
        except Exception as e:
            logging.error(f"Study API error for {label}: {e}")
            results[label] = []
    return jsonify(results)

@app.route('/api/ping')
def api_ping():
    return jsonify({'pong': True})


@app.route('/api/triangulate', methods=['POST'])
def api_triangulate():
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid JSON body'}), 400
    country_code = data.get('country_code', '')
    city = data.get('city', '')
    carrier = data.get('carrier', '')

    if country_code not in ('HN', 'GT', 'US') or not city:
        return jsonify({'error': 'Invalid parameters'}), 400

    towers = get_all_towers_for_city(country_code, city)
    carrier_key = resolve_carrier(carrier)

    if carrier_key and len(towers.get(carrier_key, [])) >= 3:
        all_towers = towers[carrier_key]
    else:
        all_towers = []
        for t_list in towers.values():
            if t_list:
                all_towers.extend(t_list)

    if not all_towers:
        return jsonify({'error': 'No towers found'}), 404

    from honduras_area_codes import HONDURAS_AREA_CODES
    from guatemala_area_codes import GUATEMALA_AREA_CODES

    city_data = None
    if country_code == 'HN':
        for code, info in HONDURAS_AREA_CODES.items():
            if info['city'] == city:
                city_data = info
                break
    elif country_code == 'GT':
        for code, info in GUATEMALA_AREA_CODES.items():
            if info['city'] == city:
                city_data = info
                break

    if not city_data:
        center_lat = sum(t['lat'] for t in all_towers) / len(all_towers)
        center_lng = sum(t['lng'] for t in all_towers) / len(all_towers)
    else:
        center_lat = city_data['latitude']
        center_lng = city_data['longitude']

    tri = triangulate(all_towers, center_lat, center_lng, country_code=country_code)

    return jsonify({
        'towers': towers,
        'triangulation': tri,
        'city': city,
    })


@app.route('/api/weather', methods=['GET'])
def api_weather():
    lat = request.args.get('lat', type=float)
    lng = request.args.get('lng', type=float)
    if lat is None or lng is None:
        return jsonify({'error': 'Missing lat/lng'}), 400

    weather = fetch_weather_data(lat, lng)
    aqi = fetch_aqi_data(lat, lng)

    return jsonify({
        'weather': weather,
        'aqi': aqi,
    })


@app.route('/api/towers/stats', methods=['GET'])
def api_tower_stats():
    from opencellid_etl import get_tower_stats, get_data_version
    return jsonify({
        'stats': get_tower_stats(),
        'version': get_data_version(),
    })


@app.route('/api/towers/update', methods=['POST'])
def api_tower_update():
    from opencellid_etl import import_opencellid_csv
    import tempfile
    import hmac

    update_token = os.environ.get('TOWER_UPDATE_TOKEN')
    if not update_token:
        return jsonify({'error': 'Tower updates are disabled (TOWER_UPDATE_TOKEN not configured)'}), 403

    auth_header = request.headers.get('Authorization', '')
    provided_token = auth_header.replace('Bearer ', '') if auth_header.startswith('Bearer ') else ''
    if not provided_token or not hmac.compare_digest(provided_token, update_token):
        return jsonify({'error': 'Unauthorized'}), 401

    if 'file' not in request.files:
        return jsonify({'error': 'No CSV file provided. Upload an OpenCelliD CSV file.'}), 400

    uploaded = request.files['file']
    if not uploaded.filename:
        return jsonify({'error': 'Empty filename'}), 400

    if not uploaded.filename.lower().endswith('.csv'):
        return jsonify({'error': 'Only CSV files are accepted'}), 400

    max_size = 50 * 1024 * 1024
    uploaded.seek(0, 2)
    size = uploaded.tell()
    uploaded.seek(0)
    if size > max_size:
        return jsonify({'error': f'File too large ({size} bytes). Maximum is {max_size} bytes.'}), 413

    with tempfile.NamedTemporaryFile(mode='wb', suffix='.csv', delete=False) as tmp:
        uploaded.save(tmp)
        tmp_path = tmp.name

    try:
        result = import_opencellid_csv(tmp_path)

        import cell_towers
        cell_towers.TIGO_TOWERS = cell_towers._load_carrier_towers('tigo')
        cell_towers.CLARO_TOWERS = cell_towers._load_carrier_towers('claro')
        cell_towers.DIGICEL_TOWERS = cell_towers._load_carrier_towers('digicel')

        return jsonify({
            'status': 'success',
            'imported': result,
        })
    except Exception as e:
        logging.error(f"Tower update failed: {e}")
        return jsonify({'error': str(e)}), 500
    finally:
        os.unlink(tmp_path)


@app.errorhandler(404)
def page_not_found(e):
    return render_template('index.html'), 404


@app.errorhandler(500)
def server_error(e):
    flash('An unexpected error occurred. Please try again later.', 'error')
    return render_template('index.html'), 500
