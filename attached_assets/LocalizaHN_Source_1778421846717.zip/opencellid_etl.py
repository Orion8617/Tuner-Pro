"""
OpenCelliD ETL Pipeline for MCC 708 (Honduras) and MCC 704 (Guatemala).

This module handles:
1. Loading tower data from local CSV files (offline preloaded data)
2. Exporting tower data to OpenCelliD-compatible CSV format
3. Importing/updating from raw OpenCelliD CSV downloads (with automatic city
   assignment via nearest-city geolocation when 'city' column is absent)
4. Enriching tower records with frequency, band, and radio type metadata

Data provenance:
  Preloaded tower data extracted from the OpenCelliD community database
  (https://opencellid.org), filtered for MCC 708 (Honduras) and MCC 704
  (Guatemala). Licensed under CC BY-SA 4.0. See DATA_PROVENANCE in this
  module for full details.

CSV format follows OpenCelliD cell_towers.csv schema:
  radio,mcc,mnc,lac,cid,unit,lon,lat,range,samples,changeable,created,updated,averageSignal

Extended fields for local enrichment:
  cell_id,enodeb,band,tech,power_dbm,source,carrier,city,country

Usage:
  python opencellid_etl.py --export          Export current data to CSV
  python opencellid_etl.py --import FILE     Import/merge from OpenCelliD CSV
  python opencellid_etl.py --stats           Show tower statistics
"""

import csv
import math
import os
import sys
import json
import logging
import time
from pathlib import Path

logger = logging.getLogger(__name__)

DATA_DIR = Path(__file__).parent / 'data'

DATA_PROVENANCE = {
    'source': 'OpenCelliD community database (https://opencellid.org)',
    'extraction': 'Filtered from OpenCelliD cell_towers.csv for MCC 708 (Honduras) and MCC 704 (Guatemala)',
    'schema': 'OpenCelliD cell_towers.csv (radio,mcc,mnc,lac,cid,unit,lon,lat,range,samples,changeable,created,updated,averageSignal)',
    'mnc_mapping': 'MCC 708: MNC 2=Tigo, MNC 1=Claro, MNC 40=Digicel; MCC 704: MNC 1=Tigo, MNC 3=Claro',
    'initial_extract_date': '2024-11-01',
    'update_method': 'Download OpenCelliD CSV export, filter by MCC, import via opencellid_etl.py --import-csv',
    'license': 'Creative Commons Attribution-ShareAlike 4.0 (CC BY-SA 4.0)',
}

CITY_CENTERS = {
    708: {
        'Tegucigalpa': (14.0723, -87.1921),
        'San Pedro Sula': (15.5000, -88.0333),
        'La Ceiba': (15.7631, -86.7822),
        'Choloma': (15.5600, -87.9544),
        'Villanueva': (15.3167, -87.9833),
        'Comayagua': (14.4513, -87.6346),
        'La Lima': (15.4333, -87.9167),
        'Puerto Cortés': (15.8383, -87.9497),
        'Choluteca': (13.3000, -87.1833),
        'Juticalpa': (14.6500, -86.2167),
        'Danlí': (14.0333, -86.5833),
        'Siguatepeque': (14.6000, -87.8333),
        'El Progreso': (15.4000, -87.8000),
        'Tela': (15.7833, -87.4500),
        'Tocoa': (15.6500, -85.9833),
        'Santa Rosa de Copán': (14.7667, -88.7833),
        'Olanchito': (15.4833, -86.5833),
        'Roatán': (16.3333, -86.5333),
        'Catacamas': (14.8000, -85.9000),
        'Trujillo': (15.9167, -85.9500),
        'Pimienta': (15.4167, -87.9500),
        'San Manuel': (15.4000, -87.7500),
        'Omoa': (15.7333, -88.0500),
        'Potrerillos': (15.2167, -87.9500),
        'Comayagüela': (14.0833, -87.2167),
        'La Paz': (14.3167, -87.6833),
        'Nacaome': (13.5333, -87.4833),
        'Gracias': (14.5833, -88.5833),
        'Yoro': (15.1333, -87.1333),
        'Guanaja': (16.4667, -85.9000),
        'La Entrada': (14.9500, -88.8333),
        'La Esperanza': (14.3000, -88.1833),
        'Marcala': (14.1167, -88.0000),
        'Copán Ruinas': (14.8333, -89.1500),
        'Utila': (16.1000, -86.8833),
        'Puerto Lempira': (15.2667, -83.7667),
        'Santa Bárbara': (14.9167, -88.2333),
        'Sabá': (15.6333, -86.0333),
        'San Lorenzo': (13.4167, -87.4500),
        'Morocelí': (14.1000, -86.8667),
        'Talanga': (14.3833, -87.0833),
        'Lepaera': (14.7833, -88.5833),
    },
    704: {
        'Ciudad de Guatemala': (14.6349, -90.5069),
        'Quetzaltenango': (14.8333, -91.5167),
        'Escuintla': (14.3000, -90.7833),
        'Villa Nueva': (14.5333, -90.5833),
        'Cobán': (15.4667, -90.3667),
    },
    310: {
        'New Orleans': (29.9511, -90.0715),
        'Baton Rouge': (30.4583, -91.1403),
        'Shreveport': (32.5252, -93.7502),
        'Lafayette': (30.2241, -92.0198),
        'Lake Charles': (30.2132, -93.2174),
        'Mandeville': (30.3571, -90.0758),
        'Hammond': (30.5044, -90.4612),
        'Covington': (30.4854, -90.3290),
        'Kenner': (29.9941, -90.2417),
        'Metairie': (29.9841, -90.1528),
        'Houma': (29.5958, -90.7195),
        'Slidell': (30.2752, -89.7812),
        'Monroe': (32.5093, -92.1193),
        'Alexandria': (31.3113, -92.4451),
    },
}


def _assign_city_from_coords(lat, lon, mcc):
    cities = CITY_CENTERS.get(mcc, {})
    if not cities:
        return 'Unknown'

    best_city = 'Unknown'
    best_dist = float('inf')
    cos_lat = math.cos(lat * math.pi / 180)

    for city_name, (clat, clon) in cities.items():
        dlat = (lat - clat) * 111.32
        dlon = (lon - clon) * 111.32 * cos_lat
        dist = math.sqrt(dlat * dlat + dlon * dlon)
        if dist < best_dist:
            best_dist = dist
            best_city = city_name

    if best_dist > 50:
        return 'Unknown'

    return best_city


MCC_CONFIGS = {
    708: {
        'country': 'HN',
        'name': 'Honduras',
        'file': 'towers_708.csv',
        'operators': {
            1: {'name': 'Claro', 'carrier_key': 'claro'},
            2: {'name': 'Tigo', 'carrier_key': 'tigo'},
            40: {'name': 'Digicel', 'carrier_key': 'digicel'},
        }
    },
    704: {
        'country': 'GT',
        'name': 'Guatemala',
        'file': 'towers_704.csv',
        'operators': {
            1: {'name': 'Tigo', 'carrier_key': 'tigo'},
            3: {'name': 'Claro', 'carrier_key': 'claro'},
        }
    },
    310: {
        'country': 'US',
        'name': 'United States',
        'file': 'towers_310.csv',
        'operators': {
            410: {'name': 'AT&T', 'carrier_key': 'att'},
            260: {'name': 'T-Mobile', 'carrier_key': 'tmobile'},
            12: {'name': 'Verizon', 'carrier_key': 'verizon'},
        }
    },
}

BAND_FREQUENCY_MAP = {
    'B2': {'earfcn': 900, 'frequency_mhz': 1900, 'band_name': 'Band 2 (PCS 1900)', 'radio': 'LTE'},
    'B4': {'earfcn': 2050, 'frequency_mhz': 2100, 'band_name': 'Band 4 (AWS 1700/2100)', 'radio': 'LTE'},
    'B5': {'earfcn': 2543, 'frequency_mhz': 883, 'band_name': 'Band 5 (CLR 850) UL:838/DL:883', 'radio': 'LTE'},
    'B7': {'earfcn': 3100, 'frequency_mhz': 2600, 'band_name': 'Band 7 (2600)', 'radio': 'LTE'},
    'B12': {'earfcn': 5095, 'frequency_mhz': 700, 'band_name': 'Band 12 (700)', 'radio': 'LTE'},
    'GSM850': {'earfcn': 190, 'frequency_mhz': 850, 'band_name': 'GSM 850', 'radio': 'GSM'},
    'GSM1900': {'earfcn': 661, 'frequency_mhz': 1900, 'band_name': 'GSM 1900', 'radio': 'GSM'},
    'UMTS850': {'earfcn': 4357, 'frequency_mhz': 850, 'band_name': 'UMTS 850', 'radio': 'UMTS'},
    'UMTS1900': {'earfcn': 9662, 'frequency_mhz': 1900, 'band_name': 'UMTS 1900', 'radio': 'UMTS'},
}

TECH_RADIO_MAP = {
    'LTE': 'LTE',
    '2G': 'GSM',
    '3G': 'UMTS',
    'UMTS': 'UMTS',
}

CSV_FIELDS = [
    'radio', 'mcc', 'mnc', 'lac', 'cid', 'unit', 'lon', 'lat', 'range',
    'samples', 'changeable', 'created', 'updated', 'averageSignal',
    'cell_id', 'enodeb', 'band', 'tech', 'power_dbm', 'source',
    'carrier', 'city', 'country',
]


def _enrich_tower_record(tower):
    band = tower.get('band', 'B2')
    tech = tower.get('tech', 'LTE')
    freq_info = BAND_FREQUENCY_MAP.get(band, BAND_FREQUENCY_MAP['B2'])
    tower['earfcn'] = freq_info['earfcn']
    tower['frequency_mhz'] = freq_info['frequency_mhz']
    tower['band_name'] = freq_info['band_name']
    tower['radio_type'] = TECH_RADIO_MAP.get(tech, freq_info.get('radio', 'LTE'))
    return tower


def _csv_row_to_tower(row):
    tower = {
        'id': row.get('cell_id', ''),
        'lat': float(row.get('lat', 0)),
        'lng': float(row.get('lon', 0)),
        'range_km': int(row.get('range', 3000)) / 1000.0,
        'power_dbm': int(float(row.get('power_dbm', -65))),
        'enodeb': int(row.get('enodeb', 0)),
        'lac': int(row.get('lac', 0)),
        'band': row.get('band', 'B2'),
        'tech': row.get('tech', 'LTE'),
        'avg_signal': int(float(row.get('averageSignal', -65))),
        'samples': int(row.get('samples', 1)),
        'source': row.get('source', 'OpenCelliD'),
        'mcc': int(row.get('mcc', 708)),
        'mnc': int(row.get('mnc', 2)),
    }
    _enrich_tower_record(tower)
    return tower


def _tower_to_csv_row(tower, carrier, city, country_code, mcc, mnc):
    enodeb = tower.get('enodeb', 0)
    return {
        'radio': tower.get('radio_type', 'LTE'),
        'mcc': mcc,
        'mnc': mnc,
        'lac': tower.get('lac', 0),
        'cid': enodeb * 256 if enodeb else 0,
        'unit': 0,
        'lon': tower['lng'],
        'lat': tower['lat'],
        'range': int(tower['range_km'] * 1000),
        'samples': tower.get('samples', 1),
        'changeable': 1,
        'created': tower.get('created', 1700000000),
        'updated': tower.get('updated', int(time.time())),
        'averageSignal': tower.get('avg_signal', tower.get('power_dbm', -65)),
        'cell_id': tower['id'],
        'enodeb': enodeb,
        'band': tower.get('band', 'B2'),
        'tech': tower.get('tech', 'LTE'),
        'power_dbm': tower.get('power_dbm', -65),
        'source': tower.get('source', 'OpenCelliD'),
        'carrier': carrier,
        'city': city,
        'country': country_code,
    }


def load_towers_from_csv(mcc):
    config = MCC_CONFIGS.get(mcc)
    if not config:
        logger.warning(f"Unknown MCC {mcc}")
        return {}

    csv_path = DATA_DIR / config['file']
    if not csv_path.exists():
        logger.warning(f"CSV file not found: {csv_path}")
        return {}

    carriers = {}
    for op_info in config['operators'].values():
        carriers[op_info['carrier_key']] = {}

    row_count = 0
    with open(csv_path, 'r', newline='', encoding='utf-8') as f:
        lines = [line for line in f if not line.startswith('#')]
        reader = csv.DictReader(lines)
        for row in reader:
            carrier = row.get('carrier', '').lower()
            city = row.get('city', 'Unknown')

            if carrier not in carriers:
                continue

            if city not in carriers[carrier]:
                carriers[carrier][city] = []

            tower = _csv_row_to_tower(row)
            carriers[carrier][city].append(tower)
            row_count += 1

    logger.info(f"Loaded {row_count} towers from {csv_path} for MCC {mcc}")
    return carriers


def load_all_towers():
    result = {'HN': {}, 'GT': {}}
    for mcc, config in MCC_CONFIGS.items():
        country = config['country']
        carriers = load_towers_from_csv(mcc)
        for carrier_key, cities in carriers.items():
            if carrier_key not in result[country]:
                result[country][carrier_key] = {}
            result[country][carrier_key].update(cities)
    return result


def export_to_csv(tower_data, mcc, output_path=None):
    config = MCC_CONFIGS.get(mcc)
    if not config:
        raise ValueError(f"Unknown MCC {mcc}")

    if output_path is None:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        output_path = DATA_DIR / config['file']

    country_code = config['country']
    rows = []

    for mnc, op_info in config['operators'].items():
        carrier_key = op_info['carrier_key']
        carrier_data = tower_data.get(carrier_key, {})
        if isinstance(carrier_data, dict):
            for city, towers in carrier_data.items():
                for t in towers:
                    rows.append(_tower_to_csv_row(t, carrier_key, city, country_code, mcc, mnc))

    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        f.write(f"# Source: OpenCelliD community database (https://opencellid.org)\n")
        f.write(f"# Extraction: Filtered from OpenCelliD cell_towers.csv for MCC {mcc} ({config['country']})\n")
        operators_desc = ', '.join(f"MNC {mnc}={info['carrier_key'].capitalize()}" for mnc, info in config['operators'].items())
        f.write(f"# Operators: {operators_desc}\n")
        f.write(f"# License: Creative Commons Attribution-ShareAlike 4.0 (CC BY-SA 4.0)\n")
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(rows)

    logger.info(f"Exported {len(rows)} towers to {output_path}")
    return len(rows)


def import_opencellid_csv(source_path, target_mccs=None):
    if target_mccs is None:
        target_mccs = [708, 704]

    if not os.path.exists(source_path):
        raise FileNotFoundError(f"Source CSV not found: {source_path}")

    imported = {mcc: {} for mcc in target_mccs}
    skipped = 0
    processed = 0

    mnc_to_carrier = {}
    for mcc in target_mccs:
        config = MCC_CONFIGS.get(mcc, {})
        for mnc, op_info in config.get('operators', {}).items():
            mnc_to_carrier[(mcc, mnc)] = op_info['carrier_key']

    with open(source_path, 'r', newline='', encoding='utf-8') as f:
        lines = [line for line in f if not line.startswith('#')]
        reader = csv.DictReader(lines)
        for row in reader:
            processed += 1
            try:
                mcc = int(row.get('mcc', 0))
            except (ValueError, TypeError):
                skipped += 1
                continue

            if mcc not in target_mccs:
                skipped += 1
                continue

            try:
                mnc = int(row.get('mnc', 0))
            except (ValueError, TypeError):
                skipped += 1
                continue

            carrier_key = mnc_to_carrier.get((mcc, mnc))
            if not carrier_key:
                skipped += 1
                continue

            city = row.get('city', '').strip()
            if not city:
                try:
                    lat = float(row.get('lat', 0))
                    lon = float(row.get('lon', 0))
                    city = _assign_city_from_coords(lat, lon, mcc)
                except (ValueError, TypeError):
                    city = 'Unknown'

            if city not in imported[mcc]:
                imported[mcc][city] = {}
            if carrier_key not in imported[mcc][city]:
                imported[mcc][city][carrier_key] = []

            tower = _csv_row_to_tower(row)
            imported[mcc][city][carrier_key].append(tower)

    result = {}
    for mcc, city_data in imported.items():
        carriers = {}
        for city, carrier_towers in city_data.items():
            for carrier_key, towers in carrier_towers.items():
                if carrier_key not in carriers:
                    carriers[carrier_key] = {}
                carriers[carrier_key][city] = towers

        if carriers:
            validation = validate_tower_data(carriers)
            min_towers = MIN_TOWERS_PER_COUNTRY.get(mcc, 10)
            total_count = validation['total_towers']
            if total_count < min_towers:
                logger.warning(f"MCC {mcc}: Only {total_count} towers, minimum is {min_towers}. Skipping import.")
                result[mcc] = {'towers': 0, 'skipped': True, 'reason': f'below minimum ({total_count} < {min_towers})'}
                continue

            config = MCC_CONFIGS[mcc]
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            total = export_to_csv(carriers, mcc)
            result[mcc] = {'towers': total, 'carriers': list(carriers.keys()), 'validation': validation}

    logger.info(f"Import complete: processed={processed}, skipped={skipped}, result={result}")
    return result


def get_tower_stats():
    stats = {}
    for mcc, config in MCC_CONFIGS.items():
        country = config['country']
        carriers = load_towers_from_csv(mcc)
        total = 0
        carrier_stats = {}
        for carrier_key, cities in carriers.items():
            count = sum(len(towers) for towers in cities.values())
            carrier_stats[carrier_key] = {
                'count': count,
                'cities': len(cities),
            }
            total += count
        stats[country] = {
            'mcc': mcc,
            'name': config['name'],
            'total': total,
            'carriers': carrier_stats,
        }
    return stats


def get_data_version():
    version_info = {}
    for mcc, config in MCC_CONFIGS.items():
        csv_path = DATA_DIR / config['file']
        if csv_path.exists():
            stat = csv_path.stat()
            version_info[mcc] = {
                'file': str(csv_path),
                'size_bytes': stat.st_size,
                'modified': stat.st_mtime,
                'modified_iso': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(stat.st_mtime)),
            }
        else:
            version_info[mcc] = {'file': str(csv_path), 'exists': False}
    return version_info


REQUIRED_TOWER_FIELDS = ['id', 'lat', 'lng', 'range_km', 'power_dbm', 'band', 'tech', 'mcc', 'mnc']
REQUIRED_ENRICHED_FIELDS = ['earfcn', 'frequency_mhz', 'radio_type', 'avg_signal', 'samples', 'source']

MIN_TOWERS_PER_COUNTRY = {708: 50, 704: 10}


def validate_tower_data(towers_by_carrier):
    errors = []
    warnings = []
    total = 0

    for carrier_key, cities in towers_by_carrier.items():
        for city, towers in cities.items():
            for t in towers:
                total += 1
                for field in REQUIRED_TOWER_FIELDS:
                    if field not in t or t[field] in (None, '', 0) and field not in ('power_dbm',):
                        if field == 'id' and not t.get('id'):
                            errors.append(f"Tower in {city}/{carrier_key} missing required field: {field}")
                        elif field in ('mcc', 'mnc') and field not in t:
                            errors.append(f"Tower {t.get('id', '?')} missing {field}")
                for field in REQUIRED_ENRICHED_FIELDS:
                    if field not in t:
                        warnings.append(f"Tower {t.get('id', '?')} missing enrichment field: {field}")

    return {
        'valid': len(errors) == 0,
        'total_towers': total,
        'errors': errors[:20],
        'warnings': warnings[:10],
        'error_count': len(errors),
        'warning_count': len(warnings),
    }


def validate_imported_data(mcc):
    carriers = load_towers_from_csv(mcc)
    result = validate_tower_data(carriers)

    min_towers = MIN_TOWERS_PER_COUNTRY.get(mcc, 10)
    if result['total_towers'] < min_towers:
        result['valid'] = False
        result['errors'].append(
            f"MCC {mcc}: Only {result['total_towers']} towers loaded, minimum is {min_towers}"
        )

    return result


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    import argparse

    parser = argparse.ArgumentParser(description='OpenCelliD ETL for MCC 708/704')
    parser.add_argument('--export', action='store_true', help='Export current data to CSV')
    parser.add_argument('--import-csv', type=str, metavar='FILE', help='Import from OpenCelliD CSV file')
    parser.add_argument('--stats', action='store_true', help='Show tower statistics')
    parser.add_argument('--version', action='store_true', help='Show data version info')
    parser.add_argument('--validate', action='store_true', help='Validate loaded tower data integrity')
    args = parser.parse_args()

    if args.validate:
        all_ok = True
        for mcc in MCC_CONFIGS:
            result = validate_imported_data(mcc)
            status = 'PASS' if result['valid'] else 'FAIL'
            print(f"MCC {mcc}: {status} ({result['total_towers']} towers, {result['error_count']} errors, {result['warning_count']} warnings)")
            if result['errors']:
                for e in result['errors']:
                    print(f"  ERROR: {e}")
            if not result['valid']:
                all_ok = False
        sys.exit(0 if all_ok else 1)
    elif args.stats:
        stats = get_tower_stats()
        print(json.dumps(stats, indent=2))
    elif args.version:
        ver = get_data_version()
        print(json.dumps(ver, indent=2))
    elif args.import_csv:
        result = import_opencellid_csv(args.import_csv)
        print(json.dumps(result, indent=2))
    elif args.export:
        all_towers = load_all_towers()
        for mcc, config in MCC_CONFIGS.items():
            country = config['country']
            carrier_data = {}
            for carrier_key in all_towers.get(country, {}).keys():
                carrier_data[carrier_key] = all_towers[country][carrier_key]
            count = export_to_csv(carrier_data, mcc)
            print(f"Exported {count} towers for MCC {mcc} ({config['name']})")
    else:
        parser.print_help()
