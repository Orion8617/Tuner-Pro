# LocalizaHN — Localización Celular Honduras

## Overview
LocalizaHN is a phone number validation and cell tower triangulation system for Honduras (MCC 708) with Pythagorean IRLS (Iteratively Reweighted Least Squares) solver, ternary quantization (◎/•/━ Maya symbols), WiFi+Cell fusion, CAD-style layered result display, Six Sigma precision (P50=50m, P90=101m), and a clean professional dark dashboard. SaaS subscription model with Stripe payments.

## Architecture

### Backend (Python/Flask)
- `app.py` — Flask app with routes: `/` (home with WiFi map), `/validate` (phone validation + triangulation, requires 'locate' plan), `/api/triangulate`, `/api/weather`, `/api/track` (requires 'track' premium plan), `/api/history/<phone>`, `/api/tracked-phones`, `/api/nearby/<phone>`, `/api/contacts` (GET/POST), `/api/contacts/<phone>` (DELETE), `/api/geolocate-ip`, `/registro` (register), `/login`, `/logout`, `/planes` (pricing page), `/cuenta` (account page), `/subscribe/<plan>`, `/cancel-subscription`, `/webhook/stripe`, `/subscription/success`
- `tracking_db.py` — SQLite persistence layer for tracking history, searched numbers, and contacts
- `cell_towers.py` — Tower database with enriched OpenCelliD-style data (HN/GT/US carriers). Dynamic `CARRIER_TOWER_MAP` dict, `_get_country_carriers()` helper, `ALL_CARRIER_KEYS` set. US carriers: AT&T (MNC 410), T-Mobile (MNC 260), Verizon (MNC 12)
- `triangulation_engine.py` — TriNet-Pythag v2 triangulation engine: Cost-231 Hata propagation, GN-IRLS solver with Tukey Bisquare robust weighting (progressive c: 6σ→4.685σ), gain-ratio adaptive LM damping, asymmetric NLOS penalty, quality gate tower pre-filtering (RSRP/RSRQ/TA consistency), 13 multi-start points (5 IRLS × 40 GN iterations), vigesimal quantization, GDOP scoring, IVW WiFi+Cell fusion
- `wifi_positioning.py` — WiFi access point simulation, WPS positioning, hybrid position calculation, hotel companion scanning
- `phone_validator.py` — Phone number validation using phonenumbers library. US area codes: 504 (New Orleans), 225 (Baton Rouge), 318 (Shreveport), 337 (Lafayette), 985 (Mandeville)
- `opencellid_etl.py` — ETL pipeline for tower CSV data. MCC_CONFIGS for 708 (HN), 704 (GT), 310 (US)
- `honduras_area_codes.py` — Honduras area code to city mapping. All 22 cities verified against real coordinates (OpenStreetMap/Google Maps). Both HONDURAS_AREA_CODES (landline) and HONDURAS_MOBILE_CITIES (mobile) dicts.
- `models.py` — SQLite user/subscription models: users (email, password_hash, active_plan, stripe_customer_id, stripe_subscription_id, subscription_start/end, free_searches_used), payments, protected_numbers (shield). Plans: 'localizador' ($5.99/mo) and 'premium' ($9.99/mo). Freemium: 2 free searches for unsubscribed users. Shield: premium users can protect numbers from being located. Auth helpers: create_user, authenticate_user, user_has_access, increment_free_searches, get_free_searches_remaining, add_protected_number, remove_protected_number, is_number_protected.
- `main.py` — Gunicorn entry point

### Frontend
- `templates/index.html` — LocalizaHN home page with WiFi/GPS map, hero map section, search history, stats link. Inter + JetBrains Mono fonts, Honduras-only.
- `templates/result.html` — LocalizaHN HUD with 3 CAD layers, staged loading animation, WhatsApp share + Google Maps copy buttons
- `templates/track.html` — Live Tracking HUD with Leaflet.heat heatmap, history trail, contacts directory, Wi-Fi proximity detection
- `templates/login.html` — Login page (Inter/JetBrains Mono, SVG logo, glassmorphism cards)
- `templates/register.html` — Registration page (unified design with login)
- `templates/planes.html` — Pricing page showing Localizador ($5.99/mo) and Rastreo Premium ($9.99/mo) with feature comparison, freemium badge
- `templates/account.html` — User account page showing current plan, renewal date, payment history, upgrade/cancel, Escudo Anti-Localización management (premium)
- `templates/upgrade.html` — Upgrade prompt for premium features
- `templates/limit_reached.html` — Freemium limit reached page (2 free searches exhausted, shows plan options)
- `templates/estadisticas.html` — Statistics dashboard: total searches, daily chart (Chart.js), top numbers, location heatmap (Leaflet.heat)
- `static/css/hud.css` — Dark glassmorphism HUD styles (Inter/JetBrains Mono), `.cad-layer`/`.cad-visible` transitions, carrier toggles
- `static/css/styles.css` — Base styles (Inter/JetBrains Mono, flash alerts)
- `static/js/clonengine.js` — Leaflet map rendering, carrier layer system, progressive CAD layer reveal, SNN ticks

### CAD Layer System
- **Layer 1 (MAPA)**: Map + towers + IEC fitness — visible immediately (cadLayer1)
- **Layer 2 (ANÁLISIS)**: SNN Pascal panel + prediction + city selector — fades in after ~2s (cadLayer2)
- **Metrics Strip (cadMetrics)**: 6 location-relevant gauges (Precisión ±m, Torres, Señal %, Distancia km/m, Zona, Confianza %) — loads after ~2.5s
- CSS: `.cad-layer { opacity: 0; pointer-events: none }` → `.cad-layer.cad-visible { opacity: 1; pointer-events: auto }`

### Pascal Horizons
- **Alpha (blue, L0–L2)**: Reactive — Parseo, Torres, Triangulación
- **Beta (amber, L3–L5)**: Analytical — Suavizado SNN, Pascal Cascade, Cuantización Vigesimal
- **Gamma (purple, L6–L7)**: Deferred async — Latencia de Red

### Dynamic Carrier System
- `CARRIER_COLORS` / `CARRIER_LABELS` dicts in clonengine.js
- `initCarrierLayers(towers)` creates Leaflet layer groups and toggle buttons dynamically
- `renderTowers(towers)` iterates carrier keys instead of hardcoded tigo/claro/digicel
- `filterTowersByCarrier(towers, carrier)` uses dynamic `Object.values()` aggregation

### Tower Data (CellMapper-Verified)
- `data/towers_708.csv` — Honduras towers: Tigo (B4 AWS 2100MHz + B5 CLR 883MHz + GSM850), Claro (B4 AWS 2100MHz + GSM1900). Includes 3 CellMapper-verified towers (eNB 3087, LAC 42060, cells 790273-790276). Digicel inactive (sold to Claro 2011).
- `data/towers_704.csv` — Guatemala towers (Tigo/Claro)
- `data/towers_310.csv` — US/Louisiana towers (AT&T/T-Mobile/Verizon) ~66 towers across New Orleans, Baton Rouge, Shreveport, Lafayette, Lake Charles, Mandeville, Hammond, Covington
- Real Honduras spectrum: Tigo LTE B4 EARFCN:2050 (UL:1720/DL:2120 MHz) + B5 EARFCN:2543 (UL:838/DL:883 MHz); Claro LTE B4 EARFCN:2050 only

### Theme
- **Color scheme**: Navy/slate blue (`#0d1117` bg, `#58a6ff` primary, `#388bfd` secondary, `#d29922` amber accent)
- **Map tiles**: Stadia Alidade Smooth Dark (result page) + Esri Satellite toggle, CartoDB Dark Matter on other pages
- **Popup style**: `#161b22` bg, `border-radius:8px`, system-ui font, `box-shadow:0 8px 24px rgba(0,0,0,.5)`
- **Branding**: "CLONENGINE" — Sistema de Localización Celular · v3.0
- **All pages**: Spanish language, consistent dark navy theme across validator, result, and tracking pages

### Triangulation Solver (TriNet-Pythag v2)
- **Method**: GN-IRLS with Tukey Bisquare robust weighting + gain-ratio adaptive LM damping
- **IRLS rounds**: 5 outer rounds with progressive Tukey c (6σ→4.685σ), asymmetric NLOS penalty
- **GN iterations**: 40 per IRLS round with gain-ratio LM damping (rejects steps when cost rises)
- **Starting points**: 13 (centroid + 12 tower offsets at 500m)
- **Quality gates**: NLOS detection via RSRP/RSRQ/TA consistency, distance ratio anomaly detection
- **WiFi fusion**: IVW (Inverse Variance Weighting) with σ² from GDOP+residuals (cell) and accuracy×AP-factor (WiFi)
- **Tower dedup**: `_dedupe_towers()` removes co-located towers (<55m apart)
- **Default freq**: 2100 MHz (Band 4 AWS) matching real Honduras Tigo/Claro deployments

### Position Resolution
- **Known numbers**: Numbers in `KNOWN_HOMES` dict or contacts DB get precise location with movement simulation (home, work, mall, etc. based on time of day)
- **Unknown numbers**: `lookup_known_position()` returns `None`. Triangulation uses tower-based IRLS estimation. Result shows `geo_source: 'tower_triangulation'` and location label "Zona estimada por torres". No fake addresses or colonias are generated.
- **GPS/IP**: Browser GPS or IP geolocation can provide center coordinates for tower search
- **Road-snap validation**: All positions (triangulated + simulated) are snapped to nearest road/street using Google Roads API (`_snap_to_road`) with reverse geocode fallback (`_snap_to_nearest_road_reverse`). Water positions snap to nearest populated anchor first, then road-snap. Cache in `_ROAD_SNAP_CACHE` prevents redundant API calls. Max snap distance: 3km (roads), 2km (reverse). Ensures no positions land in forests, lakes, or impassable terrain.

### Hotel/Motel Alert System
- `WATCHED_PHONES = {'50495829200'}` — only this number triggers hotel monitoring
- `HOTEL_ALERT_RADIUS_M = 150` — haversine proximity check
- `HOTEL_MIN_PERMANENCE_S = 600` — 10-minute minimum before alert fires
- Confidence levels: CONFIRMADO (companion WiFi found) / PROBABLE (no companion)

### Timezone
- `HN_TZ = timezone(timedelta(hours=-6))` — Honduras UTC-6
- Frontend uses `timeZone:'America/Tegucigalpa'` in date/time formatters

### Rust/WASM Motor
- `rust_triangulation/src/lib.rs` — Rust triangulation engine compiled to WASM
- `static/wasm/` — Compiled WASM binary (~148KB) + JS bindings

## Environment
- Port: 5000
- Framework: Flask + Gunicorn
- Database: PostgreSQL (SQLAlchemy) + SQLite (tracking_db)
- APIs: ipgeolocation.io, Google Maps, Open-Meteo (weather/AQI)
- WASM: Rust wasm-pack build
- Secrets: GOOGLE_MAPS_API_KEY, IPGEOLOCATION_API_KEY, DATABASE_URL, SESSION_SECRET, STRIPE_SECRET_KEY (optional), STRIPE_PUBLISHABLE_KEY (optional), STRIPE_WEBHOOK_SECRET (optional), STRIPE_PRICE_LOCALIZADOR (optional Stripe Price ID), STRIPE_PRICE_PREMIUM (optional Stripe Price ID)

### SaaS Subscription System
- **Plan Localizador** ($4.99/mo): Locate phone numbers, see carrier, approximate zone, 7-day history
- **Plan Rastreo Premium** ($9.99/mo): All Localizador features + live tracking, proximity alerts, heatmap, nearby devices, 30-day history, contacts directory
- Auth: Session-based with `session['user_id']`, permanent sessions (30 days). `@login_required` and `@plan_required(feature)` decorators.
- Stripe: Optional. If STRIPE_SECRET_KEY not set, operates in demo mode (instant plan activation without payment). Webhook endpoint at `/webhook/stripe` handles checkout.session.completed, customer.subscription.deleted, invoice.payment_failed.
- Users DB: `users.db` SQLite file with users and payments tables
